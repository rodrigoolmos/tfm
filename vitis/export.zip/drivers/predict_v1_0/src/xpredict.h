// ==============================================================
// Vitis HLS - High-Level Synthesis from C, C++ and OpenCL v2023.1.1 (64-bit)
// Tool Version Limit: 2023.06
// Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
// Copyright 2022-2023 Advanced Micro Devices, Inc. All Rights Reserved.
// 
// ==============================================================
#ifndef XPREDICT_H
#define XPREDICT_H

#ifdef __cplusplus
extern "C" {
#endif

/***************************** Include Files *********************************/
#ifndef __linux__
#include "xil_types.h"
#include "xil_assert.h"
#include "xstatus.h"
#include "xil_io.h"
#else
#include <stdint.h>
#include <assert.h>
#include <dirent.h>
#include <fcntl.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/mman.h>
#include <unistd.h>
#include <stddef.h>
#endif
#include "xpredict_hw.h"

/**************************** Type Definitions ******************************/
#ifdef __linux__
typedef uint8_t u8;
typedef uint16_t u16;
typedef uint32_t u32;
typedef uint64_t u64;
#else
typedef struct {
    u16 DeviceId;
    u64 Compact_data_BaseAddress;
    u64 Features_BaseAddress;
    u64 Next_node_right_index_BaseAddress;
    u64 Node_leaf_value_BaseAddress;
    u64 Prediction_BaseAddress;
    u64 Results_BaseAddress;
} XPredict_Config;
#endif

typedef struct {
    u64 Compact_data_BaseAddress;
    u64 Features_BaseAddress;
    u64 Next_node_right_index_BaseAddress;
    u64 Node_leaf_value_BaseAddress;
    u64 Prediction_BaseAddress;
    u64 Results_BaseAddress;
    u32 IsReady;
} XPredict;

typedef u32 word_type;

/***************** Macros (Inline Functions) Definitions *********************/
#ifndef __linux__
#define XPredict_WriteReg(BaseAddress, RegOffset, Data) \
    Xil_Out32((BaseAddress) + (RegOffset), (u32)(Data))
#define XPredict_ReadReg(BaseAddress, RegOffset) \
    Xil_In32((BaseAddress) + (RegOffset))
#else
#define XPredict_WriteReg(BaseAddress, RegOffset, Data) \
    *(volatile u32*)((BaseAddress) + (RegOffset)) = (u32)(Data)
#define XPredict_ReadReg(BaseAddress, RegOffset) \
    *(volatile u32*)((BaseAddress) + (RegOffset))

#define Xil_AssertVoid(expr)    assert(expr)
#define Xil_AssertNonvoid(expr) assert(expr)

#define XST_SUCCESS             0
#define XST_DEVICE_NOT_FOUND    2
#define XST_OPEN_DEVICE_FAILED  3
#define XIL_COMPONENT_IS_READY  1
#endif

/************************** Function Prototypes *****************************/
#ifndef __linux__
int XPredict_Initialize(XPredict *InstancePtr, u16 DeviceId);
XPredict_Config* XPredict_LookupConfig(u16 DeviceId);
int XPredict_CfgInitialize(XPredict *InstancePtr, XPredict_Config *ConfigPtr);
#else
int XPredict_Initialize(XPredict *InstancePtr, const char* InstanceName);
int XPredict_Release(XPredict *InstancePtr);
#endif

void XPredict_Start(XPredict *InstancePtr);
u32 XPredict_IsDone(XPredict *InstancePtr);
u32 XPredict_IsIdle(XPredict *InstancePtr);
u32 XPredict_IsReady(XPredict *InstancePtr);
void XPredict_EnableAutoRestart(XPredict *InstancePtr);
void XPredict_DisableAutoRestart(XPredict *InstancePtr);

u32 XPredict_Get_prediction(XPredict *InstancePtr);
u32 XPredict_Get_prediction_vld(XPredict *InstancePtr);
u32 XPredict_Get_compact_data_0_BaseAddress(XPredict *InstancePtr);
u32 XPredict_Get_compact_data_0_HighAddress(XPredict *InstancePtr);
u32 XPredict_Get_compact_data_0_TotalBytes(XPredict *InstancePtr);
u32 XPredict_Get_compact_data_0_BitWidth(XPredict *InstancePtr);
u32 XPredict_Get_compact_data_0_Depth(XPredict *InstancePtr);
u32 XPredict_Write_compact_data_0_Words(XPredict *InstancePtr, int offset, word_type *data, int length);
u32 XPredict_Read_compact_data_0_Words(XPredict *InstancePtr, int offset, word_type *data, int length);
u32 XPredict_Write_compact_data_0_Bytes(XPredict *InstancePtr, int offset, char *data, int length);
u32 XPredict_Read_compact_data_0_Bytes(XPredict *InstancePtr, int offset, char *data, int length);
u32 XPredict_Get_compact_data_1_BaseAddress(XPredict *InstancePtr);
u32 XPredict_Get_compact_data_1_HighAddress(XPredict *InstancePtr);
u32 XPredict_Get_compact_data_1_TotalBytes(XPredict *InstancePtr);
u32 XPredict_Get_compact_data_1_BitWidth(XPredict *InstancePtr);
u32 XPredict_Get_compact_data_1_Depth(XPredict *InstancePtr);
u32 XPredict_Write_compact_data_1_Words(XPredict *InstancePtr, int offset, word_type *data, int length);
u32 XPredict_Read_compact_data_1_Words(XPredict *InstancePtr, int offset, word_type *data, int length);
u32 XPredict_Write_compact_data_1_Bytes(XPredict *InstancePtr, int offset, char *data, int length);
u32 XPredict_Read_compact_data_1_Bytes(XPredict *InstancePtr, int offset, char *data, int length);
u32 XPredict_Get_compact_data_2_BaseAddress(XPredict *InstancePtr);
u32 XPredict_Get_compact_data_2_HighAddress(XPredict *InstancePtr);
u32 XPredict_Get_compact_data_2_TotalBytes(XPredict *InstancePtr);
u32 XPredict_Get_compact_data_2_BitWidth(XPredict *InstancePtr);
u32 XPredict_Get_compact_data_2_Depth(XPredict *InstancePtr);
u32 XPredict_Write_compact_data_2_Words(XPredict *InstancePtr, int offset, word_type *data, int length);
u32 XPredict_Read_compact_data_2_Words(XPredict *InstancePtr, int offset, word_type *data, int length);
u32 XPredict_Write_compact_data_2_Bytes(XPredict *InstancePtr, int offset, char *data, int length);
u32 XPredict_Read_compact_data_2_Bytes(XPredict *InstancePtr, int offset, char *data, int length);
u32 XPredict_Get_compact_data_3_BaseAddress(XPredict *InstancePtr);
u32 XPredict_Get_compact_data_3_HighAddress(XPredict *InstancePtr);
u32 XPredict_Get_compact_data_3_TotalBytes(XPredict *InstancePtr);
u32 XPredict_Get_compact_data_3_BitWidth(XPredict *InstancePtr);
u32 XPredict_Get_compact_data_3_Depth(XPredict *InstancePtr);
u32 XPredict_Write_compact_data_3_Words(XPredict *InstancePtr, int offset, word_type *data, int length);
u32 XPredict_Read_compact_data_3_Words(XPredict *InstancePtr, int offset, word_type *data, int length);
u32 XPredict_Write_compact_data_3_Bytes(XPredict *InstancePtr, int offset, char *data, int length);
u32 XPredict_Read_compact_data_3_Bytes(XPredict *InstancePtr, int offset, char *data, int length);
u32 XPredict_Get_compact_data_4_BaseAddress(XPredict *InstancePtr);
u32 XPredict_Get_compact_data_4_HighAddress(XPredict *InstancePtr);
u32 XPredict_Get_compact_data_4_TotalBytes(XPredict *InstancePtr);
u32 XPredict_Get_compact_data_4_BitWidth(XPredict *InstancePtr);
u32 XPredict_Get_compact_data_4_Depth(XPredict *InstancePtr);
u32 XPredict_Write_compact_data_4_Words(XPredict *InstancePtr, int offset, word_type *data, int length);
u32 XPredict_Read_compact_data_4_Words(XPredict *InstancePtr, int offset, word_type *data, int length);
u32 XPredict_Write_compact_data_4_Bytes(XPredict *InstancePtr, int offset, char *data, int length);
u32 XPredict_Read_compact_data_4_Bytes(XPredict *InstancePtr, int offset, char *data, int length);
u32 XPredict_Get_compact_data_5_BaseAddress(XPredict *InstancePtr);
u32 XPredict_Get_compact_data_5_HighAddress(XPredict *InstancePtr);
u32 XPredict_Get_compact_data_5_TotalBytes(XPredict *InstancePtr);
u32 XPredict_Get_compact_data_5_BitWidth(XPredict *InstancePtr);
u32 XPredict_Get_compact_data_5_Depth(XPredict *InstancePtr);
u32 XPredict_Write_compact_data_5_Words(XPredict *InstancePtr, int offset, word_type *data, int length);
u32 XPredict_Read_compact_data_5_Words(XPredict *InstancePtr, int offset, word_type *data, int length);
u32 XPredict_Write_compact_data_5_Bytes(XPredict *InstancePtr, int offset, char *data, int length);
u32 XPredict_Read_compact_data_5_Bytes(XPredict *InstancePtr, int offset, char *data, int length);
u32 XPredict_Get_compact_data_6_BaseAddress(XPredict *InstancePtr);
u32 XPredict_Get_compact_data_6_HighAddress(XPredict *InstancePtr);
u32 XPredict_Get_compact_data_6_TotalBytes(XPredict *InstancePtr);
u32 XPredict_Get_compact_data_6_BitWidth(XPredict *InstancePtr);
u32 XPredict_Get_compact_data_6_Depth(XPredict *InstancePtr);
u32 XPredict_Write_compact_data_6_Words(XPredict *InstancePtr, int offset, word_type *data, int length);
u32 XPredict_Read_compact_data_6_Words(XPredict *InstancePtr, int offset, word_type *data, int length);
u32 XPredict_Write_compact_data_6_Bytes(XPredict *InstancePtr, int offset, char *data, int length);
u32 XPredict_Read_compact_data_6_Bytes(XPredict *InstancePtr, int offset, char *data, int length);
u32 XPredict_Get_compact_data_7_BaseAddress(XPredict *InstancePtr);
u32 XPredict_Get_compact_data_7_HighAddress(XPredict *InstancePtr);
u32 XPredict_Get_compact_data_7_TotalBytes(XPredict *InstancePtr);
u32 XPredict_Get_compact_data_7_BitWidth(XPredict *InstancePtr);
u32 XPredict_Get_compact_data_7_Depth(XPredict *InstancePtr);
u32 XPredict_Write_compact_data_7_Words(XPredict *InstancePtr, int offset, word_type *data, int length);
u32 XPredict_Read_compact_data_7_Words(XPredict *InstancePtr, int offset, word_type *data, int length);
u32 XPredict_Write_compact_data_7_Bytes(XPredict *InstancePtr, int offset, char *data, int length);
u32 XPredict_Read_compact_data_7_Bytes(XPredict *InstancePtr, int offset, char *data, int length);
u32 XPredict_Get_compact_data_8_BaseAddress(XPredict *InstancePtr);
u32 XPredict_Get_compact_data_8_HighAddress(XPredict *InstancePtr);
u32 XPredict_Get_compact_data_8_TotalBytes(XPredict *InstancePtr);
u32 XPredict_Get_compact_data_8_BitWidth(XPredict *InstancePtr);
u32 XPredict_Get_compact_data_8_Depth(XPredict *InstancePtr);
u32 XPredict_Write_compact_data_8_Words(XPredict *InstancePtr, int offset, word_type *data, int length);
u32 XPredict_Read_compact_data_8_Words(XPredict *InstancePtr, int offset, word_type *data, int length);
u32 XPredict_Write_compact_data_8_Bytes(XPredict *InstancePtr, int offset, char *data, int length);
u32 XPredict_Read_compact_data_8_Bytes(XPredict *InstancePtr, int offset, char *data, int length);
u32 XPredict_Get_compact_data_9_BaseAddress(XPredict *InstancePtr);
u32 XPredict_Get_compact_data_9_HighAddress(XPredict *InstancePtr);
u32 XPredict_Get_compact_data_9_TotalBytes(XPredict *InstancePtr);
u32 XPredict_Get_compact_data_9_BitWidth(XPredict *InstancePtr);
u32 XPredict_Get_compact_data_9_Depth(XPredict *InstancePtr);
u32 XPredict_Write_compact_data_9_Words(XPredict *InstancePtr, int offset, word_type *data, int length);
u32 XPredict_Read_compact_data_9_Words(XPredict *InstancePtr, int offset, word_type *data, int length);
u32 XPredict_Write_compact_data_9_Bytes(XPredict *InstancePtr, int offset, char *data, int length);
u32 XPredict_Read_compact_data_9_Bytes(XPredict *InstancePtr, int offset, char *data, int length);
u32 XPredict_Get_features_0_BaseAddress(XPredict *InstancePtr);
u32 XPredict_Get_features_0_HighAddress(XPredict *InstancePtr);
u32 XPredict_Get_features_0_TotalBytes(XPredict *InstancePtr);
u32 XPredict_Get_features_0_BitWidth(XPredict *InstancePtr);
u32 XPredict_Get_features_0_Depth(XPredict *InstancePtr);
u32 XPredict_Write_features_0_Words(XPredict *InstancePtr, int offset, word_type *data, int length);
u32 XPredict_Read_features_0_Words(XPredict *InstancePtr, int offset, word_type *data, int length);
u32 XPredict_Write_features_0_Bytes(XPredict *InstancePtr, int offset, char *data, int length);
u32 XPredict_Read_features_0_Bytes(XPredict *InstancePtr, int offset, char *data, int length);
u32 XPredict_Get_features_1_BaseAddress(XPredict *InstancePtr);
u32 XPredict_Get_features_1_HighAddress(XPredict *InstancePtr);
u32 XPredict_Get_features_1_TotalBytes(XPredict *InstancePtr);
u32 XPredict_Get_features_1_BitWidth(XPredict *InstancePtr);
u32 XPredict_Get_features_1_Depth(XPredict *InstancePtr);
u32 XPredict_Write_features_1_Words(XPredict *InstancePtr, int offset, word_type *data, int length);
u32 XPredict_Read_features_1_Words(XPredict *InstancePtr, int offset, word_type *data, int length);
u32 XPredict_Write_features_1_Bytes(XPredict *InstancePtr, int offset, char *data, int length);
u32 XPredict_Read_features_1_Bytes(XPredict *InstancePtr, int offset, char *data, int length);
u32 XPredict_Get_features_2_BaseAddress(XPredict *InstancePtr);
u32 XPredict_Get_features_2_HighAddress(XPredict *InstancePtr);
u32 XPredict_Get_features_2_TotalBytes(XPredict *InstancePtr);
u32 XPredict_Get_features_2_BitWidth(XPredict *InstancePtr);
u32 XPredict_Get_features_2_Depth(XPredict *InstancePtr);
u32 XPredict_Write_features_2_Words(XPredict *InstancePtr, int offset, word_type *data, int length);
u32 XPredict_Read_features_2_Words(XPredict *InstancePtr, int offset, word_type *data, int length);
u32 XPredict_Write_features_2_Bytes(XPredict *InstancePtr, int offset, char *data, int length);
u32 XPredict_Read_features_2_Bytes(XPredict *InstancePtr, int offset, char *data, int length);
u32 XPredict_Get_features_3_BaseAddress(XPredict *InstancePtr);
u32 XPredict_Get_features_3_HighAddress(XPredict *InstancePtr);
u32 XPredict_Get_features_3_TotalBytes(XPredict *InstancePtr);
u32 XPredict_Get_features_3_BitWidth(XPredict *InstancePtr);
u32 XPredict_Get_features_3_Depth(XPredict *InstancePtr);
u32 XPredict_Write_features_3_Words(XPredict *InstancePtr, int offset, word_type *data, int length);
u32 XPredict_Read_features_3_Words(XPredict *InstancePtr, int offset, word_type *data, int length);
u32 XPredict_Write_features_3_Bytes(XPredict *InstancePtr, int offset, char *data, int length);
u32 XPredict_Read_features_3_Bytes(XPredict *InstancePtr, int offset, char *data, int length);
u32 XPredict_Get_features_4_BaseAddress(XPredict *InstancePtr);
u32 XPredict_Get_features_4_HighAddress(XPredict *InstancePtr);
u32 XPredict_Get_features_4_TotalBytes(XPredict *InstancePtr);
u32 XPredict_Get_features_4_BitWidth(XPredict *InstancePtr);
u32 XPredict_Get_features_4_Depth(XPredict *InstancePtr);
u32 XPredict_Write_features_4_Words(XPredict *InstancePtr, int offset, word_type *data, int length);
u32 XPredict_Read_features_4_Words(XPredict *InstancePtr, int offset, word_type *data, int length);
u32 XPredict_Write_features_4_Bytes(XPredict *InstancePtr, int offset, char *data, int length);
u32 XPredict_Read_features_4_Bytes(XPredict *InstancePtr, int offset, char *data, int length);
u32 XPredict_Get_features_5_BaseAddress(XPredict *InstancePtr);
u32 XPredict_Get_features_5_HighAddress(XPredict *InstancePtr);
u32 XPredict_Get_features_5_TotalBytes(XPredict *InstancePtr);
u32 XPredict_Get_features_5_BitWidth(XPredict *InstancePtr);
u32 XPredict_Get_features_5_Depth(XPredict *InstancePtr);
u32 XPredict_Write_features_5_Words(XPredict *InstancePtr, int offset, word_type *data, int length);
u32 XPredict_Read_features_5_Words(XPredict *InstancePtr, int offset, word_type *data, int length);
u32 XPredict_Write_features_5_Bytes(XPredict *InstancePtr, int offset, char *data, int length);
u32 XPredict_Read_features_5_Bytes(XPredict *InstancePtr, int offset, char *data, int length);
u32 XPredict_Get_features_6_BaseAddress(XPredict *InstancePtr);
u32 XPredict_Get_features_6_HighAddress(XPredict *InstancePtr);
u32 XPredict_Get_features_6_TotalBytes(XPredict *InstancePtr);
u32 XPredict_Get_features_6_BitWidth(XPredict *InstancePtr);
u32 XPredict_Get_features_6_Depth(XPredict *InstancePtr);
u32 XPredict_Write_features_6_Words(XPredict *InstancePtr, int offset, word_type *data, int length);
u32 XPredict_Read_features_6_Words(XPredict *InstancePtr, int offset, word_type *data, int length);
u32 XPredict_Write_features_6_Bytes(XPredict *InstancePtr, int offset, char *data, int length);
u32 XPredict_Read_features_6_Bytes(XPredict *InstancePtr, int offset, char *data, int length);
u32 XPredict_Get_features_7_BaseAddress(XPredict *InstancePtr);
u32 XPredict_Get_features_7_HighAddress(XPredict *InstancePtr);
u32 XPredict_Get_features_7_TotalBytes(XPredict *InstancePtr);
u32 XPredict_Get_features_7_BitWidth(XPredict *InstancePtr);
u32 XPredict_Get_features_7_Depth(XPredict *InstancePtr);
u32 XPredict_Write_features_7_Words(XPredict *InstancePtr, int offset, word_type *data, int length);
u32 XPredict_Read_features_7_Words(XPredict *InstancePtr, int offset, word_type *data, int length);
u32 XPredict_Write_features_7_Bytes(XPredict *InstancePtr, int offset, char *data, int length);
u32 XPredict_Read_features_7_Bytes(XPredict *InstancePtr, int offset, char *data, int length);
u32 XPredict_Get_features_8_BaseAddress(XPredict *InstancePtr);
u32 XPredict_Get_features_8_HighAddress(XPredict *InstancePtr);
u32 XPredict_Get_features_8_TotalBytes(XPredict *InstancePtr);
u32 XPredict_Get_features_8_BitWidth(XPredict *InstancePtr);
u32 XPredict_Get_features_8_Depth(XPredict *InstancePtr);
u32 XPredict_Write_features_8_Words(XPredict *InstancePtr, int offset, word_type *data, int length);
u32 XPredict_Read_features_8_Words(XPredict *InstancePtr, int offset, word_type *data, int length);
u32 XPredict_Write_features_8_Bytes(XPredict *InstancePtr, int offset, char *data, int length);
u32 XPredict_Read_features_8_Bytes(XPredict *InstancePtr, int offset, char *data, int length);
u32 XPredict_Get_features_9_BaseAddress(XPredict *InstancePtr);
u32 XPredict_Get_features_9_HighAddress(XPredict *InstancePtr);
u32 XPredict_Get_features_9_TotalBytes(XPredict *InstancePtr);
u32 XPredict_Get_features_9_BitWidth(XPredict *InstancePtr);
u32 XPredict_Get_features_9_Depth(XPredict *InstancePtr);
u32 XPredict_Write_features_9_Words(XPredict *InstancePtr, int offset, word_type *data, int length);
u32 XPredict_Read_features_9_Words(XPredict *InstancePtr, int offset, word_type *data, int length);
u32 XPredict_Write_features_9_Bytes(XPredict *InstancePtr, int offset, char *data, int length);
u32 XPredict_Read_features_9_Bytes(XPredict *InstancePtr, int offset, char *data, int length);
u32 XPredict_Get_features_10_BaseAddress(XPredict *InstancePtr);
u32 XPredict_Get_features_10_HighAddress(XPredict *InstancePtr);
u32 XPredict_Get_features_10_TotalBytes(XPredict *InstancePtr);
u32 XPredict_Get_features_10_BitWidth(XPredict *InstancePtr);
u32 XPredict_Get_features_10_Depth(XPredict *InstancePtr);
u32 XPredict_Write_features_10_Words(XPredict *InstancePtr, int offset, word_type *data, int length);
u32 XPredict_Read_features_10_Words(XPredict *InstancePtr, int offset, word_type *data, int length);
u32 XPredict_Write_features_10_Bytes(XPredict *InstancePtr, int offset, char *data, int length);
u32 XPredict_Read_features_10_Bytes(XPredict *InstancePtr, int offset, char *data, int length);
u32 XPredict_Get_features_11_BaseAddress(XPredict *InstancePtr);
u32 XPredict_Get_features_11_HighAddress(XPredict *InstancePtr);
u32 XPredict_Get_features_11_TotalBytes(XPredict *InstancePtr);
u32 XPredict_Get_features_11_BitWidth(XPredict *InstancePtr);
u32 XPredict_Get_features_11_Depth(XPredict *InstancePtr);
u32 XPredict_Write_features_11_Words(XPredict *InstancePtr, int offset, word_type *data, int length);
u32 XPredict_Read_features_11_Words(XPredict *InstancePtr, int offset, word_type *data, int length);
u32 XPredict_Write_features_11_Bytes(XPredict *InstancePtr, int offset, char *data, int length);
u32 XPredict_Read_features_11_Bytes(XPredict *InstancePtr, int offset, char *data, int length);
u32 XPredict_Get_features_12_BaseAddress(XPredict *InstancePtr);
u32 XPredict_Get_features_12_HighAddress(XPredict *InstancePtr);
u32 XPredict_Get_features_12_TotalBytes(XPredict *InstancePtr);
u32 XPredict_Get_features_12_BitWidth(XPredict *InstancePtr);
u32 XPredict_Get_features_12_Depth(XPredict *InstancePtr);
u32 XPredict_Write_features_12_Words(XPredict *InstancePtr, int offset, word_type *data, int length);
u32 XPredict_Read_features_12_Words(XPredict *InstancePtr, int offset, word_type *data, int length);
u32 XPredict_Write_features_12_Bytes(XPredict *InstancePtr, int offset, char *data, int length);
u32 XPredict_Read_features_12_Bytes(XPredict *InstancePtr, int offset, char *data, int length);
u32 XPredict_Get_features_13_BaseAddress(XPredict *InstancePtr);
u32 XPredict_Get_features_13_HighAddress(XPredict *InstancePtr);
u32 XPredict_Get_features_13_TotalBytes(XPredict *InstancePtr);
u32 XPredict_Get_features_13_BitWidth(XPredict *InstancePtr);
u32 XPredict_Get_features_13_Depth(XPredict *InstancePtr);
u32 XPredict_Write_features_13_Words(XPredict *InstancePtr, int offset, word_type *data, int length);
u32 XPredict_Read_features_13_Words(XPredict *InstancePtr, int offset, word_type *data, int length);
u32 XPredict_Write_features_13_Bytes(XPredict *InstancePtr, int offset, char *data, int length);
u32 XPredict_Read_features_13_Bytes(XPredict *InstancePtr, int offset, char *data, int length);
u32 XPredict_Get_features_14_BaseAddress(XPredict *InstancePtr);
u32 XPredict_Get_features_14_HighAddress(XPredict *InstancePtr);
u32 XPredict_Get_features_14_TotalBytes(XPredict *InstancePtr);
u32 XPredict_Get_features_14_BitWidth(XPredict *InstancePtr);
u32 XPredict_Get_features_14_Depth(XPredict *InstancePtr);
u32 XPredict_Write_features_14_Words(XPredict *InstancePtr, int offset, word_type *data, int length);
u32 XPredict_Read_features_14_Words(XPredict *InstancePtr, int offset, word_type *data, int length);
u32 XPredict_Write_features_14_Bytes(XPredict *InstancePtr, int offset, char *data, int length);
u32 XPredict_Read_features_14_Bytes(XPredict *InstancePtr, int offset, char *data, int length);
u32 XPredict_Get_features_15_BaseAddress(XPredict *InstancePtr);
u32 XPredict_Get_features_15_HighAddress(XPredict *InstancePtr);
u32 XPredict_Get_features_15_TotalBytes(XPredict *InstancePtr);
u32 XPredict_Get_features_15_BitWidth(XPredict *InstancePtr);
u32 XPredict_Get_features_15_Depth(XPredict *InstancePtr);
u32 XPredict_Write_features_15_Words(XPredict *InstancePtr, int offset, word_type *data, int length);
u32 XPredict_Read_features_15_Words(XPredict *InstancePtr, int offset, word_type *data, int length);
u32 XPredict_Write_features_15_Bytes(XPredict *InstancePtr, int offset, char *data, int length);
u32 XPredict_Read_features_15_Bytes(XPredict *InstancePtr, int offset, char *data, int length);
u32 XPredict_Get_features_16_BaseAddress(XPredict *InstancePtr);
u32 XPredict_Get_features_16_HighAddress(XPredict *InstancePtr);
u32 XPredict_Get_features_16_TotalBytes(XPredict *InstancePtr);
u32 XPredict_Get_features_16_BitWidth(XPredict *InstancePtr);
u32 XPredict_Get_features_16_Depth(XPredict *InstancePtr);
u32 XPredict_Write_features_16_Words(XPredict *InstancePtr, int offset, word_type *data, int length);
u32 XPredict_Read_features_16_Words(XPredict *InstancePtr, int offset, word_type *data, int length);
u32 XPredict_Write_features_16_Bytes(XPredict *InstancePtr, int offset, char *data, int length);
u32 XPredict_Read_features_16_Bytes(XPredict *InstancePtr, int offset, char *data, int length);
u32 XPredict_Get_features_17_BaseAddress(XPredict *InstancePtr);
u32 XPredict_Get_features_17_HighAddress(XPredict *InstancePtr);
u32 XPredict_Get_features_17_TotalBytes(XPredict *InstancePtr);
u32 XPredict_Get_features_17_BitWidth(XPredict *InstancePtr);
u32 XPredict_Get_features_17_Depth(XPredict *InstancePtr);
u32 XPredict_Write_features_17_Words(XPredict *InstancePtr, int offset, word_type *data, int length);
u32 XPredict_Read_features_17_Words(XPredict *InstancePtr, int offset, word_type *data, int length);
u32 XPredict_Write_features_17_Bytes(XPredict *InstancePtr, int offset, char *data, int length);
u32 XPredict_Read_features_17_Bytes(XPredict *InstancePtr, int offset, char *data, int length);
u32 XPredict_Get_features_18_BaseAddress(XPredict *InstancePtr);
u32 XPredict_Get_features_18_HighAddress(XPredict *InstancePtr);
u32 XPredict_Get_features_18_TotalBytes(XPredict *InstancePtr);
u32 XPredict_Get_features_18_BitWidth(XPredict *InstancePtr);
u32 XPredict_Get_features_18_Depth(XPredict *InstancePtr);
u32 XPredict_Write_features_18_Words(XPredict *InstancePtr, int offset, word_type *data, int length);
u32 XPredict_Read_features_18_Words(XPredict *InstancePtr, int offset, word_type *data, int length);
u32 XPredict_Write_features_18_Bytes(XPredict *InstancePtr, int offset, char *data, int length);
u32 XPredict_Read_features_18_Bytes(XPredict *InstancePtr, int offset, char *data, int length);
u32 XPredict_Get_features_19_BaseAddress(XPredict *InstancePtr);
u32 XPredict_Get_features_19_HighAddress(XPredict *InstancePtr);
u32 XPredict_Get_features_19_TotalBytes(XPredict *InstancePtr);
u32 XPredict_Get_features_19_BitWidth(XPredict *InstancePtr);
u32 XPredict_Get_features_19_Depth(XPredict *InstancePtr);
u32 XPredict_Write_features_19_Words(XPredict *InstancePtr, int offset, word_type *data, int length);
u32 XPredict_Read_features_19_Words(XPredict *InstancePtr, int offset, word_type *data, int length);
u32 XPredict_Write_features_19_Bytes(XPredict *InstancePtr, int offset, char *data, int length);
u32 XPredict_Read_features_19_Bytes(XPredict *InstancePtr, int offset, char *data, int length);
u32 XPredict_Get_features_20_BaseAddress(XPredict *InstancePtr);
u32 XPredict_Get_features_20_HighAddress(XPredict *InstancePtr);
u32 XPredict_Get_features_20_TotalBytes(XPredict *InstancePtr);
u32 XPredict_Get_features_20_BitWidth(XPredict *InstancePtr);
u32 XPredict_Get_features_20_Depth(XPredict *InstancePtr);
u32 XPredict_Write_features_20_Words(XPredict *InstancePtr, int offset, word_type *data, int length);
u32 XPredict_Read_features_20_Words(XPredict *InstancePtr, int offset, word_type *data, int length);
u32 XPredict_Write_features_20_Bytes(XPredict *InstancePtr, int offset, char *data, int length);
u32 XPredict_Read_features_20_Bytes(XPredict *InstancePtr, int offset, char *data, int length);
u32 XPredict_Get_features_21_BaseAddress(XPredict *InstancePtr);
u32 XPredict_Get_features_21_HighAddress(XPredict *InstancePtr);
u32 XPredict_Get_features_21_TotalBytes(XPredict *InstancePtr);
u32 XPredict_Get_features_21_BitWidth(XPredict *InstancePtr);
u32 XPredict_Get_features_21_Depth(XPredict *InstancePtr);
u32 XPredict_Write_features_21_Words(XPredict *InstancePtr, int offset, word_type *data, int length);
u32 XPredict_Read_features_21_Words(XPredict *InstancePtr, int offset, word_type *data, int length);
u32 XPredict_Write_features_21_Bytes(XPredict *InstancePtr, int offset, char *data, int length);
u32 XPredict_Read_features_21_Bytes(XPredict *InstancePtr, int offset, char *data, int length);
u32 XPredict_Get_features_22_BaseAddress(XPredict *InstancePtr);
u32 XPredict_Get_features_22_HighAddress(XPredict *InstancePtr);
u32 XPredict_Get_features_22_TotalBytes(XPredict *InstancePtr);
u32 XPredict_Get_features_22_BitWidth(XPredict *InstancePtr);
u32 XPredict_Get_features_22_Depth(XPredict *InstancePtr);
u32 XPredict_Write_features_22_Words(XPredict *InstancePtr, int offset, word_type *data, int length);
u32 XPredict_Read_features_22_Words(XPredict *InstancePtr, int offset, word_type *data, int length);
u32 XPredict_Write_features_22_Bytes(XPredict *InstancePtr, int offset, char *data, int length);
u32 XPredict_Read_features_22_Bytes(XPredict *InstancePtr, int offset, char *data, int length);
u32 XPredict_Get_features_23_BaseAddress(XPredict *InstancePtr);
u32 XPredict_Get_features_23_HighAddress(XPredict *InstancePtr);
u32 XPredict_Get_features_23_TotalBytes(XPredict *InstancePtr);
u32 XPredict_Get_features_23_BitWidth(XPredict *InstancePtr);
u32 XPredict_Get_features_23_Depth(XPredict *InstancePtr);
u32 XPredict_Write_features_23_Words(XPredict *InstancePtr, int offset, word_type *data, int length);
u32 XPredict_Read_features_23_Words(XPredict *InstancePtr, int offset, word_type *data, int length);
u32 XPredict_Write_features_23_Bytes(XPredict *InstancePtr, int offset, char *data, int length);
u32 XPredict_Read_features_23_Bytes(XPredict *InstancePtr, int offset, char *data, int length);
u32 XPredict_Get_features_24_BaseAddress(XPredict *InstancePtr);
u32 XPredict_Get_features_24_HighAddress(XPredict *InstancePtr);
u32 XPredict_Get_features_24_TotalBytes(XPredict *InstancePtr);
u32 XPredict_Get_features_24_BitWidth(XPredict *InstancePtr);
u32 XPredict_Get_features_24_Depth(XPredict *InstancePtr);
u32 XPredict_Write_features_24_Words(XPredict *InstancePtr, int offset, word_type *data, int length);
u32 XPredict_Read_features_24_Words(XPredict *InstancePtr, int offset, word_type *data, int length);
u32 XPredict_Write_features_24_Bytes(XPredict *InstancePtr, int offset, char *data, int length);
u32 XPredict_Read_features_24_Bytes(XPredict *InstancePtr, int offset, char *data, int length);
u32 XPredict_Get_next_node_right_index_0_BaseAddress(XPredict *InstancePtr);
u32 XPredict_Get_next_node_right_index_0_HighAddress(XPredict *InstancePtr);
u32 XPredict_Get_next_node_right_index_0_TotalBytes(XPredict *InstancePtr);
u32 XPredict_Get_next_node_right_index_0_BitWidth(XPredict *InstancePtr);
u32 XPredict_Get_next_node_right_index_0_Depth(XPredict *InstancePtr);
u32 XPredict_Write_next_node_right_index_0_Words(XPredict *InstancePtr, int offset, word_type *data, int length);
u32 XPredict_Read_next_node_right_index_0_Words(XPredict *InstancePtr, int offset, word_type *data, int length);
u32 XPredict_Write_next_node_right_index_0_Bytes(XPredict *InstancePtr, int offset, char *data, int length);
u32 XPredict_Read_next_node_right_index_0_Bytes(XPredict *InstancePtr, int offset, char *data, int length);
u32 XPredict_Get_next_node_right_index_1_BaseAddress(XPredict *InstancePtr);
u32 XPredict_Get_next_node_right_index_1_HighAddress(XPredict *InstancePtr);
u32 XPredict_Get_next_node_right_index_1_TotalBytes(XPredict *InstancePtr);
u32 XPredict_Get_next_node_right_index_1_BitWidth(XPredict *InstancePtr);
u32 XPredict_Get_next_node_right_index_1_Depth(XPredict *InstancePtr);
u32 XPredict_Write_next_node_right_index_1_Words(XPredict *InstancePtr, int offset, word_type *data, int length);
u32 XPredict_Read_next_node_right_index_1_Words(XPredict *InstancePtr, int offset, word_type *data, int length);
u32 XPredict_Write_next_node_right_index_1_Bytes(XPredict *InstancePtr, int offset, char *data, int length);
u32 XPredict_Read_next_node_right_index_1_Bytes(XPredict *InstancePtr, int offset, char *data, int length);
u32 XPredict_Get_next_node_right_index_2_BaseAddress(XPredict *InstancePtr);
u32 XPredict_Get_next_node_right_index_2_HighAddress(XPredict *InstancePtr);
u32 XPredict_Get_next_node_right_index_2_TotalBytes(XPredict *InstancePtr);
u32 XPredict_Get_next_node_right_index_2_BitWidth(XPredict *InstancePtr);
u32 XPredict_Get_next_node_right_index_2_Depth(XPredict *InstancePtr);
u32 XPredict_Write_next_node_right_index_2_Words(XPredict *InstancePtr, int offset, word_type *data, int length);
u32 XPredict_Read_next_node_right_index_2_Words(XPredict *InstancePtr, int offset, word_type *data, int length);
u32 XPredict_Write_next_node_right_index_2_Bytes(XPredict *InstancePtr, int offset, char *data, int length);
u32 XPredict_Read_next_node_right_index_2_Bytes(XPredict *InstancePtr, int offset, char *data, int length);
u32 XPredict_Get_next_node_right_index_3_BaseAddress(XPredict *InstancePtr);
u32 XPredict_Get_next_node_right_index_3_HighAddress(XPredict *InstancePtr);
u32 XPredict_Get_next_node_right_index_3_TotalBytes(XPredict *InstancePtr);
u32 XPredict_Get_next_node_right_index_3_BitWidth(XPredict *InstancePtr);
u32 XPredict_Get_next_node_right_index_3_Depth(XPredict *InstancePtr);
u32 XPredict_Write_next_node_right_index_3_Words(XPredict *InstancePtr, int offset, word_type *data, int length);
u32 XPredict_Read_next_node_right_index_3_Words(XPredict *InstancePtr, int offset, word_type *data, int length);
u32 XPredict_Write_next_node_right_index_3_Bytes(XPredict *InstancePtr, int offset, char *data, int length);
u32 XPredict_Read_next_node_right_index_3_Bytes(XPredict *InstancePtr, int offset, char *data, int length);
u32 XPredict_Get_next_node_right_index_4_BaseAddress(XPredict *InstancePtr);
u32 XPredict_Get_next_node_right_index_4_HighAddress(XPredict *InstancePtr);
u32 XPredict_Get_next_node_right_index_4_TotalBytes(XPredict *InstancePtr);
u32 XPredict_Get_next_node_right_index_4_BitWidth(XPredict *InstancePtr);
u32 XPredict_Get_next_node_right_index_4_Depth(XPredict *InstancePtr);
u32 XPredict_Write_next_node_right_index_4_Words(XPredict *InstancePtr, int offset, word_type *data, int length);
u32 XPredict_Read_next_node_right_index_4_Words(XPredict *InstancePtr, int offset, word_type *data, int length);
u32 XPredict_Write_next_node_right_index_4_Bytes(XPredict *InstancePtr, int offset, char *data, int length);
u32 XPredict_Read_next_node_right_index_4_Bytes(XPredict *InstancePtr, int offset, char *data, int length);
u32 XPredict_Get_next_node_right_index_5_BaseAddress(XPredict *InstancePtr);
u32 XPredict_Get_next_node_right_index_5_HighAddress(XPredict *InstancePtr);
u32 XPredict_Get_next_node_right_index_5_TotalBytes(XPredict *InstancePtr);
u32 XPredict_Get_next_node_right_index_5_BitWidth(XPredict *InstancePtr);
u32 XPredict_Get_next_node_right_index_5_Depth(XPredict *InstancePtr);
u32 XPredict_Write_next_node_right_index_5_Words(XPredict *InstancePtr, int offset, word_type *data, int length);
u32 XPredict_Read_next_node_right_index_5_Words(XPredict *InstancePtr, int offset, word_type *data, int length);
u32 XPredict_Write_next_node_right_index_5_Bytes(XPredict *InstancePtr, int offset, char *data, int length);
u32 XPredict_Read_next_node_right_index_5_Bytes(XPredict *InstancePtr, int offset, char *data, int length);
u32 XPredict_Get_next_node_right_index_6_BaseAddress(XPredict *InstancePtr);
u32 XPredict_Get_next_node_right_index_6_HighAddress(XPredict *InstancePtr);
u32 XPredict_Get_next_node_right_index_6_TotalBytes(XPredict *InstancePtr);
u32 XPredict_Get_next_node_right_index_6_BitWidth(XPredict *InstancePtr);
u32 XPredict_Get_next_node_right_index_6_Depth(XPredict *InstancePtr);
u32 XPredict_Write_next_node_right_index_6_Words(XPredict *InstancePtr, int offset, word_type *data, int length);
u32 XPredict_Read_next_node_right_index_6_Words(XPredict *InstancePtr, int offset, word_type *data, int length);
u32 XPredict_Write_next_node_right_index_6_Bytes(XPredict *InstancePtr, int offset, char *data, int length);
u32 XPredict_Read_next_node_right_index_6_Bytes(XPredict *InstancePtr, int offset, char *data, int length);
u32 XPredict_Get_next_node_right_index_7_BaseAddress(XPredict *InstancePtr);
u32 XPredict_Get_next_node_right_index_7_HighAddress(XPredict *InstancePtr);
u32 XPredict_Get_next_node_right_index_7_TotalBytes(XPredict *InstancePtr);
u32 XPredict_Get_next_node_right_index_7_BitWidth(XPredict *InstancePtr);
u32 XPredict_Get_next_node_right_index_7_Depth(XPredict *InstancePtr);
u32 XPredict_Write_next_node_right_index_7_Words(XPredict *InstancePtr, int offset, word_type *data, int length);
u32 XPredict_Read_next_node_right_index_7_Words(XPredict *InstancePtr, int offset, word_type *data, int length);
u32 XPredict_Write_next_node_right_index_7_Bytes(XPredict *InstancePtr, int offset, char *data, int length);
u32 XPredict_Read_next_node_right_index_7_Bytes(XPredict *InstancePtr, int offset, char *data, int length);
u32 XPredict_Get_next_node_right_index_8_BaseAddress(XPredict *InstancePtr);
u32 XPredict_Get_next_node_right_index_8_HighAddress(XPredict *InstancePtr);
u32 XPredict_Get_next_node_right_index_8_TotalBytes(XPredict *InstancePtr);
u32 XPredict_Get_next_node_right_index_8_BitWidth(XPredict *InstancePtr);
u32 XPredict_Get_next_node_right_index_8_Depth(XPredict *InstancePtr);
u32 XPredict_Write_next_node_right_index_8_Words(XPredict *InstancePtr, int offset, word_type *data, int length);
u32 XPredict_Read_next_node_right_index_8_Words(XPredict *InstancePtr, int offset, word_type *data, int length);
u32 XPredict_Write_next_node_right_index_8_Bytes(XPredict *InstancePtr, int offset, char *data, int length);
u32 XPredict_Read_next_node_right_index_8_Bytes(XPredict *InstancePtr, int offset, char *data, int length);
u32 XPredict_Get_next_node_right_index_9_BaseAddress(XPredict *InstancePtr);
u32 XPredict_Get_next_node_right_index_9_HighAddress(XPredict *InstancePtr);
u32 XPredict_Get_next_node_right_index_9_TotalBytes(XPredict *InstancePtr);
u32 XPredict_Get_next_node_right_index_9_BitWidth(XPredict *InstancePtr);
u32 XPredict_Get_next_node_right_index_9_Depth(XPredict *InstancePtr);
u32 XPredict_Write_next_node_right_index_9_Words(XPredict *InstancePtr, int offset, word_type *data, int length);
u32 XPredict_Read_next_node_right_index_9_Words(XPredict *InstancePtr, int offset, word_type *data, int length);
u32 XPredict_Write_next_node_right_index_9_Bytes(XPredict *InstancePtr, int offset, char *data, int length);
u32 XPredict_Read_next_node_right_index_9_Bytes(XPredict *InstancePtr, int offset, char *data, int length);
u32 XPredict_Get_node_leaf_value_0_BaseAddress(XPredict *InstancePtr);
u32 XPredict_Get_node_leaf_value_0_HighAddress(XPredict *InstancePtr);
u32 XPredict_Get_node_leaf_value_0_TotalBytes(XPredict *InstancePtr);
u32 XPredict_Get_node_leaf_value_0_BitWidth(XPredict *InstancePtr);
u32 XPredict_Get_node_leaf_value_0_Depth(XPredict *InstancePtr);
u32 XPredict_Write_node_leaf_value_0_Words(XPredict *InstancePtr, int offset, word_type *data, int length);
u32 XPredict_Read_node_leaf_value_0_Words(XPredict *InstancePtr, int offset, word_type *data, int length);
u32 XPredict_Write_node_leaf_value_0_Bytes(XPredict *InstancePtr, int offset, char *data, int length);
u32 XPredict_Read_node_leaf_value_0_Bytes(XPredict *InstancePtr, int offset, char *data, int length);
u32 XPredict_Get_node_leaf_value_1_BaseAddress(XPredict *InstancePtr);
u32 XPredict_Get_node_leaf_value_1_HighAddress(XPredict *InstancePtr);
u32 XPredict_Get_node_leaf_value_1_TotalBytes(XPredict *InstancePtr);
u32 XPredict_Get_node_leaf_value_1_BitWidth(XPredict *InstancePtr);
u32 XPredict_Get_node_leaf_value_1_Depth(XPredict *InstancePtr);
u32 XPredict_Write_node_leaf_value_1_Words(XPredict *InstancePtr, int offset, word_type *data, int length);
u32 XPredict_Read_node_leaf_value_1_Words(XPredict *InstancePtr, int offset, word_type *data, int length);
u32 XPredict_Write_node_leaf_value_1_Bytes(XPredict *InstancePtr, int offset, char *data, int length);
u32 XPredict_Read_node_leaf_value_1_Bytes(XPredict *InstancePtr, int offset, char *data, int length);
u32 XPredict_Get_node_leaf_value_2_BaseAddress(XPredict *InstancePtr);
u32 XPredict_Get_node_leaf_value_2_HighAddress(XPredict *InstancePtr);
u32 XPredict_Get_node_leaf_value_2_TotalBytes(XPredict *InstancePtr);
u32 XPredict_Get_node_leaf_value_2_BitWidth(XPredict *InstancePtr);
u32 XPredict_Get_node_leaf_value_2_Depth(XPredict *InstancePtr);
u32 XPredict_Write_node_leaf_value_2_Words(XPredict *InstancePtr, int offset, word_type *data, int length);
u32 XPredict_Read_node_leaf_value_2_Words(XPredict *InstancePtr, int offset, word_type *data, int length);
u32 XPredict_Write_node_leaf_value_2_Bytes(XPredict *InstancePtr, int offset, char *data, int length);
u32 XPredict_Read_node_leaf_value_2_Bytes(XPredict *InstancePtr, int offset, char *data, int length);
u32 XPredict_Get_node_leaf_value_3_BaseAddress(XPredict *InstancePtr);
u32 XPredict_Get_node_leaf_value_3_HighAddress(XPredict *InstancePtr);
u32 XPredict_Get_node_leaf_value_3_TotalBytes(XPredict *InstancePtr);
u32 XPredict_Get_node_leaf_value_3_BitWidth(XPredict *InstancePtr);
u32 XPredict_Get_node_leaf_value_3_Depth(XPredict *InstancePtr);
u32 XPredict_Write_node_leaf_value_3_Words(XPredict *InstancePtr, int offset, word_type *data, int length);
u32 XPredict_Read_node_leaf_value_3_Words(XPredict *InstancePtr, int offset, word_type *data, int length);
u32 XPredict_Write_node_leaf_value_3_Bytes(XPredict *InstancePtr, int offset, char *data, int length);
u32 XPredict_Read_node_leaf_value_3_Bytes(XPredict *InstancePtr, int offset, char *data, int length);
u32 XPredict_Get_node_leaf_value_4_BaseAddress(XPredict *InstancePtr);
u32 XPredict_Get_node_leaf_value_4_HighAddress(XPredict *InstancePtr);
u32 XPredict_Get_node_leaf_value_4_TotalBytes(XPredict *InstancePtr);
u32 XPredict_Get_node_leaf_value_4_BitWidth(XPredict *InstancePtr);
u32 XPredict_Get_node_leaf_value_4_Depth(XPredict *InstancePtr);
u32 XPredict_Write_node_leaf_value_4_Words(XPredict *InstancePtr, int offset, word_type *data, int length);
u32 XPredict_Read_node_leaf_value_4_Words(XPredict *InstancePtr, int offset, word_type *data, int length);
u32 XPredict_Write_node_leaf_value_4_Bytes(XPredict *InstancePtr, int offset, char *data, int length);
u32 XPredict_Read_node_leaf_value_4_Bytes(XPredict *InstancePtr, int offset, char *data, int length);
u32 XPredict_Get_node_leaf_value_5_BaseAddress(XPredict *InstancePtr);
u32 XPredict_Get_node_leaf_value_5_HighAddress(XPredict *InstancePtr);
u32 XPredict_Get_node_leaf_value_5_TotalBytes(XPredict *InstancePtr);
u32 XPredict_Get_node_leaf_value_5_BitWidth(XPredict *InstancePtr);
u32 XPredict_Get_node_leaf_value_5_Depth(XPredict *InstancePtr);
u32 XPredict_Write_node_leaf_value_5_Words(XPredict *InstancePtr, int offset, word_type *data, int length);
u32 XPredict_Read_node_leaf_value_5_Words(XPredict *InstancePtr, int offset, word_type *data, int length);
u32 XPredict_Write_node_leaf_value_5_Bytes(XPredict *InstancePtr, int offset, char *data, int length);
u32 XPredict_Read_node_leaf_value_5_Bytes(XPredict *InstancePtr, int offset, char *data, int length);
u32 XPredict_Get_node_leaf_value_6_BaseAddress(XPredict *InstancePtr);
u32 XPredict_Get_node_leaf_value_6_HighAddress(XPredict *InstancePtr);
u32 XPredict_Get_node_leaf_value_6_TotalBytes(XPredict *InstancePtr);
u32 XPredict_Get_node_leaf_value_6_BitWidth(XPredict *InstancePtr);
u32 XPredict_Get_node_leaf_value_6_Depth(XPredict *InstancePtr);
u32 XPredict_Write_node_leaf_value_6_Words(XPredict *InstancePtr, int offset, word_type *data, int length);
u32 XPredict_Read_node_leaf_value_6_Words(XPredict *InstancePtr, int offset, word_type *data, int length);
u32 XPredict_Write_node_leaf_value_6_Bytes(XPredict *InstancePtr, int offset, char *data, int length);
u32 XPredict_Read_node_leaf_value_6_Bytes(XPredict *InstancePtr, int offset, char *data, int length);
u32 XPredict_Get_node_leaf_value_7_BaseAddress(XPredict *InstancePtr);
u32 XPredict_Get_node_leaf_value_7_HighAddress(XPredict *InstancePtr);
u32 XPredict_Get_node_leaf_value_7_TotalBytes(XPredict *InstancePtr);
u32 XPredict_Get_node_leaf_value_7_BitWidth(XPredict *InstancePtr);
u32 XPredict_Get_node_leaf_value_7_Depth(XPredict *InstancePtr);
u32 XPredict_Write_node_leaf_value_7_Words(XPredict *InstancePtr, int offset, word_type *data, int length);
u32 XPredict_Read_node_leaf_value_7_Words(XPredict *InstancePtr, int offset, word_type *data, int length);
u32 XPredict_Write_node_leaf_value_7_Bytes(XPredict *InstancePtr, int offset, char *data, int length);
u32 XPredict_Read_node_leaf_value_7_Bytes(XPredict *InstancePtr, int offset, char *data, int length);
u32 XPredict_Get_node_leaf_value_8_BaseAddress(XPredict *InstancePtr);
u32 XPredict_Get_node_leaf_value_8_HighAddress(XPredict *InstancePtr);
u32 XPredict_Get_node_leaf_value_8_TotalBytes(XPredict *InstancePtr);
u32 XPredict_Get_node_leaf_value_8_BitWidth(XPredict *InstancePtr);
u32 XPredict_Get_node_leaf_value_8_Depth(XPredict *InstancePtr);
u32 XPredict_Write_node_leaf_value_8_Words(XPredict *InstancePtr, int offset, word_type *data, int length);
u32 XPredict_Read_node_leaf_value_8_Words(XPredict *InstancePtr, int offset, word_type *data, int length);
u32 XPredict_Write_node_leaf_value_8_Bytes(XPredict *InstancePtr, int offset, char *data, int length);
u32 XPredict_Read_node_leaf_value_8_Bytes(XPredict *InstancePtr, int offset, char *data, int length);
u32 XPredict_Get_node_leaf_value_9_BaseAddress(XPredict *InstancePtr);
u32 XPredict_Get_node_leaf_value_9_HighAddress(XPredict *InstancePtr);
u32 XPredict_Get_node_leaf_value_9_TotalBytes(XPredict *InstancePtr);
u32 XPredict_Get_node_leaf_value_9_BitWidth(XPredict *InstancePtr);
u32 XPredict_Get_node_leaf_value_9_Depth(XPredict *InstancePtr);
u32 XPredict_Write_node_leaf_value_9_Words(XPredict *InstancePtr, int offset, word_type *data, int length);
u32 XPredict_Read_node_leaf_value_9_Words(XPredict *InstancePtr, int offset, word_type *data, int length);
u32 XPredict_Write_node_leaf_value_9_Bytes(XPredict *InstancePtr, int offset, char *data, int length);
u32 XPredict_Read_node_leaf_value_9_Bytes(XPredict *InstancePtr, int offset, char *data, int length);

void XPredict_InterruptGlobalEnable(XPredict *InstancePtr);
void XPredict_InterruptGlobalDisable(XPredict *InstancePtr);
void XPredict_InterruptEnable(XPredict *InstancePtr, u32 Mask);
void XPredict_InterruptDisable(XPredict *InstancePtr, u32 Mask);
void XPredict_InterruptClear(XPredict *InstancePtr, u32 Mask);
u32 XPredict_InterruptGetEnabled(XPredict *InstancePtr);
u32 XPredict_InterruptGetStatus(XPredict *InstancePtr);

#ifdef __cplusplus
}
#endif

#endif
