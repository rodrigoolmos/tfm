// ==============================================================
// Vitis HLS - High-Level Synthesis from C, C++ and OpenCL v2023.1.1 (64-bit)
// Tool Version Limit: 2023.06
// Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
// Copyright 2022-2023 Advanced Micro Devices, Inc. All Rights Reserved.
// 
// ==============================================================
/***************************** Include Files *********************************/
#include "xpredict.h"

/************************** Function Implementation *************************/
#ifndef __linux__
int XPredict_CfgInitialize(XPredict *InstancePtr, XPredict_Config *ConfigPtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(ConfigPtr != NULL);

    InstancePtr->Compact_data_BaseAddress = ConfigPtr->Compact_data_BaseAddress;
    InstancePtr->Features_BaseAddress = ConfigPtr->Features_BaseAddress;
    InstancePtr->Next_node_right_index_BaseAddress = ConfigPtr->Next_node_right_index_BaseAddress;
    InstancePtr->Node_leaf_value_BaseAddress = ConfigPtr->Node_leaf_value_BaseAddress;
    InstancePtr->Prediction_BaseAddress = ConfigPtr->Prediction_BaseAddress;
    InstancePtr->Results_BaseAddress = ConfigPtr->Results_BaseAddress;
    InstancePtr->IsReady = XIL_COMPONENT_IS_READY;

    return XST_SUCCESS;
}
#endif

void XPredict_Start(XPredict *InstancePtr) {
    u32 Data;

    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XPredict_ReadReg(InstancePtr->Results_BaseAddress, XPREDICT_RESULTS_ADDR_AP_CTRL) & 0x80;
    XPredict_WriteReg(InstancePtr->Results_BaseAddress, XPREDICT_RESULTS_ADDR_AP_CTRL, Data | 0x01);
}

u32 XPredict_IsDone(XPredict *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XPredict_ReadReg(InstancePtr->Results_BaseAddress, XPREDICT_RESULTS_ADDR_AP_CTRL);
    return (Data >> 1) & 0x1;
}

u32 XPredict_IsIdle(XPredict *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XPredict_ReadReg(InstancePtr->Results_BaseAddress, XPREDICT_RESULTS_ADDR_AP_CTRL);
    return (Data >> 2) & 0x1;
}

u32 XPredict_IsReady(XPredict *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XPredict_ReadReg(InstancePtr->Results_BaseAddress, XPREDICT_RESULTS_ADDR_AP_CTRL);
    // check ap_start to see if the pcore is ready for next input
    return !(Data & 0x1);
}

void XPredict_EnableAutoRestart(XPredict *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XPredict_WriteReg(InstancePtr->Results_BaseAddress, XPREDICT_RESULTS_ADDR_AP_CTRL, 0x80);
}

void XPredict_DisableAutoRestart(XPredict *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XPredict_WriteReg(InstancePtr->Results_BaseAddress, XPREDICT_RESULTS_ADDR_AP_CTRL, 0);
}

u32 XPredict_Get_prediction(XPredict *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XPredict_ReadReg(InstancePtr->Prediction_BaseAddress, XPREDICT_PREDICTION_ADDR_PREDICTION_DATA);
    return Data;
}

u32 XPredict_Get_prediction_vld(XPredict *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XPredict_ReadReg(InstancePtr->Prediction_BaseAddress, XPREDICT_PREDICTION_ADDR_PREDICTION_CTRL);
    return Data & 0x1;
}

u32 XPredict_Get_compact_data_BaseAddress(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (InstancePtr->Compact_data_BaseAddress + XPREDICT_COMPACT_DATA_ADDR_COMPACT_DATA_BASE);
}

u32 XPredict_Get_compact_data_HighAddress(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (InstancePtr->Compact_data_BaseAddress + XPREDICT_COMPACT_DATA_ADDR_COMPACT_DATA_HIGH);
}

u32 XPredict_Get_compact_data_TotalBytes(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (XPREDICT_COMPACT_DATA_ADDR_COMPACT_DATA_HIGH - XPREDICT_COMPACT_DATA_ADDR_COMPACT_DATA_BASE + 1);
}

u32 XPredict_Get_compact_data_BitWidth(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XPREDICT_COMPACT_DATA_WIDTH_COMPACT_DATA;
}

u32 XPredict_Get_compact_data_Depth(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XPREDICT_COMPACT_DATA_DEPTH_COMPACT_DATA;
}

u32 XPredict_Write_compact_data_Words(XPredict *InstancePtr, int offset, word_type *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length)*4 > (XPREDICT_COMPACT_DATA_ADDR_COMPACT_DATA_HIGH - XPREDICT_COMPACT_DATA_ADDR_COMPACT_DATA_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(int *)(InstancePtr->Compact_data_BaseAddress + XPREDICT_COMPACT_DATA_ADDR_COMPACT_DATA_BASE + (offset + i)*4) = *(data + i);
    }
    return length;
}

u32 XPredict_Read_compact_data_Words(XPredict *InstancePtr, int offset, word_type *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length)*4 > (XPREDICT_COMPACT_DATA_ADDR_COMPACT_DATA_HIGH - XPREDICT_COMPACT_DATA_ADDR_COMPACT_DATA_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(data + i) = *(int *)(InstancePtr->Compact_data_BaseAddress + XPREDICT_COMPACT_DATA_ADDR_COMPACT_DATA_BASE + (offset + i)*4);
    }
    return length;
}

u32 XPredict_Write_compact_data_Bytes(XPredict *InstancePtr, int offset, char *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length) > (XPREDICT_COMPACT_DATA_ADDR_COMPACT_DATA_HIGH - XPREDICT_COMPACT_DATA_ADDR_COMPACT_DATA_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(char *)(InstancePtr->Compact_data_BaseAddress + XPREDICT_COMPACT_DATA_ADDR_COMPACT_DATA_BASE + offset + i) = *(data + i);
    }
    return length;
}

u32 XPredict_Read_compact_data_Bytes(XPredict *InstancePtr, int offset, char *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length) > (XPREDICT_COMPACT_DATA_ADDR_COMPACT_DATA_HIGH - XPREDICT_COMPACT_DATA_ADDR_COMPACT_DATA_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(data + i) = *(char *)(InstancePtr->Compact_data_BaseAddress + XPREDICT_COMPACT_DATA_ADDR_COMPACT_DATA_BASE + offset + i);
    }
    return length;
}

u32 XPredict_Get_features_BaseAddress(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (InstancePtr->Features_BaseAddress + XPREDICT_FEATURES_ADDR_FEATURES_BASE);
}

u32 XPredict_Get_features_HighAddress(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (InstancePtr->Features_BaseAddress + XPREDICT_FEATURES_ADDR_FEATURES_HIGH);
}

u32 XPredict_Get_features_TotalBytes(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (XPREDICT_FEATURES_ADDR_FEATURES_HIGH - XPREDICT_FEATURES_ADDR_FEATURES_BASE + 1);
}

u32 XPredict_Get_features_BitWidth(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XPREDICT_FEATURES_WIDTH_FEATURES;
}

u32 XPredict_Get_features_Depth(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XPREDICT_FEATURES_DEPTH_FEATURES;
}

u32 XPredict_Write_features_Words(XPredict *InstancePtr, int offset, word_type *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length)*4 > (XPREDICT_FEATURES_ADDR_FEATURES_HIGH - XPREDICT_FEATURES_ADDR_FEATURES_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(int *)(InstancePtr->Features_BaseAddress + XPREDICT_FEATURES_ADDR_FEATURES_BASE + (offset + i)*4) = *(data + i);
    }
    return length;
}

u32 XPredict_Read_features_Words(XPredict *InstancePtr, int offset, word_type *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length)*4 > (XPREDICT_FEATURES_ADDR_FEATURES_HIGH - XPREDICT_FEATURES_ADDR_FEATURES_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(data + i) = *(int *)(InstancePtr->Features_BaseAddress + XPREDICT_FEATURES_ADDR_FEATURES_BASE + (offset + i)*4);
    }
    return length;
}

u32 XPredict_Write_features_Bytes(XPredict *InstancePtr, int offset, char *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length) > (XPREDICT_FEATURES_ADDR_FEATURES_HIGH - XPREDICT_FEATURES_ADDR_FEATURES_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(char *)(InstancePtr->Features_BaseAddress + XPREDICT_FEATURES_ADDR_FEATURES_BASE + offset + i) = *(data + i);
    }
    return length;
}

u32 XPredict_Read_features_Bytes(XPredict *InstancePtr, int offset, char *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length) > (XPREDICT_FEATURES_ADDR_FEATURES_HIGH - XPREDICT_FEATURES_ADDR_FEATURES_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(data + i) = *(char *)(InstancePtr->Features_BaseAddress + XPREDICT_FEATURES_ADDR_FEATURES_BASE + offset + i);
    }
    return length;
}

u32 XPredict_Get_next_node_right_index_BaseAddress(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (InstancePtr->Next_node_right_index_BaseAddress + XPREDICT_NEXT_NODE_RIGHT_INDEX_ADDR_NEXT_NODE_RIGHT_INDEX_BASE);
}

u32 XPredict_Get_next_node_right_index_HighAddress(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (InstancePtr->Next_node_right_index_BaseAddress + XPREDICT_NEXT_NODE_RIGHT_INDEX_ADDR_NEXT_NODE_RIGHT_INDEX_HIGH);
}

u32 XPredict_Get_next_node_right_index_TotalBytes(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (XPREDICT_NEXT_NODE_RIGHT_INDEX_ADDR_NEXT_NODE_RIGHT_INDEX_HIGH - XPREDICT_NEXT_NODE_RIGHT_INDEX_ADDR_NEXT_NODE_RIGHT_INDEX_BASE + 1);
}

u32 XPredict_Get_next_node_right_index_BitWidth(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XPREDICT_NEXT_NODE_RIGHT_INDEX_WIDTH_NEXT_NODE_RIGHT_INDEX;
}

u32 XPredict_Get_next_node_right_index_Depth(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XPREDICT_NEXT_NODE_RIGHT_INDEX_DEPTH_NEXT_NODE_RIGHT_INDEX;
}

u32 XPredict_Write_next_node_right_index_Words(XPredict *InstancePtr, int offset, word_type *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length)*4 > (XPREDICT_NEXT_NODE_RIGHT_INDEX_ADDR_NEXT_NODE_RIGHT_INDEX_HIGH - XPREDICT_NEXT_NODE_RIGHT_INDEX_ADDR_NEXT_NODE_RIGHT_INDEX_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(int *)(InstancePtr->Next_node_right_index_BaseAddress + XPREDICT_NEXT_NODE_RIGHT_INDEX_ADDR_NEXT_NODE_RIGHT_INDEX_BASE + (offset + i)*4) = *(data + i);
    }
    return length;
}

u32 XPredict_Read_next_node_right_index_Words(XPredict *InstancePtr, int offset, word_type *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length)*4 > (XPREDICT_NEXT_NODE_RIGHT_INDEX_ADDR_NEXT_NODE_RIGHT_INDEX_HIGH - XPREDICT_NEXT_NODE_RIGHT_INDEX_ADDR_NEXT_NODE_RIGHT_INDEX_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(data + i) = *(int *)(InstancePtr->Next_node_right_index_BaseAddress + XPREDICT_NEXT_NODE_RIGHT_INDEX_ADDR_NEXT_NODE_RIGHT_INDEX_BASE + (offset + i)*4);
    }
    return length;
}

u32 XPredict_Write_next_node_right_index_Bytes(XPredict *InstancePtr, int offset, char *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length) > (XPREDICT_NEXT_NODE_RIGHT_INDEX_ADDR_NEXT_NODE_RIGHT_INDEX_HIGH - XPREDICT_NEXT_NODE_RIGHT_INDEX_ADDR_NEXT_NODE_RIGHT_INDEX_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(char *)(InstancePtr->Next_node_right_index_BaseAddress + XPREDICT_NEXT_NODE_RIGHT_INDEX_ADDR_NEXT_NODE_RIGHT_INDEX_BASE + offset + i) = *(data + i);
    }
    return length;
}

u32 XPredict_Read_next_node_right_index_Bytes(XPredict *InstancePtr, int offset, char *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length) > (XPREDICT_NEXT_NODE_RIGHT_INDEX_ADDR_NEXT_NODE_RIGHT_INDEX_HIGH - XPREDICT_NEXT_NODE_RIGHT_INDEX_ADDR_NEXT_NODE_RIGHT_INDEX_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(data + i) = *(char *)(InstancePtr->Next_node_right_index_BaseAddress + XPREDICT_NEXT_NODE_RIGHT_INDEX_ADDR_NEXT_NODE_RIGHT_INDEX_BASE + offset + i);
    }
    return length;
}

u32 XPredict_Get_node_leaf_value_BaseAddress(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (InstancePtr->Node_leaf_value_BaseAddress + XPREDICT_NODE_LEAF_VALUE_ADDR_NODE_LEAF_VALUE_BASE);
}

u32 XPredict_Get_node_leaf_value_HighAddress(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (InstancePtr->Node_leaf_value_BaseAddress + XPREDICT_NODE_LEAF_VALUE_ADDR_NODE_LEAF_VALUE_HIGH);
}

u32 XPredict_Get_node_leaf_value_TotalBytes(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (XPREDICT_NODE_LEAF_VALUE_ADDR_NODE_LEAF_VALUE_HIGH - XPREDICT_NODE_LEAF_VALUE_ADDR_NODE_LEAF_VALUE_BASE + 1);
}

u32 XPredict_Get_node_leaf_value_BitWidth(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XPREDICT_NODE_LEAF_VALUE_WIDTH_NODE_LEAF_VALUE;
}

u32 XPredict_Get_node_leaf_value_Depth(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XPREDICT_NODE_LEAF_VALUE_DEPTH_NODE_LEAF_VALUE;
}

u32 XPredict_Write_node_leaf_value_Words(XPredict *InstancePtr, int offset, word_type *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length)*4 > (XPREDICT_NODE_LEAF_VALUE_ADDR_NODE_LEAF_VALUE_HIGH - XPREDICT_NODE_LEAF_VALUE_ADDR_NODE_LEAF_VALUE_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(int *)(InstancePtr->Node_leaf_value_BaseAddress + XPREDICT_NODE_LEAF_VALUE_ADDR_NODE_LEAF_VALUE_BASE + (offset + i)*4) = *(data + i);
    }
    return length;
}

u32 XPredict_Read_node_leaf_value_Words(XPredict *InstancePtr, int offset, word_type *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length)*4 > (XPREDICT_NODE_LEAF_VALUE_ADDR_NODE_LEAF_VALUE_HIGH - XPREDICT_NODE_LEAF_VALUE_ADDR_NODE_LEAF_VALUE_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(data + i) = *(int *)(InstancePtr->Node_leaf_value_BaseAddress + XPREDICT_NODE_LEAF_VALUE_ADDR_NODE_LEAF_VALUE_BASE + (offset + i)*4);
    }
    return length;
}

u32 XPredict_Write_node_leaf_value_Bytes(XPredict *InstancePtr, int offset, char *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length) > (XPREDICT_NODE_LEAF_VALUE_ADDR_NODE_LEAF_VALUE_HIGH - XPREDICT_NODE_LEAF_VALUE_ADDR_NODE_LEAF_VALUE_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(char *)(InstancePtr->Node_leaf_value_BaseAddress + XPREDICT_NODE_LEAF_VALUE_ADDR_NODE_LEAF_VALUE_BASE + offset + i) = *(data + i);
    }
    return length;
}

u32 XPredict_Read_node_leaf_value_Bytes(XPredict *InstancePtr, int offset, char *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length) > (XPREDICT_NODE_LEAF_VALUE_ADDR_NODE_LEAF_VALUE_HIGH - XPREDICT_NODE_LEAF_VALUE_ADDR_NODE_LEAF_VALUE_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(data + i) = *(char *)(InstancePtr->Node_leaf_value_BaseAddress + XPREDICT_NODE_LEAF_VALUE_ADDR_NODE_LEAF_VALUE_BASE + offset + i);
    }
    return length;
}

void XPredict_InterruptGlobalEnable(XPredict *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XPredict_WriteReg(InstancePtr->Results_BaseAddress, XPREDICT_RESULTS_ADDR_GIE, 1);
}

void XPredict_InterruptGlobalDisable(XPredict *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XPredict_WriteReg(InstancePtr->Results_BaseAddress, XPREDICT_RESULTS_ADDR_GIE, 0);
}

void XPredict_InterruptEnable(XPredict *InstancePtr, u32 Mask) {
    u32 Register;

    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Register =  XPredict_ReadReg(InstancePtr->Results_BaseAddress, XPREDICT_RESULTS_ADDR_IER);
    XPredict_WriteReg(InstancePtr->Results_BaseAddress, XPREDICT_RESULTS_ADDR_IER, Register | Mask);
}

void XPredict_InterruptDisable(XPredict *InstancePtr, u32 Mask) {
    u32 Register;

    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Register =  XPredict_ReadReg(InstancePtr->Results_BaseAddress, XPREDICT_RESULTS_ADDR_IER);
    XPredict_WriteReg(InstancePtr->Results_BaseAddress, XPREDICT_RESULTS_ADDR_IER, Register & (~Mask));
}

void XPredict_InterruptClear(XPredict *InstancePtr, u32 Mask) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XPredict_WriteReg(InstancePtr->Results_BaseAddress, XPREDICT_RESULTS_ADDR_ISR, Mask);
}

u32 XPredict_InterruptGetEnabled(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XPredict_ReadReg(InstancePtr->Results_BaseAddress, XPREDICT_RESULTS_ADDR_IER);
}

u32 XPredict_InterruptGetStatus(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XPredict_ReadReg(InstancePtr->Results_BaseAddress, XPREDICT_RESULTS_ADDR_ISR);
}

