// ==============================================================
// Vitis HLS - High-Level Synthesis from C, C++ and OpenCL v2023.1.1 (64-bit)
// Tool Version Limit: 2023.06
// Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
// Copyright 2022-2023 Advanced Micro Devices, Inc. All Rights Reserved.
// 
// ==============================================================
/***************************** Include Files *********************************/
#include "xpredict.h"

/************************** Function Implementation *************************/
#ifndef __linux__
int XPredict_CfgInitialize(XPredict *InstancePtr, XPredict_Config *ConfigPtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(ConfigPtr != NULL);

    InstancePtr->Compact_data_BaseAddress = ConfigPtr->Compact_data_BaseAddress;
    InstancePtr->Features_BaseAddress = ConfigPtr->Features_BaseAddress;
    InstancePtr->Next_node_right_index_BaseAddress = ConfigPtr->Next_node_right_index_BaseAddress;
    InstancePtr->Node_leaf_value_BaseAddress = ConfigPtr->Node_leaf_value_BaseAddress;
    InstancePtr->Prediction_BaseAddress = ConfigPtr->Prediction_BaseAddress;
    InstancePtr->Results_BaseAddress = ConfigPtr->Results_BaseAddress;
    InstancePtr->IsReady = XIL_COMPONENT_IS_READY;

    return XST_SUCCESS;
}
#endif

void XPredict_Start(XPredict *InstancePtr) {
    u32 Data;

    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XPredict_ReadReg(InstancePtr->Results_BaseAddress, XPREDICT_RESULTS_ADDR_AP_CTRL) & 0x80;
    XPredict_WriteReg(InstancePtr->Results_BaseAddress, XPREDICT_RESULTS_ADDR_AP_CTRL, Data | 0x01);
}

u32 XPredict_IsDone(XPredict *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XPredict_ReadReg(InstancePtr->Results_BaseAddress, XPREDICT_RESULTS_ADDR_AP_CTRL);
    return (Data >> 1) & 0x1;
}

u32 XPredict_IsIdle(XPredict *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XPredict_ReadReg(InstancePtr->Results_BaseAddress, XPREDICT_RESULTS_ADDR_AP_CTRL);
    return (Data >> 2) & 0x1;
}

u32 XPredict_IsReady(XPredict *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XPredict_ReadReg(InstancePtr->Results_BaseAddress, XPREDICT_RESULTS_ADDR_AP_CTRL);
    // check ap_start to see if the pcore is ready for next input
    return !(Data & 0x1);
}

void XPredict_EnableAutoRestart(XPredict *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XPredict_WriteReg(InstancePtr->Results_BaseAddress, XPREDICT_RESULTS_ADDR_AP_CTRL, 0x80);
}

void XPredict_DisableAutoRestart(XPredict *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XPredict_WriteReg(InstancePtr->Results_BaseAddress, XPREDICT_RESULTS_ADDR_AP_CTRL, 0);
}

u32 XPredict_Get_prediction(XPredict *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XPredict_ReadReg(InstancePtr->Prediction_BaseAddress, XPREDICT_PREDICTION_ADDR_PREDICTION_DATA);
    return Data;
}

u32 XPredict_Get_prediction_vld(XPredict *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XPredict_ReadReg(InstancePtr->Prediction_BaseAddress, XPREDICT_PREDICTION_ADDR_PREDICTION_CTRL);
    return Data & 0x1;
}

u32 XPredict_Get_compact_data_0_BaseAddress(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (InstancePtr->Compact_data_BaseAddress + XPREDICT_COMPACT_DATA_ADDR_COMPACT_DATA_0_BASE);
}

u32 XPredict_Get_compact_data_0_HighAddress(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (InstancePtr->Compact_data_BaseAddress + XPREDICT_COMPACT_DATA_ADDR_COMPACT_DATA_0_HIGH);
}

u32 XPredict_Get_compact_data_0_TotalBytes(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (XPREDICT_COMPACT_DATA_ADDR_COMPACT_DATA_0_HIGH - XPREDICT_COMPACT_DATA_ADDR_COMPACT_DATA_0_BASE + 1);
}

u32 XPredict_Get_compact_data_0_BitWidth(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XPREDICT_COMPACT_DATA_WIDTH_COMPACT_DATA_0;
}

u32 XPredict_Get_compact_data_0_Depth(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XPREDICT_COMPACT_DATA_DEPTH_COMPACT_DATA_0;
}

u32 XPredict_Write_compact_data_0_Words(XPredict *InstancePtr, int offset, word_type *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length)*4 > (XPREDICT_COMPACT_DATA_ADDR_COMPACT_DATA_0_HIGH - XPREDICT_COMPACT_DATA_ADDR_COMPACT_DATA_0_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(int *)(InstancePtr->Compact_data_BaseAddress + XPREDICT_COMPACT_DATA_ADDR_COMPACT_DATA_0_BASE + (offset + i)*4) = *(data + i);
    }
    return length;
}

u32 XPredict_Read_compact_data_0_Words(XPredict *InstancePtr, int offset, word_type *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length)*4 > (XPREDICT_COMPACT_DATA_ADDR_COMPACT_DATA_0_HIGH - XPREDICT_COMPACT_DATA_ADDR_COMPACT_DATA_0_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(data + i) = *(int *)(InstancePtr->Compact_data_BaseAddress + XPREDICT_COMPACT_DATA_ADDR_COMPACT_DATA_0_BASE + (offset + i)*4);
    }
    return length;
}

u32 XPredict_Write_compact_data_0_Bytes(XPredict *InstancePtr, int offset, char *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length) > (XPREDICT_COMPACT_DATA_ADDR_COMPACT_DATA_0_HIGH - XPREDICT_COMPACT_DATA_ADDR_COMPACT_DATA_0_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(char *)(InstancePtr->Compact_data_BaseAddress + XPREDICT_COMPACT_DATA_ADDR_COMPACT_DATA_0_BASE + offset + i) = *(data + i);
    }
    return length;
}

u32 XPredict_Read_compact_data_0_Bytes(XPredict *InstancePtr, int offset, char *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length) > (XPREDICT_COMPACT_DATA_ADDR_COMPACT_DATA_0_HIGH - XPREDICT_COMPACT_DATA_ADDR_COMPACT_DATA_0_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(data + i) = *(char *)(InstancePtr->Compact_data_BaseAddress + XPREDICT_COMPACT_DATA_ADDR_COMPACT_DATA_0_BASE + offset + i);
    }
    return length;
}

u32 XPredict_Get_compact_data_1_BaseAddress(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (InstancePtr->Compact_data_BaseAddress + XPREDICT_COMPACT_DATA_ADDR_COMPACT_DATA_1_BASE);
}

u32 XPredict_Get_compact_data_1_HighAddress(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (InstancePtr->Compact_data_BaseAddress + XPREDICT_COMPACT_DATA_ADDR_COMPACT_DATA_1_HIGH);
}

u32 XPredict_Get_compact_data_1_TotalBytes(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (XPREDICT_COMPACT_DATA_ADDR_COMPACT_DATA_1_HIGH - XPREDICT_COMPACT_DATA_ADDR_COMPACT_DATA_1_BASE + 1);
}

u32 XPredict_Get_compact_data_1_BitWidth(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XPREDICT_COMPACT_DATA_WIDTH_COMPACT_DATA_1;
}

u32 XPredict_Get_compact_data_1_Depth(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XPREDICT_COMPACT_DATA_DEPTH_COMPACT_DATA_1;
}

u32 XPredict_Write_compact_data_1_Words(XPredict *InstancePtr, int offset, word_type *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length)*4 > (XPREDICT_COMPACT_DATA_ADDR_COMPACT_DATA_1_HIGH - XPREDICT_COMPACT_DATA_ADDR_COMPACT_DATA_1_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(int *)(InstancePtr->Compact_data_BaseAddress + XPREDICT_COMPACT_DATA_ADDR_COMPACT_DATA_1_BASE + (offset + i)*4) = *(data + i);
    }
    return length;
}

u32 XPredict_Read_compact_data_1_Words(XPredict *InstancePtr, int offset, word_type *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length)*4 > (XPREDICT_COMPACT_DATA_ADDR_COMPACT_DATA_1_HIGH - XPREDICT_COMPACT_DATA_ADDR_COMPACT_DATA_1_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(data + i) = *(int *)(InstancePtr->Compact_data_BaseAddress + XPREDICT_COMPACT_DATA_ADDR_COMPACT_DATA_1_BASE + (offset + i)*4);
    }
    return length;
}

u32 XPredict_Write_compact_data_1_Bytes(XPredict *InstancePtr, int offset, char *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length) > (XPREDICT_COMPACT_DATA_ADDR_COMPACT_DATA_1_HIGH - XPREDICT_COMPACT_DATA_ADDR_COMPACT_DATA_1_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(char *)(InstancePtr->Compact_data_BaseAddress + XPREDICT_COMPACT_DATA_ADDR_COMPACT_DATA_1_BASE + offset + i) = *(data + i);
    }
    return length;
}

u32 XPredict_Read_compact_data_1_Bytes(XPredict *InstancePtr, int offset, char *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length) > (XPREDICT_COMPACT_DATA_ADDR_COMPACT_DATA_1_HIGH - XPREDICT_COMPACT_DATA_ADDR_COMPACT_DATA_1_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(data + i) = *(char *)(InstancePtr->Compact_data_BaseAddress + XPREDICT_COMPACT_DATA_ADDR_COMPACT_DATA_1_BASE + offset + i);
    }
    return length;
}

u32 XPredict_Get_compact_data_2_BaseAddress(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (InstancePtr->Compact_data_BaseAddress + XPREDICT_COMPACT_DATA_ADDR_COMPACT_DATA_2_BASE);
}

u32 XPredict_Get_compact_data_2_HighAddress(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (InstancePtr->Compact_data_BaseAddress + XPREDICT_COMPACT_DATA_ADDR_COMPACT_DATA_2_HIGH);
}

u32 XPredict_Get_compact_data_2_TotalBytes(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (XPREDICT_COMPACT_DATA_ADDR_COMPACT_DATA_2_HIGH - XPREDICT_COMPACT_DATA_ADDR_COMPACT_DATA_2_BASE + 1);
}

u32 XPredict_Get_compact_data_2_BitWidth(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XPREDICT_COMPACT_DATA_WIDTH_COMPACT_DATA_2;
}

u32 XPredict_Get_compact_data_2_Depth(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XPREDICT_COMPACT_DATA_DEPTH_COMPACT_DATA_2;
}

u32 XPredict_Write_compact_data_2_Words(XPredict *InstancePtr, int offset, word_type *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length)*4 > (XPREDICT_COMPACT_DATA_ADDR_COMPACT_DATA_2_HIGH - XPREDICT_COMPACT_DATA_ADDR_COMPACT_DATA_2_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(int *)(InstancePtr->Compact_data_BaseAddress + XPREDICT_COMPACT_DATA_ADDR_COMPACT_DATA_2_BASE + (offset + i)*4) = *(data + i);
    }
    return length;
}

u32 XPredict_Read_compact_data_2_Words(XPredict *InstancePtr, int offset, word_type *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length)*4 > (XPREDICT_COMPACT_DATA_ADDR_COMPACT_DATA_2_HIGH - XPREDICT_COMPACT_DATA_ADDR_COMPACT_DATA_2_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(data + i) = *(int *)(InstancePtr->Compact_data_BaseAddress + XPREDICT_COMPACT_DATA_ADDR_COMPACT_DATA_2_BASE + (offset + i)*4);
    }
    return length;
}

u32 XPredict_Write_compact_data_2_Bytes(XPredict *InstancePtr, int offset, char *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length) > (XPREDICT_COMPACT_DATA_ADDR_COMPACT_DATA_2_HIGH - XPREDICT_COMPACT_DATA_ADDR_COMPACT_DATA_2_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(char *)(InstancePtr->Compact_data_BaseAddress + XPREDICT_COMPACT_DATA_ADDR_COMPACT_DATA_2_BASE + offset + i) = *(data + i);
    }
    return length;
}

u32 XPredict_Read_compact_data_2_Bytes(XPredict *InstancePtr, int offset, char *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length) > (XPREDICT_COMPACT_DATA_ADDR_COMPACT_DATA_2_HIGH - XPREDICT_COMPACT_DATA_ADDR_COMPACT_DATA_2_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(data + i) = *(char *)(InstancePtr->Compact_data_BaseAddress + XPREDICT_COMPACT_DATA_ADDR_COMPACT_DATA_2_BASE + offset + i);
    }
    return length;
}

u32 XPredict_Get_compact_data_3_BaseAddress(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (InstancePtr->Compact_data_BaseAddress + XPREDICT_COMPACT_DATA_ADDR_COMPACT_DATA_3_BASE);
}

u32 XPredict_Get_compact_data_3_HighAddress(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (InstancePtr->Compact_data_BaseAddress + XPREDICT_COMPACT_DATA_ADDR_COMPACT_DATA_3_HIGH);
}

u32 XPredict_Get_compact_data_3_TotalBytes(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (XPREDICT_COMPACT_DATA_ADDR_COMPACT_DATA_3_HIGH - XPREDICT_COMPACT_DATA_ADDR_COMPACT_DATA_3_BASE + 1);
}

u32 XPredict_Get_compact_data_3_BitWidth(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XPREDICT_COMPACT_DATA_WIDTH_COMPACT_DATA_3;
}

u32 XPredict_Get_compact_data_3_Depth(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XPREDICT_COMPACT_DATA_DEPTH_COMPACT_DATA_3;
}

u32 XPredict_Write_compact_data_3_Words(XPredict *InstancePtr, int offset, word_type *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length)*4 > (XPREDICT_COMPACT_DATA_ADDR_COMPACT_DATA_3_HIGH - XPREDICT_COMPACT_DATA_ADDR_COMPACT_DATA_3_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(int *)(InstancePtr->Compact_data_BaseAddress + XPREDICT_COMPACT_DATA_ADDR_COMPACT_DATA_3_BASE + (offset + i)*4) = *(data + i);
    }
    return length;
}

u32 XPredict_Read_compact_data_3_Words(XPredict *InstancePtr, int offset, word_type *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length)*4 > (XPREDICT_COMPACT_DATA_ADDR_COMPACT_DATA_3_HIGH - XPREDICT_COMPACT_DATA_ADDR_COMPACT_DATA_3_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(data + i) = *(int *)(InstancePtr->Compact_data_BaseAddress + XPREDICT_COMPACT_DATA_ADDR_COMPACT_DATA_3_BASE + (offset + i)*4);
    }
    return length;
}

u32 XPredict_Write_compact_data_3_Bytes(XPredict *InstancePtr, int offset, char *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length) > (XPREDICT_COMPACT_DATA_ADDR_COMPACT_DATA_3_HIGH - XPREDICT_COMPACT_DATA_ADDR_COMPACT_DATA_3_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(char *)(InstancePtr->Compact_data_BaseAddress + XPREDICT_COMPACT_DATA_ADDR_COMPACT_DATA_3_BASE + offset + i) = *(data + i);
    }
    return length;
}

u32 XPredict_Read_compact_data_3_Bytes(XPredict *InstancePtr, int offset, char *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length) > (XPREDICT_COMPACT_DATA_ADDR_COMPACT_DATA_3_HIGH - XPREDICT_COMPACT_DATA_ADDR_COMPACT_DATA_3_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(data + i) = *(char *)(InstancePtr->Compact_data_BaseAddress + XPREDICT_COMPACT_DATA_ADDR_COMPACT_DATA_3_BASE + offset + i);
    }
    return length;
}

u32 XPredict_Get_compact_data_4_BaseAddress(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (InstancePtr->Compact_data_BaseAddress + XPREDICT_COMPACT_DATA_ADDR_COMPACT_DATA_4_BASE);
}

u32 XPredict_Get_compact_data_4_HighAddress(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (InstancePtr->Compact_data_BaseAddress + XPREDICT_COMPACT_DATA_ADDR_COMPACT_DATA_4_HIGH);
}

u32 XPredict_Get_compact_data_4_TotalBytes(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (XPREDICT_COMPACT_DATA_ADDR_COMPACT_DATA_4_HIGH - XPREDICT_COMPACT_DATA_ADDR_COMPACT_DATA_4_BASE + 1);
}

u32 XPredict_Get_compact_data_4_BitWidth(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XPREDICT_COMPACT_DATA_WIDTH_COMPACT_DATA_4;
}

u32 XPredict_Get_compact_data_4_Depth(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XPREDICT_COMPACT_DATA_DEPTH_COMPACT_DATA_4;
}

u32 XPredict_Write_compact_data_4_Words(XPredict *InstancePtr, int offset, word_type *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length)*4 > (XPREDICT_COMPACT_DATA_ADDR_COMPACT_DATA_4_HIGH - XPREDICT_COMPACT_DATA_ADDR_COMPACT_DATA_4_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(int *)(InstancePtr->Compact_data_BaseAddress + XPREDICT_COMPACT_DATA_ADDR_COMPACT_DATA_4_BASE + (offset + i)*4) = *(data + i);
    }
    return length;
}

u32 XPredict_Read_compact_data_4_Words(XPredict *InstancePtr, int offset, word_type *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length)*4 > (XPREDICT_COMPACT_DATA_ADDR_COMPACT_DATA_4_HIGH - XPREDICT_COMPACT_DATA_ADDR_COMPACT_DATA_4_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(data + i) = *(int *)(InstancePtr->Compact_data_BaseAddress + XPREDICT_COMPACT_DATA_ADDR_COMPACT_DATA_4_BASE + (offset + i)*4);
    }
    return length;
}

u32 XPredict_Write_compact_data_4_Bytes(XPredict *InstancePtr, int offset, char *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length) > (XPREDICT_COMPACT_DATA_ADDR_COMPACT_DATA_4_HIGH - XPREDICT_COMPACT_DATA_ADDR_COMPACT_DATA_4_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(char *)(InstancePtr->Compact_data_BaseAddress + XPREDICT_COMPACT_DATA_ADDR_COMPACT_DATA_4_BASE + offset + i) = *(data + i);
    }
    return length;
}

u32 XPredict_Read_compact_data_4_Bytes(XPredict *InstancePtr, int offset, char *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length) > (XPREDICT_COMPACT_DATA_ADDR_COMPACT_DATA_4_HIGH - XPREDICT_COMPACT_DATA_ADDR_COMPACT_DATA_4_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(data + i) = *(char *)(InstancePtr->Compact_data_BaseAddress + XPREDICT_COMPACT_DATA_ADDR_COMPACT_DATA_4_BASE + offset + i);
    }
    return length;
}

u32 XPredict_Get_compact_data_5_BaseAddress(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (InstancePtr->Compact_data_BaseAddress + XPREDICT_COMPACT_DATA_ADDR_COMPACT_DATA_5_BASE);
}

u32 XPredict_Get_compact_data_5_HighAddress(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (InstancePtr->Compact_data_BaseAddress + XPREDICT_COMPACT_DATA_ADDR_COMPACT_DATA_5_HIGH);
}

u32 XPredict_Get_compact_data_5_TotalBytes(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (XPREDICT_COMPACT_DATA_ADDR_COMPACT_DATA_5_HIGH - XPREDICT_COMPACT_DATA_ADDR_COMPACT_DATA_5_BASE + 1);
}

u32 XPredict_Get_compact_data_5_BitWidth(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XPREDICT_COMPACT_DATA_WIDTH_COMPACT_DATA_5;
}

u32 XPredict_Get_compact_data_5_Depth(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XPREDICT_COMPACT_DATA_DEPTH_COMPACT_DATA_5;
}

u32 XPredict_Write_compact_data_5_Words(XPredict *InstancePtr, int offset, word_type *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length)*4 > (XPREDICT_COMPACT_DATA_ADDR_COMPACT_DATA_5_HIGH - XPREDICT_COMPACT_DATA_ADDR_COMPACT_DATA_5_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(int *)(InstancePtr->Compact_data_BaseAddress + XPREDICT_COMPACT_DATA_ADDR_COMPACT_DATA_5_BASE + (offset + i)*4) = *(data + i);
    }
    return length;
}

u32 XPredict_Read_compact_data_5_Words(XPredict *InstancePtr, int offset, word_type *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length)*4 > (XPREDICT_COMPACT_DATA_ADDR_COMPACT_DATA_5_HIGH - XPREDICT_COMPACT_DATA_ADDR_COMPACT_DATA_5_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(data + i) = *(int *)(InstancePtr->Compact_data_BaseAddress + XPREDICT_COMPACT_DATA_ADDR_COMPACT_DATA_5_BASE + (offset + i)*4);
    }
    return length;
}

u32 XPredict_Write_compact_data_5_Bytes(XPredict *InstancePtr, int offset, char *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length) > (XPREDICT_COMPACT_DATA_ADDR_COMPACT_DATA_5_HIGH - XPREDICT_COMPACT_DATA_ADDR_COMPACT_DATA_5_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(char *)(InstancePtr->Compact_data_BaseAddress + XPREDICT_COMPACT_DATA_ADDR_COMPACT_DATA_5_BASE + offset + i) = *(data + i);
    }
    return length;
}

u32 XPredict_Read_compact_data_5_Bytes(XPredict *InstancePtr, int offset, char *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length) > (XPREDICT_COMPACT_DATA_ADDR_COMPACT_DATA_5_HIGH - XPREDICT_COMPACT_DATA_ADDR_COMPACT_DATA_5_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(data + i) = *(char *)(InstancePtr->Compact_data_BaseAddress + XPREDICT_COMPACT_DATA_ADDR_COMPACT_DATA_5_BASE + offset + i);
    }
    return length;
}

u32 XPredict_Get_compact_data_6_BaseAddress(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (InstancePtr->Compact_data_BaseAddress + XPREDICT_COMPACT_DATA_ADDR_COMPACT_DATA_6_BASE);
}

u32 XPredict_Get_compact_data_6_HighAddress(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (InstancePtr->Compact_data_BaseAddress + XPREDICT_COMPACT_DATA_ADDR_COMPACT_DATA_6_HIGH);
}

u32 XPredict_Get_compact_data_6_TotalBytes(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (XPREDICT_COMPACT_DATA_ADDR_COMPACT_DATA_6_HIGH - XPREDICT_COMPACT_DATA_ADDR_COMPACT_DATA_6_BASE + 1);
}

u32 XPredict_Get_compact_data_6_BitWidth(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XPREDICT_COMPACT_DATA_WIDTH_COMPACT_DATA_6;
}

u32 XPredict_Get_compact_data_6_Depth(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XPREDICT_COMPACT_DATA_DEPTH_COMPACT_DATA_6;
}

u32 XPredict_Write_compact_data_6_Words(XPredict *InstancePtr, int offset, word_type *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length)*4 > (XPREDICT_COMPACT_DATA_ADDR_COMPACT_DATA_6_HIGH - XPREDICT_COMPACT_DATA_ADDR_COMPACT_DATA_6_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(int *)(InstancePtr->Compact_data_BaseAddress + XPREDICT_COMPACT_DATA_ADDR_COMPACT_DATA_6_BASE + (offset + i)*4) = *(data + i);
    }
    return length;
}

u32 XPredict_Read_compact_data_6_Words(XPredict *InstancePtr, int offset, word_type *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length)*4 > (XPREDICT_COMPACT_DATA_ADDR_COMPACT_DATA_6_HIGH - XPREDICT_COMPACT_DATA_ADDR_COMPACT_DATA_6_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(data + i) = *(int *)(InstancePtr->Compact_data_BaseAddress + XPREDICT_COMPACT_DATA_ADDR_COMPACT_DATA_6_BASE + (offset + i)*4);
    }
    return length;
}

u32 XPredict_Write_compact_data_6_Bytes(XPredict *InstancePtr, int offset, char *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length) > (XPREDICT_COMPACT_DATA_ADDR_COMPACT_DATA_6_HIGH - XPREDICT_COMPACT_DATA_ADDR_COMPACT_DATA_6_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(char *)(InstancePtr->Compact_data_BaseAddress + XPREDICT_COMPACT_DATA_ADDR_COMPACT_DATA_6_BASE + offset + i) = *(data + i);
    }
    return length;
}

u32 XPredict_Read_compact_data_6_Bytes(XPredict *InstancePtr, int offset, char *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length) > (XPREDICT_COMPACT_DATA_ADDR_COMPACT_DATA_6_HIGH - XPREDICT_COMPACT_DATA_ADDR_COMPACT_DATA_6_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(data + i) = *(char *)(InstancePtr->Compact_data_BaseAddress + XPREDICT_COMPACT_DATA_ADDR_COMPACT_DATA_6_BASE + offset + i);
    }
    return length;
}

u32 XPredict_Get_compact_data_7_BaseAddress(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (InstancePtr->Compact_data_BaseAddress + XPREDICT_COMPACT_DATA_ADDR_COMPACT_DATA_7_BASE);
}

u32 XPredict_Get_compact_data_7_HighAddress(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (InstancePtr->Compact_data_BaseAddress + XPREDICT_COMPACT_DATA_ADDR_COMPACT_DATA_7_HIGH);
}

u32 XPredict_Get_compact_data_7_TotalBytes(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (XPREDICT_COMPACT_DATA_ADDR_COMPACT_DATA_7_HIGH - XPREDICT_COMPACT_DATA_ADDR_COMPACT_DATA_7_BASE + 1);
}

u32 XPredict_Get_compact_data_7_BitWidth(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XPREDICT_COMPACT_DATA_WIDTH_COMPACT_DATA_7;
}

u32 XPredict_Get_compact_data_7_Depth(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XPREDICT_COMPACT_DATA_DEPTH_COMPACT_DATA_7;
}

u32 XPredict_Write_compact_data_7_Words(XPredict *InstancePtr, int offset, word_type *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length)*4 > (XPREDICT_COMPACT_DATA_ADDR_COMPACT_DATA_7_HIGH - XPREDICT_COMPACT_DATA_ADDR_COMPACT_DATA_7_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(int *)(InstancePtr->Compact_data_BaseAddress + XPREDICT_COMPACT_DATA_ADDR_COMPACT_DATA_7_BASE + (offset + i)*4) = *(data + i);
    }
    return length;
}

u32 XPredict_Read_compact_data_7_Words(XPredict *InstancePtr, int offset, word_type *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length)*4 > (XPREDICT_COMPACT_DATA_ADDR_COMPACT_DATA_7_HIGH - XPREDICT_COMPACT_DATA_ADDR_COMPACT_DATA_7_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(data + i) = *(int *)(InstancePtr->Compact_data_BaseAddress + XPREDICT_COMPACT_DATA_ADDR_COMPACT_DATA_7_BASE + (offset + i)*4);
    }
    return length;
}

u32 XPredict_Write_compact_data_7_Bytes(XPredict *InstancePtr, int offset, char *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length) > (XPREDICT_COMPACT_DATA_ADDR_COMPACT_DATA_7_HIGH - XPREDICT_COMPACT_DATA_ADDR_COMPACT_DATA_7_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(char *)(InstancePtr->Compact_data_BaseAddress + XPREDICT_COMPACT_DATA_ADDR_COMPACT_DATA_7_BASE + offset + i) = *(data + i);
    }
    return length;
}

u32 XPredict_Read_compact_data_7_Bytes(XPredict *InstancePtr, int offset, char *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length) > (XPREDICT_COMPACT_DATA_ADDR_COMPACT_DATA_7_HIGH - XPREDICT_COMPACT_DATA_ADDR_COMPACT_DATA_7_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(data + i) = *(char *)(InstancePtr->Compact_data_BaseAddress + XPREDICT_COMPACT_DATA_ADDR_COMPACT_DATA_7_BASE + offset + i);
    }
    return length;
}

u32 XPredict_Get_compact_data_8_BaseAddress(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (InstancePtr->Compact_data_BaseAddress + XPREDICT_COMPACT_DATA_ADDR_COMPACT_DATA_8_BASE);
}

u32 XPredict_Get_compact_data_8_HighAddress(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (InstancePtr->Compact_data_BaseAddress + XPREDICT_COMPACT_DATA_ADDR_COMPACT_DATA_8_HIGH);
}

u32 XPredict_Get_compact_data_8_TotalBytes(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (XPREDICT_COMPACT_DATA_ADDR_COMPACT_DATA_8_HIGH - XPREDICT_COMPACT_DATA_ADDR_COMPACT_DATA_8_BASE + 1);
}

u32 XPredict_Get_compact_data_8_BitWidth(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XPREDICT_COMPACT_DATA_WIDTH_COMPACT_DATA_8;
}

u32 XPredict_Get_compact_data_8_Depth(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XPREDICT_COMPACT_DATA_DEPTH_COMPACT_DATA_8;
}

u32 XPredict_Write_compact_data_8_Words(XPredict *InstancePtr, int offset, word_type *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length)*4 > (XPREDICT_COMPACT_DATA_ADDR_COMPACT_DATA_8_HIGH - XPREDICT_COMPACT_DATA_ADDR_COMPACT_DATA_8_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(int *)(InstancePtr->Compact_data_BaseAddress + XPREDICT_COMPACT_DATA_ADDR_COMPACT_DATA_8_BASE + (offset + i)*4) = *(data + i);
    }
    return length;
}

u32 XPredict_Read_compact_data_8_Words(XPredict *InstancePtr, int offset, word_type *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length)*4 > (XPREDICT_COMPACT_DATA_ADDR_COMPACT_DATA_8_HIGH - XPREDICT_COMPACT_DATA_ADDR_COMPACT_DATA_8_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(data + i) = *(int *)(InstancePtr->Compact_data_BaseAddress + XPREDICT_COMPACT_DATA_ADDR_COMPACT_DATA_8_BASE + (offset + i)*4);
    }
    return length;
}

u32 XPredict_Write_compact_data_8_Bytes(XPredict *InstancePtr, int offset, char *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length) > (XPREDICT_COMPACT_DATA_ADDR_COMPACT_DATA_8_HIGH - XPREDICT_COMPACT_DATA_ADDR_COMPACT_DATA_8_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(char *)(InstancePtr->Compact_data_BaseAddress + XPREDICT_COMPACT_DATA_ADDR_COMPACT_DATA_8_BASE + offset + i) = *(data + i);
    }
    return length;
}

u32 XPredict_Read_compact_data_8_Bytes(XPredict *InstancePtr, int offset, char *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length) > (XPREDICT_COMPACT_DATA_ADDR_COMPACT_DATA_8_HIGH - XPREDICT_COMPACT_DATA_ADDR_COMPACT_DATA_8_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(data + i) = *(char *)(InstancePtr->Compact_data_BaseAddress + XPREDICT_COMPACT_DATA_ADDR_COMPACT_DATA_8_BASE + offset + i);
    }
    return length;
}

u32 XPredict_Get_compact_data_9_BaseAddress(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (InstancePtr->Compact_data_BaseAddress + XPREDICT_COMPACT_DATA_ADDR_COMPACT_DATA_9_BASE);
}

u32 XPredict_Get_compact_data_9_HighAddress(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (InstancePtr->Compact_data_BaseAddress + XPREDICT_COMPACT_DATA_ADDR_COMPACT_DATA_9_HIGH);
}

u32 XPredict_Get_compact_data_9_TotalBytes(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (XPREDICT_COMPACT_DATA_ADDR_COMPACT_DATA_9_HIGH - XPREDICT_COMPACT_DATA_ADDR_COMPACT_DATA_9_BASE + 1);
}

u32 XPredict_Get_compact_data_9_BitWidth(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XPREDICT_COMPACT_DATA_WIDTH_COMPACT_DATA_9;
}

u32 XPredict_Get_compact_data_9_Depth(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XPREDICT_COMPACT_DATA_DEPTH_COMPACT_DATA_9;
}

u32 XPredict_Write_compact_data_9_Words(XPredict *InstancePtr, int offset, word_type *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length)*4 > (XPREDICT_COMPACT_DATA_ADDR_COMPACT_DATA_9_HIGH - XPREDICT_COMPACT_DATA_ADDR_COMPACT_DATA_9_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(int *)(InstancePtr->Compact_data_BaseAddress + XPREDICT_COMPACT_DATA_ADDR_COMPACT_DATA_9_BASE + (offset + i)*4) = *(data + i);
    }
    return length;
}

u32 XPredict_Read_compact_data_9_Words(XPredict *InstancePtr, int offset, word_type *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length)*4 > (XPREDICT_COMPACT_DATA_ADDR_COMPACT_DATA_9_HIGH - XPREDICT_COMPACT_DATA_ADDR_COMPACT_DATA_9_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(data + i) = *(int *)(InstancePtr->Compact_data_BaseAddress + XPREDICT_COMPACT_DATA_ADDR_COMPACT_DATA_9_BASE + (offset + i)*4);
    }
    return length;
}

u32 XPredict_Write_compact_data_9_Bytes(XPredict *InstancePtr, int offset, char *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length) > (XPREDICT_COMPACT_DATA_ADDR_COMPACT_DATA_9_HIGH - XPREDICT_COMPACT_DATA_ADDR_COMPACT_DATA_9_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(char *)(InstancePtr->Compact_data_BaseAddress + XPREDICT_COMPACT_DATA_ADDR_COMPACT_DATA_9_BASE + offset + i) = *(data + i);
    }
    return length;
}

u32 XPredict_Read_compact_data_9_Bytes(XPredict *InstancePtr, int offset, char *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length) > (XPREDICT_COMPACT_DATA_ADDR_COMPACT_DATA_9_HIGH - XPREDICT_COMPACT_DATA_ADDR_COMPACT_DATA_9_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(data + i) = *(char *)(InstancePtr->Compact_data_BaseAddress + XPREDICT_COMPACT_DATA_ADDR_COMPACT_DATA_9_BASE + offset + i);
    }
    return length;
}

u32 XPredict_Get_features_0_BaseAddress(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (InstancePtr->Features_BaseAddress + XPREDICT_FEATURES_ADDR_FEATURES_0_BASE);
}

u32 XPredict_Get_features_0_HighAddress(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (InstancePtr->Features_BaseAddress + XPREDICT_FEATURES_ADDR_FEATURES_0_HIGH);
}

u32 XPredict_Get_features_0_TotalBytes(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (XPREDICT_FEATURES_ADDR_FEATURES_0_HIGH - XPREDICT_FEATURES_ADDR_FEATURES_0_BASE + 1);
}

u32 XPredict_Get_features_0_BitWidth(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XPREDICT_FEATURES_WIDTH_FEATURES_0;
}

u32 XPredict_Get_features_0_Depth(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XPREDICT_FEATURES_DEPTH_FEATURES_0;
}

u32 XPredict_Write_features_0_Words(XPredict *InstancePtr, int offset, word_type *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length)*4 > (XPREDICT_FEATURES_ADDR_FEATURES_0_HIGH - XPREDICT_FEATURES_ADDR_FEATURES_0_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(int *)(InstancePtr->Features_BaseAddress + XPREDICT_FEATURES_ADDR_FEATURES_0_BASE + (offset + i)*4) = *(data + i);
    }
    return length;
}

u32 XPredict_Read_features_0_Words(XPredict *InstancePtr, int offset, word_type *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length)*4 > (XPREDICT_FEATURES_ADDR_FEATURES_0_HIGH - XPREDICT_FEATURES_ADDR_FEATURES_0_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(data + i) = *(int *)(InstancePtr->Features_BaseAddress + XPREDICT_FEATURES_ADDR_FEATURES_0_BASE + (offset + i)*4);
    }
    return length;
}

u32 XPredict_Write_features_0_Bytes(XPredict *InstancePtr, int offset, char *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length) > (XPREDICT_FEATURES_ADDR_FEATURES_0_HIGH - XPREDICT_FEATURES_ADDR_FEATURES_0_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(char *)(InstancePtr->Features_BaseAddress + XPREDICT_FEATURES_ADDR_FEATURES_0_BASE + offset + i) = *(data + i);
    }
    return length;
}

u32 XPredict_Read_features_0_Bytes(XPredict *InstancePtr, int offset, char *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length) > (XPREDICT_FEATURES_ADDR_FEATURES_0_HIGH - XPREDICT_FEATURES_ADDR_FEATURES_0_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(data + i) = *(char *)(InstancePtr->Features_BaseAddress + XPREDICT_FEATURES_ADDR_FEATURES_0_BASE + offset + i);
    }
    return length;
}

u32 XPredict_Get_features_1_BaseAddress(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (InstancePtr->Features_BaseAddress + XPREDICT_FEATURES_ADDR_FEATURES_1_BASE);
}

u32 XPredict_Get_features_1_HighAddress(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (InstancePtr->Features_BaseAddress + XPREDICT_FEATURES_ADDR_FEATURES_1_HIGH);
}

u32 XPredict_Get_features_1_TotalBytes(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (XPREDICT_FEATURES_ADDR_FEATURES_1_HIGH - XPREDICT_FEATURES_ADDR_FEATURES_1_BASE + 1);
}

u32 XPredict_Get_features_1_BitWidth(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XPREDICT_FEATURES_WIDTH_FEATURES_1;
}

u32 XPredict_Get_features_1_Depth(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XPREDICT_FEATURES_DEPTH_FEATURES_1;
}

u32 XPredict_Write_features_1_Words(XPredict *InstancePtr, int offset, word_type *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length)*4 > (XPREDICT_FEATURES_ADDR_FEATURES_1_HIGH - XPREDICT_FEATURES_ADDR_FEATURES_1_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(int *)(InstancePtr->Features_BaseAddress + XPREDICT_FEATURES_ADDR_FEATURES_1_BASE + (offset + i)*4) = *(data + i);
    }
    return length;
}

u32 XPredict_Read_features_1_Words(XPredict *InstancePtr, int offset, word_type *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length)*4 > (XPREDICT_FEATURES_ADDR_FEATURES_1_HIGH - XPREDICT_FEATURES_ADDR_FEATURES_1_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(data + i) = *(int *)(InstancePtr->Features_BaseAddress + XPREDICT_FEATURES_ADDR_FEATURES_1_BASE + (offset + i)*4);
    }
    return length;
}

u32 XPredict_Write_features_1_Bytes(XPredict *InstancePtr, int offset, char *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length) > (XPREDICT_FEATURES_ADDR_FEATURES_1_HIGH - XPREDICT_FEATURES_ADDR_FEATURES_1_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(char *)(InstancePtr->Features_BaseAddress + XPREDICT_FEATURES_ADDR_FEATURES_1_BASE + offset + i) = *(data + i);
    }
    return length;
}

u32 XPredict_Read_features_1_Bytes(XPredict *InstancePtr, int offset, char *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length) > (XPREDICT_FEATURES_ADDR_FEATURES_1_HIGH - XPREDICT_FEATURES_ADDR_FEATURES_1_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(data + i) = *(char *)(InstancePtr->Features_BaseAddress + XPREDICT_FEATURES_ADDR_FEATURES_1_BASE + offset + i);
    }
    return length;
}

u32 XPredict_Get_features_2_BaseAddress(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (InstancePtr->Features_BaseAddress + XPREDICT_FEATURES_ADDR_FEATURES_2_BASE);
}

u32 XPredict_Get_features_2_HighAddress(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (InstancePtr->Features_BaseAddress + XPREDICT_FEATURES_ADDR_FEATURES_2_HIGH);
}

u32 XPredict_Get_features_2_TotalBytes(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (XPREDICT_FEATURES_ADDR_FEATURES_2_HIGH - XPREDICT_FEATURES_ADDR_FEATURES_2_BASE + 1);
}

u32 XPredict_Get_features_2_BitWidth(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XPREDICT_FEATURES_WIDTH_FEATURES_2;
}

u32 XPredict_Get_features_2_Depth(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XPREDICT_FEATURES_DEPTH_FEATURES_2;
}

u32 XPredict_Write_features_2_Words(XPredict *InstancePtr, int offset, word_type *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length)*4 > (XPREDICT_FEATURES_ADDR_FEATURES_2_HIGH - XPREDICT_FEATURES_ADDR_FEATURES_2_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(int *)(InstancePtr->Features_BaseAddress + XPREDICT_FEATURES_ADDR_FEATURES_2_BASE + (offset + i)*4) = *(data + i);
    }
    return length;
}

u32 XPredict_Read_features_2_Words(XPredict *InstancePtr, int offset, word_type *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length)*4 > (XPREDICT_FEATURES_ADDR_FEATURES_2_HIGH - XPREDICT_FEATURES_ADDR_FEATURES_2_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(data + i) = *(int *)(InstancePtr->Features_BaseAddress + XPREDICT_FEATURES_ADDR_FEATURES_2_BASE + (offset + i)*4);
    }
    return length;
}

u32 XPredict_Write_features_2_Bytes(XPredict *InstancePtr, int offset, char *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length) > (XPREDICT_FEATURES_ADDR_FEATURES_2_HIGH - XPREDICT_FEATURES_ADDR_FEATURES_2_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(char *)(InstancePtr->Features_BaseAddress + XPREDICT_FEATURES_ADDR_FEATURES_2_BASE + offset + i) = *(data + i);
    }
    return length;
}

u32 XPredict_Read_features_2_Bytes(XPredict *InstancePtr, int offset, char *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length) > (XPREDICT_FEATURES_ADDR_FEATURES_2_HIGH - XPREDICT_FEATURES_ADDR_FEATURES_2_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(data + i) = *(char *)(InstancePtr->Features_BaseAddress + XPREDICT_FEATURES_ADDR_FEATURES_2_BASE + offset + i);
    }
    return length;
}

u32 XPredict_Get_features_3_BaseAddress(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (InstancePtr->Features_BaseAddress + XPREDICT_FEATURES_ADDR_FEATURES_3_BASE);
}

u32 XPredict_Get_features_3_HighAddress(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (InstancePtr->Features_BaseAddress + XPREDICT_FEATURES_ADDR_FEATURES_3_HIGH);
}

u32 XPredict_Get_features_3_TotalBytes(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (XPREDICT_FEATURES_ADDR_FEATURES_3_HIGH - XPREDICT_FEATURES_ADDR_FEATURES_3_BASE + 1);
}

u32 XPredict_Get_features_3_BitWidth(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XPREDICT_FEATURES_WIDTH_FEATURES_3;
}

u32 XPredict_Get_features_3_Depth(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XPREDICT_FEATURES_DEPTH_FEATURES_3;
}

u32 XPredict_Write_features_3_Words(XPredict *InstancePtr, int offset, word_type *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length)*4 > (XPREDICT_FEATURES_ADDR_FEATURES_3_HIGH - XPREDICT_FEATURES_ADDR_FEATURES_3_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(int *)(InstancePtr->Features_BaseAddress + XPREDICT_FEATURES_ADDR_FEATURES_3_BASE + (offset + i)*4) = *(data + i);
    }
    return length;
}

u32 XPredict_Read_features_3_Words(XPredict *InstancePtr, int offset, word_type *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length)*4 > (XPREDICT_FEATURES_ADDR_FEATURES_3_HIGH - XPREDICT_FEATURES_ADDR_FEATURES_3_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(data + i) = *(int *)(InstancePtr->Features_BaseAddress + XPREDICT_FEATURES_ADDR_FEATURES_3_BASE + (offset + i)*4);
    }
    return length;
}

u32 XPredict_Write_features_3_Bytes(XPredict *InstancePtr, int offset, char *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length) > (XPREDICT_FEATURES_ADDR_FEATURES_3_HIGH - XPREDICT_FEATURES_ADDR_FEATURES_3_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(char *)(InstancePtr->Features_BaseAddress + XPREDICT_FEATURES_ADDR_FEATURES_3_BASE + offset + i) = *(data + i);
    }
    return length;
}

u32 XPredict_Read_features_3_Bytes(XPredict *InstancePtr, int offset, char *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length) > (XPREDICT_FEATURES_ADDR_FEATURES_3_HIGH - XPREDICT_FEATURES_ADDR_FEATURES_3_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(data + i) = *(char *)(InstancePtr->Features_BaseAddress + XPREDICT_FEATURES_ADDR_FEATURES_3_BASE + offset + i);
    }
    return length;
}

u32 XPredict_Get_features_4_BaseAddress(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (InstancePtr->Features_BaseAddress + XPREDICT_FEATURES_ADDR_FEATURES_4_BASE);
}

u32 XPredict_Get_features_4_HighAddress(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (InstancePtr->Features_BaseAddress + XPREDICT_FEATURES_ADDR_FEATURES_4_HIGH);
}

u32 XPredict_Get_features_4_TotalBytes(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (XPREDICT_FEATURES_ADDR_FEATURES_4_HIGH - XPREDICT_FEATURES_ADDR_FEATURES_4_BASE + 1);
}

u32 XPredict_Get_features_4_BitWidth(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XPREDICT_FEATURES_WIDTH_FEATURES_4;
}

u32 XPredict_Get_features_4_Depth(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XPREDICT_FEATURES_DEPTH_FEATURES_4;
}

u32 XPredict_Write_features_4_Words(XPredict *InstancePtr, int offset, word_type *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length)*4 > (XPREDICT_FEATURES_ADDR_FEATURES_4_HIGH - XPREDICT_FEATURES_ADDR_FEATURES_4_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(int *)(InstancePtr->Features_BaseAddress + XPREDICT_FEATURES_ADDR_FEATURES_4_BASE + (offset + i)*4) = *(data + i);
    }
    return length;
}

u32 XPredict_Read_features_4_Words(XPredict *InstancePtr, int offset, word_type *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length)*4 > (XPREDICT_FEATURES_ADDR_FEATURES_4_HIGH - XPREDICT_FEATURES_ADDR_FEATURES_4_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(data + i) = *(int *)(InstancePtr->Features_BaseAddress + XPREDICT_FEATURES_ADDR_FEATURES_4_BASE + (offset + i)*4);
    }
    return length;
}

u32 XPredict_Write_features_4_Bytes(XPredict *InstancePtr, int offset, char *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length) > (XPREDICT_FEATURES_ADDR_FEATURES_4_HIGH - XPREDICT_FEATURES_ADDR_FEATURES_4_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(char *)(InstancePtr->Features_BaseAddress + XPREDICT_FEATURES_ADDR_FEATURES_4_BASE + offset + i) = *(data + i);
    }
    return length;
}

u32 XPredict_Read_features_4_Bytes(XPredict *InstancePtr, int offset, char *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length) > (XPREDICT_FEATURES_ADDR_FEATURES_4_HIGH - XPREDICT_FEATURES_ADDR_FEATURES_4_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(data + i) = *(char *)(InstancePtr->Features_BaseAddress + XPREDICT_FEATURES_ADDR_FEATURES_4_BASE + offset + i);
    }
    return length;
}

u32 XPredict_Get_features_5_BaseAddress(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (InstancePtr->Features_BaseAddress + XPREDICT_FEATURES_ADDR_FEATURES_5_BASE);
}

u32 XPredict_Get_features_5_HighAddress(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (InstancePtr->Features_BaseAddress + XPREDICT_FEATURES_ADDR_FEATURES_5_HIGH);
}

u32 XPredict_Get_features_5_TotalBytes(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (XPREDICT_FEATURES_ADDR_FEATURES_5_HIGH - XPREDICT_FEATURES_ADDR_FEATURES_5_BASE + 1);
}

u32 XPredict_Get_features_5_BitWidth(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XPREDICT_FEATURES_WIDTH_FEATURES_5;
}

u32 XPredict_Get_features_5_Depth(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XPREDICT_FEATURES_DEPTH_FEATURES_5;
}

u32 XPredict_Write_features_5_Words(XPredict *InstancePtr, int offset, word_type *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length)*4 > (XPREDICT_FEATURES_ADDR_FEATURES_5_HIGH - XPREDICT_FEATURES_ADDR_FEATURES_5_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(int *)(InstancePtr->Features_BaseAddress + XPREDICT_FEATURES_ADDR_FEATURES_5_BASE + (offset + i)*4) = *(data + i);
    }
    return length;
}

u32 XPredict_Read_features_5_Words(XPredict *InstancePtr, int offset, word_type *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length)*4 > (XPREDICT_FEATURES_ADDR_FEATURES_5_HIGH - XPREDICT_FEATURES_ADDR_FEATURES_5_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(data + i) = *(int *)(InstancePtr->Features_BaseAddress + XPREDICT_FEATURES_ADDR_FEATURES_5_BASE + (offset + i)*4);
    }
    return length;
}

u32 XPredict_Write_features_5_Bytes(XPredict *InstancePtr, int offset, char *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length) > (XPREDICT_FEATURES_ADDR_FEATURES_5_HIGH - XPREDICT_FEATURES_ADDR_FEATURES_5_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(char *)(InstancePtr->Features_BaseAddress + XPREDICT_FEATURES_ADDR_FEATURES_5_BASE + offset + i) = *(data + i);
    }
    return length;
}

u32 XPredict_Read_features_5_Bytes(XPredict *InstancePtr, int offset, char *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length) > (XPREDICT_FEATURES_ADDR_FEATURES_5_HIGH - XPREDICT_FEATURES_ADDR_FEATURES_5_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(data + i) = *(char *)(InstancePtr->Features_BaseAddress + XPREDICT_FEATURES_ADDR_FEATURES_5_BASE + offset + i);
    }
    return length;
}

u32 XPredict_Get_features_6_BaseAddress(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (InstancePtr->Features_BaseAddress + XPREDICT_FEATURES_ADDR_FEATURES_6_BASE);
}

u32 XPredict_Get_features_6_HighAddress(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (InstancePtr->Features_BaseAddress + XPREDICT_FEATURES_ADDR_FEATURES_6_HIGH);
}

u32 XPredict_Get_features_6_TotalBytes(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (XPREDICT_FEATURES_ADDR_FEATURES_6_HIGH - XPREDICT_FEATURES_ADDR_FEATURES_6_BASE + 1);
}

u32 XPredict_Get_features_6_BitWidth(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XPREDICT_FEATURES_WIDTH_FEATURES_6;
}

u32 XPredict_Get_features_6_Depth(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XPREDICT_FEATURES_DEPTH_FEATURES_6;
}

u32 XPredict_Write_features_6_Words(XPredict *InstancePtr, int offset, word_type *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length)*4 > (XPREDICT_FEATURES_ADDR_FEATURES_6_HIGH - XPREDICT_FEATURES_ADDR_FEATURES_6_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(int *)(InstancePtr->Features_BaseAddress + XPREDICT_FEATURES_ADDR_FEATURES_6_BASE + (offset + i)*4) = *(data + i);
    }
    return length;
}

u32 XPredict_Read_features_6_Words(XPredict *InstancePtr, int offset, word_type *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length)*4 > (XPREDICT_FEATURES_ADDR_FEATURES_6_HIGH - XPREDICT_FEATURES_ADDR_FEATURES_6_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(data + i) = *(int *)(InstancePtr->Features_BaseAddress + XPREDICT_FEATURES_ADDR_FEATURES_6_BASE + (offset + i)*4);
    }
    return length;
}

u32 XPredict_Write_features_6_Bytes(XPredict *InstancePtr, int offset, char *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length) > (XPREDICT_FEATURES_ADDR_FEATURES_6_HIGH - XPREDICT_FEATURES_ADDR_FEATURES_6_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(char *)(InstancePtr->Features_BaseAddress + XPREDICT_FEATURES_ADDR_FEATURES_6_BASE + offset + i) = *(data + i);
    }
    return length;
}

u32 XPredict_Read_features_6_Bytes(XPredict *InstancePtr, int offset, char *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length) > (XPREDICT_FEATURES_ADDR_FEATURES_6_HIGH - XPREDICT_FEATURES_ADDR_FEATURES_6_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(data + i) = *(char *)(InstancePtr->Features_BaseAddress + XPREDICT_FEATURES_ADDR_FEATURES_6_BASE + offset + i);
    }
    return length;
}

u32 XPredict_Get_features_7_BaseAddress(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (InstancePtr->Features_BaseAddress + XPREDICT_FEATURES_ADDR_FEATURES_7_BASE);
}

u32 XPredict_Get_features_7_HighAddress(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (InstancePtr->Features_BaseAddress + XPREDICT_FEATURES_ADDR_FEATURES_7_HIGH);
}

u32 XPredict_Get_features_7_TotalBytes(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (XPREDICT_FEATURES_ADDR_FEATURES_7_HIGH - XPREDICT_FEATURES_ADDR_FEATURES_7_BASE + 1);
}

u32 XPredict_Get_features_7_BitWidth(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XPREDICT_FEATURES_WIDTH_FEATURES_7;
}

u32 XPredict_Get_features_7_Depth(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XPREDICT_FEATURES_DEPTH_FEATURES_7;
}

u32 XPredict_Write_features_7_Words(XPredict *InstancePtr, int offset, word_type *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length)*4 > (XPREDICT_FEATURES_ADDR_FEATURES_7_HIGH - XPREDICT_FEATURES_ADDR_FEATURES_7_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(int *)(InstancePtr->Features_BaseAddress + XPREDICT_FEATURES_ADDR_FEATURES_7_BASE + (offset + i)*4) = *(data + i);
    }
    return length;
}

u32 XPredict_Read_features_7_Words(XPredict *InstancePtr, int offset, word_type *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length)*4 > (XPREDICT_FEATURES_ADDR_FEATURES_7_HIGH - XPREDICT_FEATURES_ADDR_FEATURES_7_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(data + i) = *(int *)(InstancePtr->Features_BaseAddress + XPREDICT_FEATURES_ADDR_FEATURES_7_BASE + (offset + i)*4);
    }
    return length;
}

u32 XPredict_Write_features_7_Bytes(XPredict *InstancePtr, int offset, char *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length) > (XPREDICT_FEATURES_ADDR_FEATURES_7_HIGH - XPREDICT_FEATURES_ADDR_FEATURES_7_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(char *)(InstancePtr->Features_BaseAddress + XPREDICT_FEATURES_ADDR_FEATURES_7_BASE + offset + i) = *(data + i);
    }
    return length;
}

u32 XPredict_Read_features_7_Bytes(XPredict *InstancePtr, int offset, char *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length) > (XPREDICT_FEATURES_ADDR_FEATURES_7_HIGH - XPREDICT_FEATURES_ADDR_FEATURES_7_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(data + i) = *(char *)(InstancePtr->Features_BaseAddress + XPREDICT_FEATURES_ADDR_FEATURES_7_BASE + offset + i);
    }
    return length;
}

u32 XPredict_Get_features_8_BaseAddress(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (InstancePtr->Features_BaseAddress + XPREDICT_FEATURES_ADDR_FEATURES_8_BASE);
}

u32 XPredict_Get_features_8_HighAddress(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (InstancePtr->Features_BaseAddress + XPREDICT_FEATURES_ADDR_FEATURES_8_HIGH);
}

u32 XPredict_Get_features_8_TotalBytes(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (XPREDICT_FEATURES_ADDR_FEATURES_8_HIGH - XPREDICT_FEATURES_ADDR_FEATURES_8_BASE + 1);
}

u32 XPredict_Get_features_8_BitWidth(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XPREDICT_FEATURES_WIDTH_FEATURES_8;
}

u32 XPredict_Get_features_8_Depth(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XPREDICT_FEATURES_DEPTH_FEATURES_8;
}

u32 XPredict_Write_features_8_Words(XPredict *InstancePtr, int offset, word_type *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length)*4 > (XPREDICT_FEATURES_ADDR_FEATURES_8_HIGH - XPREDICT_FEATURES_ADDR_FEATURES_8_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(int *)(InstancePtr->Features_BaseAddress + XPREDICT_FEATURES_ADDR_FEATURES_8_BASE + (offset + i)*4) = *(data + i);
    }
    return length;
}

u32 XPredict_Read_features_8_Words(XPredict *InstancePtr, int offset, word_type *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length)*4 > (XPREDICT_FEATURES_ADDR_FEATURES_8_HIGH - XPREDICT_FEATURES_ADDR_FEATURES_8_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(data + i) = *(int *)(InstancePtr->Features_BaseAddress + XPREDICT_FEATURES_ADDR_FEATURES_8_BASE + (offset + i)*4);
    }
    return length;
}

u32 XPredict_Write_features_8_Bytes(XPredict *InstancePtr, int offset, char *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length) > (XPREDICT_FEATURES_ADDR_FEATURES_8_HIGH - XPREDICT_FEATURES_ADDR_FEATURES_8_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(char *)(InstancePtr->Features_BaseAddress + XPREDICT_FEATURES_ADDR_FEATURES_8_BASE + offset + i) = *(data + i);
    }
    return length;
}

u32 XPredict_Read_features_8_Bytes(XPredict *InstancePtr, int offset, char *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length) > (XPREDICT_FEATURES_ADDR_FEATURES_8_HIGH - XPREDICT_FEATURES_ADDR_FEATURES_8_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(data + i) = *(char *)(InstancePtr->Features_BaseAddress + XPREDICT_FEATURES_ADDR_FEATURES_8_BASE + offset + i);
    }
    return length;
}

u32 XPredict_Get_features_9_BaseAddress(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (InstancePtr->Features_BaseAddress + XPREDICT_FEATURES_ADDR_FEATURES_9_BASE);
}

u32 XPredict_Get_features_9_HighAddress(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (InstancePtr->Features_BaseAddress + XPREDICT_FEATURES_ADDR_FEATURES_9_HIGH);
}

u32 XPredict_Get_features_9_TotalBytes(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (XPREDICT_FEATURES_ADDR_FEATURES_9_HIGH - XPREDICT_FEATURES_ADDR_FEATURES_9_BASE + 1);
}

u32 XPredict_Get_features_9_BitWidth(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XPREDICT_FEATURES_WIDTH_FEATURES_9;
}

u32 XPredict_Get_features_9_Depth(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XPREDICT_FEATURES_DEPTH_FEATURES_9;
}

u32 XPredict_Write_features_9_Words(XPredict *InstancePtr, int offset, word_type *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length)*4 > (XPREDICT_FEATURES_ADDR_FEATURES_9_HIGH - XPREDICT_FEATURES_ADDR_FEATURES_9_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(int *)(InstancePtr->Features_BaseAddress + XPREDICT_FEATURES_ADDR_FEATURES_9_BASE + (offset + i)*4) = *(data + i);
    }
    return length;
}

u32 XPredict_Read_features_9_Words(XPredict *InstancePtr, int offset, word_type *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length)*4 > (XPREDICT_FEATURES_ADDR_FEATURES_9_HIGH - XPREDICT_FEATURES_ADDR_FEATURES_9_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(data + i) = *(int *)(InstancePtr->Features_BaseAddress + XPREDICT_FEATURES_ADDR_FEATURES_9_BASE + (offset + i)*4);
    }
    return length;
}

u32 XPredict_Write_features_9_Bytes(XPredict *InstancePtr, int offset, char *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length) > (XPREDICT_FEATURES_ADDR_FEATURES_9_HIGH - XPREDICT_FEATURES_ADDR_FEATURES_9_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(char *)(InstancePtr->Features_BaseAddress + XPREDICT_FEATURES_ADDR_FEATURES_9_BASE + offset + i) = *(data + i);
    }
    return length;
}

u32 XPredict_Read_features_9_Bytes(XPredict *InstancePtr, int offset, char *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length) > (XPREDICT_FEATURES_ADDR_FEATURES_9_HIGH - XPREDICT_FEATURES_ADDR_FEATURES_9_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(data + i) = *(char *)(InstancePtr->Features_BaseAddress + XPREDICT_FEATURES_ADDR_FEATURES_9_BASE + offset + i);
    }
    return length;
}

u32 XPredict_Get_features_10_BaseAddress(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (InstancePtr->Features_BaseAddress + XPREDICT_FEATURES_ADDR_FEATURES_10_BASE);
}

u32 XPredict_Get_features_10_HighAddress(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (InstancePtr->Features_BaseAddress + XPREDICT_FEATURES_ADDR_FEATURES_10_HIGH);
}

u32 XPredict_Get_features_10_TotalBytes(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (XPREDICT_FEATURES_ADDR_FEATURES_10_HIGH - XPREDICT_FEATURES_ADDR_FEATURES_10_BASE + 1);
}

u32 XPredict_Get_features_10_BitWidth(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XPREDICT_FEATURES_WIDTH_FEATURES_10;
}

u32 XPredict_Get_features_10_Depth(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XPREDICT_FEATURES_DEPTH_FEATURES_10;
}

u32 XPredict_Write_features_10_Words(XPredict *InstancePtr, int offset, word_type *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length)*4 > (XPREDICT_FEATURES_ADDR_FEATURES_10_HIGH - XPREDICT_FEATURES_ADDR_FEATURES_10_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(int *)(InstancePtr->Features_BaseAddress + XPREDICT_FEATURES_ADDR_FEATURES_10_BASE + (offset + i)*4) = *(data + i);
    }
    return length;
}

u32 XPredict_Read_features_10_Words(XPredict *InstancePtr, int offset, word_type *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length)*4 > (XPREDICT_FEATURES_ADDR_FEATURES_10_HIGH - XPREDICT_FEATURES_ADDR_FEATURES_10_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(data + i) = *(int *)(InstancePtr->Features_BaseAddress + XPREDICT_FEATURES_ADDR_FEATURES_10_BASE + (offset + i)*4);
    }
    return length;
}

u32 XPredict_Write_features_10_Bytes(XPredict *InstancePtr, int offset, char *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length) > (XPREDICT_FEATURES_ADDR_FEATURES_10_HIGH - XPREDICT_FEATURES_ADDR_FEATURES_10_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(char *)(InstancePtr->Features_BaseAddress + XPREDICT_FEATURES_ADDR_FEATURES_10_BASE + offset + i) = *(data + i);
    }
    return length;
}

u32 XPredict_Read_features_10_Bytes(XPredict *InstancePtr, int offset, char *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length) > (XPREDICT_FEATURES_ADDR_FEATURES_10_HIGH - XPREDICT_FEATURES_ADDR_FEATURES_10_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(data + i) = *(char *)(InstancePtr->Features_BaseAddress + XPREDICT_FEATURES_ADDR_FEATURES_10_BASE + offset + i);
    }
    return length;
}

u32 XPredict_Get_features_11_BaseAddress(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (InstancePtr->Features_BaseAddress + XPREDICT_FEATURES_ADDR_FEATURES_11_BASE);
}

u32 XPredict_Get_features_11_HighAddress(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (InstancePtr->Features_BaseAddress + XPREDICT_FEATURES_ADDR_FEATURES_11_HIGH);
}

u32 XPredict_Get_features_11_TotalBytes(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (XPREDICT_FEATURES_ADDR_FEATURES_11_HIGH - XPREDICT_FEATURES_ADDR_FEATURES_11_BASE + 1);
}

u32 XPredict_Get_features_11_BitWidth(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XPREDICT_FEATURES_WIDTH_FEATURES_11;
}

u32 XPredict_Get_features_11_Depth(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XPREDICT_FEATURES_DEPTH_FEATURES_11;
}

u32 XPredict_Write_features_11_Words(XPredict *InstancePtr, int offset, word_type *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length)*4 > (XPREDICT_FEATURES_ADDR_FEATURES_11_HIGH - XPREDICT_FEATURES_ADDR_FEATURES_11_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(int *)(InstancePtr->Features_BaseAddress + XPREDICT_FEATURES_ADDR_FEATURES_11_BASE + (offset + i)*4) = *(data + i);
    }
    return length;
}

u32 XPredict_Read_features_11_Words(XPredict *InstancePtr, int offset, word_type *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length)*4 > (XPREDICT_FEATURES_ADDR_FEATURES_11_HIGH - XPREDICT_FEATURES_ADDR_FEATURES_11_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(data + i) = *(int *)(InstancePtr->Features_BaseAddress + XPREDICT_FEATURES_ADDR_FEATURES_11_BASE + (offset + i)*4);
    }
    return length;
}

u32 XPredict_Write_features_11_Bytes(XPredict *InstancePtr, int offset, char *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length) > (XPREDICT_FEATURES_ADDR_FEATURES_11_HIGH - XPREDICT_FEATURES_ADDR_FEATURES_11_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(char *)(InstancePtr->Features_BaseAddress + XPREDICT_FEATURES_ADDR_FEATURES_11_BASE + offset + i) = *(data + i);
    }
    return length;
}

u32 XPredict_Read_features_11_Bytes(XPredict *InstancePtr, int offset, char *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length) > (XPREDICT_FEATURES_ADDR_FEATURES_11_HIGH - XPREDICT_FEATURES_ADDR_FEATURES_11_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(data + i) = *(char *)(InstancePtr->Features_BaseAddress + XPREDICT_FEATURES_ADDR_FEATURES_11_BASE + offset + i);
    }
    return length;
}

u32 XPredict_Get_features_12_BaseAddress(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (InstancePtr->Features_BaseAddress + XPREDICT_FEATURES_ADDR_FEATURES_12_BASE);
}

u32 XPredict_Get_features_12_HighAddress(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (InstancePtr->Features_BaseAddress + XPREDICT_FEATURES_ADDR_FEATURES_12_HIGH);
}

u32 XPredict_Get_features_12_TotalBytes(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (XPREDICT_FEATURES_ADDR_FEATURES_12_HIGH - XPREDICT_FEATURES_ADDR_FEATURES_12_BASE + 1);
}

u32 XPredict_Get_features_12_BitWidth(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XPREDICT_FEATURES_WIDTH_FEATURES_12;
}

u32 XPredict_Get_features_12_Depth(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XPREDICT_FEATURES_DEPTH_FEATURES_12;
}

u32 XPredict_Write_features_12_Words(XPredict *InstancePtr, int offset, word_type *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length)*4 > (XPREDICT_FEATURES_ADDR_FEATURES_12_HIGH - XPREDICT_FEATURES_ADDR_FEATURES_12_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(int *)(InstancePtr->Features_BaseAddress + XPREDICT_FEATURES_ADDR_FEATURES_12_BASE + (offset + i)*4) = *(data + i);
    }
    return length;
}

u32 XPredict_Read_features_12_Words(XPredict *InstancePtr, int offset, word_type *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length)*4 > (XPREDICT_FEATURES_ADDR_FEATURES_12_HIGH - XPREDICT_FEATURES_ADDR_FEATURES_12_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(data + i) = *(int *)(InstancePtr->Features_BaseAddress + XPREDICT_FEATURES_ADDR_FEATURES_12_BASE + (offset + i)*4);
    }
    return length;
}

u32 XPredict_Write_features_12_Bytes(XPredict *InstancePtr, int offset, char *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length) > (XPREDICT_FEATURES_ADDR_FEATURES_12_HIGH - XPREDICT_FEATURES_ADDR_FEATURES_12_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(char *)(InstancePtr->Features_BaseAddress + XPREDICT_FEATURES_ADDR_FEATURES_12_BASE + offset + i) = *(data + i);
    }
    return length;
}

u32 XPredict_Read_features_12_Bytes(XPredict *InstancePtr, int offset, char *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length) > (XPREDICT_FEATURES_ADDR_FEATURES_12_HIGH - XPREDICT_FEATURES_ADDR_FEATURES_12_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(data + i) = *(char *)(InstancePtr->Features_BaseAddress + XPREDICT_FEATURES_ADDR_FEATURES_12_BASE + offset + i);
    }
    return length;
}

u32 XPredict_Get_features_13_BaseAddress(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (InstancePtr->Features_BaseAddress + XPREDICT_FEATURES_ADDR_FEATURES_13_BASE);
}

u32 XPredict_Get_features_13_HighAddress(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (InstancePtr->Features_BaseAddress + XPREDICT_FEATURES_ADDR_FEATURES_13_HIGH);
}

u32 XPredict_Get_features_13_TotalBytes(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (XPREDICT_FEATURES_ADDR_FEATURES_13_HIGH - XPREDICT_FEATURES_ADDR_FEATURES_13_BASE + 1);
}

u32 XPredict_Get_features_13_BitWidth(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XPREDICT_FEATURES_WIDTH_FEATURES_13;
}

u32 XPredict_Get_features_13_Depth(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XPREDICT_FEATURES_DEPTH_FEATURES_13;
}

u32 XPredict_Write_features_13_Words(XPredict *InstancePtr, int offset, word_type *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length)*4 > (XPREDICT_FEATURES_ADDR_FEATURES_13_HIGH - XPREDICT_FEATURES_ADDR_FEATURES_13_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(int *)(InstancePtr->Features_BaseAddress + XPREDICT_FEATURES_ADDR_FEATURES_13_BASE + (offset + i)*4) = *(data + i);
    }
    return length;
}

u32 XPredict_Read_features_13_Words(XPredict *InstancePtr, int offset, word_type *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length)*4 > (XPREDICT_FEATURES_ADDR_FEATURES_13_HIGH - XPREDICT_FEATURES_ADDR_FEATURES_13_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(data + i) = *(int *)(InstancePtr->Features_BaseAddress + XPREDICT_FEATURES_ADDR_FEATURES_13_BASE + (offset + i)*4);
    }
    return length;
}

u32 XPredict_Write_features_13_Bytes(XPredict *InstancePtr, int offset, char *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length) > (XPREDICT_FEATURES_ADDR_FEATURES_13_HIGH - XPREDICT_FEATURES_ADDR_FEATURES_13_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(char *)(InstancePtr->Features_BaseAddress + XPREDICT_FEATURES_ADDR_FEATURES_13_BASE + offset + i) = *(data + i);
    }
    return length;
}

u32 XPredict_Read_features_13_Bytes(XPredict *InstancePtr, int offset, char *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length) > (XPREDICT_FEATURES_ADDR_FEATURES_13_HIGH - XPREDICT_FEATURES_ADDR_FEATURES_13_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(data + i) = *(char *)(InstancePtr->Features_BaseAddress + XPREDICT_FEATURES_ADDR_FEATURES_13_BASE + offset + i);
    }
    return length;
}

u32 XPredict_Get_features_14_BaseAddress(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (InstancePtr->Features_BaseAddress + XPREDICT_FEATURES_ADDR_FEATURES_14_BASE);
}

u32 XPredict_Get_features_14_HighAddress(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (InstancePtr->Features_BaseAddress + XPREDICT_FEATURES_ADDR_FEATURES_14_HIGH);
}

u32 XPredict_Get_features_14_TotalBytes(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (XPREDICT_FEATURES_ADDR_FEATURES_14_HIGH - XPREDICT_FEATURES_ADDR_FEATURES_14_BASE + 1);
}

u32 XPredict_Get_features_14_BitWidth(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XPREDICT_FEATURES_WIDTH_FEATURES_14;
}

u32 XPredict_Get_features_14_Depth(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XPREDICT_FEATURES_DEPTH_FEATURES_14;
}

u32 XPredict_Write_features_14_Words(XPredict *InstancePtr, int offset, word_type *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length)*4 > (XPREDICT_FEATURES_ADDR_FEATURES_14_HIGH - XPREDICT_FEATURES_ADDR_FEATURES_14_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(int *)(InstancePtr->Features_BaseAddress + XPREDICT_FEATURES_ADDR_FEATURES_14_BASE + (offset + i)*4) = *(data + i);
    }
    return length;
}

u32 XPredict_Read_features_14_Words(XPredict *InstancePtr, int offset, word_type *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length)*4 > (XPREDICT_FEATURES_ADDR_FEATURES_14_HIGH - XPREDICT_FEATURES_ADDR_FEATURES_14_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(data + i) = *(int *)(InstancePtr->Features_BaseAddress + XPREDICT_FEATURES_ADDR_FEATURES_14_BASE + (offset + i)*4);
    }
    return length;
}

u32 XPredict_Write_features_14_Bytes(XPredict *InstancePtr, int offset, char *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length) > (XPREDICT_FEATURES_ADDR_FEATURES_14_HIGH - XPREDICT_FEATURES_ADDR_FEATURES_14_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(char *)(InstancePtr->Features_BaseAddress + XPREDICT_FEATURES_ADDR_FEATURES_14_BASE + offset + i) = *(data + i);
    }
    return length;
}

u32 XPredict_Read_features_14_Bytes(XPredict *InstancePtr, int offset, char *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length) > (XPREDICT_FEATURES_ADDR_FEATURES_14_HIGH - XPREDICT_FEATURES_ADDR_FEATURES_14_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(data + i) = *(char *)(InstancePtr->Features_BaseAddress + XPREDICT_FEATURES_ADDR_FEATURES_14_BASE + offset + i);
    }
    return length;
}

u32 XPredict_Get_features_15_BaseAddress(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (InstancePtr->Features_BaseAddress + XPREDICT_FEATURES_ADDR_FEATURES_15_BASE);
}

u32 XPredict_Get_features_15_HighAddress(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (InstancePtr->Features_BaseAddress + XPREDICT_FEATURES_ADDR_FEATURES_15_HIGH);
}

u32 XPredict_Get_features_15_TotalBytes(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (XPREDICT_FEATURES_ADDR_FEATURES_15_HIGH - XPREDICT_FEATURES_ADDR_FEATURES_15_BASE + 1);
}

u32 XPredict_Get_features_15_BitWidth(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XPREDICT_FEATURES_WIDTH_FEATURES_15;
}

u32 XPredict_Get_features_15_Depth(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XPREDICT_FEATURES_DEPTH_FEATURES_15;
}

u32 XPredict_Write_features_15_Words(XPredict *InstancePtr, int offset, word_type *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length)*4 > (XPREDICT_FEATURES_ADDR_FEATURES_15_HIGH - XPREDICT_FEATURES_ADDR_FEATURES_15_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(int *)(InstancePtr->Features_BaseAddress + XPREDICT_FEATURES_ADDR_FEATURES_15_BASE + (offset + i)*4) = *(data + i);
    }
    return length;
}

u32 XPredict_Read_features_15_Words(XPredict *InstancePtr, int offset, word_type *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length)*4 > (XPREDICT_FEATURES_ADDR_FEATURES_15_HIGH - XPREDICT_FEATURES_ADDR_FEATURES_15_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(data + i) = *(int *)(InstancePtr->Features_BaseAddress + XPREDICT_FEATURES_ADDR_FEATURES_15_BASE + (offset + i)*4);
    }
    return length;
}

u32 XPredict_Write_features_15_Bytes(XPredict *InstancePtr, int offset, char *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length) > (XPREDICT_FEATURES_ADDR_FEATURES_15_HIGH - XPREDICT_FEATURES_ADDR_FEATURES_15_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(char *)(InstancePtr->Features_BaseAddress + XPREDICT_FEATURES_ADDR_FEATURES_15_BASE + offset + i) = *(data + i);
    }
    return length;
}

u32 XPredict_Read_features_15_Bytes(XPredict *InstancePtr, int offset, char *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length) > (XPREDICT_FEATURES_ADDR_FEATURES_15_HIGH - XPREDICT_FEATURES_ADDR_FEATURES_15_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(data + i) = *(char *)(InstancePtr->Features_BaseAddress + XPREDICT_FEATURES_ADDR_FEATURES_15_BASE + offset + i);
    }
    return length;
}

u32 XPredict_Get_features_16_BaseAddress(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (InstancePtr->Features_BaseAddress + XPREDICT_FEATURES_ADDR_FEATURES_16_BASE);
}

u32 XPredict_Get_features_16_HighAddress(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (InstancePtr->Features_BaseAddress + XPREDICT_FEATURES_ADDR_FEATURES_16_HIGH);
}

u32 XPredict_Get_features_16_TotalBytes(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (XPREDICT_FEATURES_ADDR_FEATURES_16_HIGH - XPREDICT_FEATURES_ADDR_FEATURES_16_BASE + 1);
}

u32 XPredict_Get_features_16_BitWidth(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XPREDICT_FEATURES_WIDTH_FEATURES_16;
}

u32 XPredict_Get_features_16_Depth(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XPREDICT_FEATURES_DEPTH_FEATURES_16;
}

u32 XPredict_Write_features_16_Words(XPredict *InstancePtr, int offset, word_type *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length)*4 > (XPREDICT_FEATURES_ADDR_FEATURES_16_HIGH - XPREDICT_FEATURES_ADDR_FEATURES_16_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(int *)(InstancePtr->Features_BaseAddress + XPREDICT_FEATURES_ADDR_FEATURES_16_BASE + (offset + i)*4) = *(data + i);
    }
    return length;
}

u32 XPredict_Read_features_16_Words(XPredict *InstancePtr, int offset, word_type *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length)*4 > (XPREDICT_FEATURES_ADDR_FEATURES_16_HIGH - XPREDICT_FEATURES_ADDR_FEATURES_16_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(data + i) = *(int *)(InstancePtr->Features_BaseAddress + XPREDICT_FEATURES_ADDR_FEATURES_16_BASE + (offset + i)*4);
    }
    return length;
}

u32 XPredict_Write_features_16_Bytes(XPredict *InstancePtr, int offset, char *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length) > (XPREDICT_FEATURES_ADDR_FEATURES_16_HIGH - XPREDICT_FEATURES_ADDR_FEATURES_16_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(char *)(InstancePtr->Features_BaseAddress + XPREDICT_FEATURES_ADDR_FEATURES_16_BASE + offset + i) = *(data + i);
    }
    return length;
}

u32 XPredict_Read_features_16_Bytes(XPredict *InstancePtr, int offset, char *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length) > (XPREDICT_FEATURES_ADDR_FEATURES_16_HIGH - XPREDICT_FEATURES_ADDR_FEATURES_16_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(data + i) = *(char *)(InstancePtr->Features_BaseAddress + XPREDICT_FEATURES_ADDR_FEATURES_16_BASE + offset + i);
    }
    return length;
}

u32 XPredict_Get_features_17_BaseAddress(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (InstancePtr->Features_BaseAddress + XPREDICT_FEATURES_ADDR_FEATURES_17_BASE);
}

u32 XPredict_Get_features_17_HighAddress(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (InstancePtr->Features_BaseAddress + XPREDICT_FEATURES_ADDR_FEATURES_17_HIGH);
}

u32 XPredict_Get_features_17_TotalBytes(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (XPREDICT_FEATURES_ADDR_FEATURES_17_HIGH - XPREDICT_FEATURES_ADDR_FEATURES_17_BASE + 1);
}

u32 XPredict_Get_features_17_BitWidth(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XPREDICT_FEATURES_WIDTH_FEATURES_17;
}

u32 XPredict_Get_features_17_Depth(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XPREDICT_FEATURES_DEPTH_FEATURES_17;
}

u32 XPredict_Write_features_17_Words(XPredict *InstancePtr, int offset, word_type *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length)*4 > (XPREDICT_FEATURES_ADDR_FEATURES_17_HIGH - XPREDICT_FEATURES_ADDR_FEATURES_17_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(int *)(InstancePtr->Features_BaseAddress + XPREDICT_FEATURES_ADDR_FEATURES_17_BASE + (offset + i)*4) = *(data + i);
    }
    return length;
}

u32 XPredict_Read_features_17_Words(XPredict *InstancePtr, int offset, word_type *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length)*4 > (XPREDICT_FEATURES_ADDR_FEATURES_17_HIGH - XPREDICT_FEATURES_ADDR_FEATURES_17_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(data + i) = *(int *)(InstancePtr->Features_BaseAddress + XPREDICT_FEATURES_ADDR_FEATURES_17_BASE + (offset + i)*4);
    }
    return length;
}

u32 XPredict_Write_features_17_Bytes(XPredict *InstancePtr, int offset, char *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length) > (XPREDICT_FEATURES_ADDR_FEATURES_17_HIGH - XPREDICT_FEATURES_ADDR_FEATURES_17_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(char *)(InstancePtr->Features_BaseAddress + XPREDICT_FEATURES_ADDR_FEATURES_17_BASE + offset + i) = *(data + i);
    }
    return length;
}

u32 XPredict_Read_features_17_Bytes(XPredict *InstancePtr, int offset, char *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length) > (XPREDICT_FEATURES_ADDR_FEATURES_17_HIGH - XPREDICT_FEATURES_ADDR_FEATURES_17_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(data + i) = *(char *)(InstancePtr->Features_BaseAddress + XPREDICT_FEATURES_ADDR_FEATURES_17_BASE + offset + i);
    }
    return length;
}

u32 XPredict_Get_features_18_BaseAddress(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (InstancePtr->Features_BaseAddress + XPREDICT_FEATURES_ADDR_FEATURES_18_BASE);
}

u32 XPredict_Get_features_18_HighAddress(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (InstancePtr->Features_BaseAddress + XPREDICT_FEATURES_ADDR_FEATURES_18_HIGH);
}

u32 XPredict_Get_features_18_TotalBytes(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (XPREDICT_FEATURES_ADDR_FEATURES_18_HIGH - XPREDICT_FEATURES_ADDR_FEATURES_18_BASE + 1);
}

u32 XPredict_Get_features_18_BitWidth(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XPREDICT_FEATURES_WIDTH_FEATURES_18;
}

u32 XPredict_Get_features_18_Depth(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XPREDICT_FEATURES_DEPTH_FEATURES_18;
}

u32 XPredict_Write_features_18_Words(XPredict *InstancePtr, int offset, word_type *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length)*4 > (XPREDICT_FEATURES_ADDR_FEATURES_18_HIGH - XPREDICT_FEATURES_ADDR_FEATURES_18_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(int *)(InstancePtr->Features_BaseAddress + XPREDICT_FEATURES_ADDR_FEATURES_18_BASE + (offset + i)*4) = *(data + i);
    }
    return length;
}

u32 XPredict_Read_features_18_Words(XPredict *InstancePtr, int offset, word_type *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length)*4 > (XPREDICT_FEATURES_ADDR_FEATURES_18_HIGH - XPREDICT_FEATURES_ADDR_FEATURES_18_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(data + i) = *(int *)(InstancePtr->Features_BaseAddress + XPREDICT_FEATURES_ADDR_FEATURES_18_BASE + (offset + i)*4);
    }
    return length;
}

u32 XPredict_Write_features_18_Bytes(XPredict *InstancePtr, int offset, char *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length) > (XPREDICT_FEATURES_ADDR_FEATURES_18_HIGH - XPREDICT_FEATURES_ADDR_FEATURES_18_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(char *)(InstancePtr->Features_BaseAddress + XPREDICT_FEATURES_ADDR_FEATURES_18_BASE + offset + i) = *(data + i);
    }
    return length;
}

u32 XPredict_Read_features_18_Bytes(XPredict *InstancePtr, int offset, char *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length) > (XPREDICT_FEATURES_ADDR_FEATURES_18_HIGH - XPREDICT_FEATURES_ADDR_FEATURES_18_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(data + i) = *(char *)(InstancePtr->Features_BaseAddress + XPREDICT_FEATURES_ADDR_FEATURES_18_BASE + offset + i);
    }
    return length;
}

u32 XPredict_Get_features_19_BaseAddress(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (InstancePtr->Features_BaseAddress + XPREDICT_FEATURES_ADDR_FEATURES_19_BASE);
}

u32 XPredict_Get_features_19_HighAddress(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (InstancePtr->Features_BaseAddress + XPREDICT_FEATURES_ADDR_FEATURES_19_HIGH);
}

u32 XPredict_Get_features_19_TotalBytes(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (XPREDICT_FEATURES_ADDR_FEATURES_19_HIGH - XPREDICT_FEATURES_ADDR_FEATURES_19_BASE + 1);
}

u32 XPredict_Get_features_19_BitWidth(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XPREDICT_FEATURES_WIDTH_FEATURES_19;
}

u32 XPredict_Get_features_19_Depth(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XPREDICT_FEATURES_DEPTH_FEATURES_19;
}

u32 XPredict_Write_features_19_Words(XPredict *InstancePtr, int offset, word_type *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length)*4 > (XPREDICT_FEATURES_ADDR_FEATURES_19_HIGH - XPREDICT_FEATURES_ADDR_FEATURES_19_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(int *)(InstancePtr->Features_BaseAddress + XPREDICT_FEATURES_ADDR_FEATURES_19_BASE + (offset + i)*4) = *(data + i);
    }
    return length;
}

u32 XPredict_Read_features_19_Words(XPredict *InstancePtr, int offset, word_type *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length)*4 > (XPREDICT_FEATURES_ADDR_FEATURES_19_HIGH - XPREDICT_FEATURES_ADDR_FEATURES_19_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(data + i) = *(int *)(InstancePtr->Features_BaseAddress + XPREDICT_FEATURES_ADDR_FEATURES_19_BASE + (offset + i)*4);
    }
    return length;
}

u32 XPredict_Write_features_19_Bytes(XPredict *InstancePtr, int offset, char *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length) > (XPREDICT_FEATURES_ADDR_FEATURES_19_HIGH - XPREDICT_FEATURES_ADDR_FEATURES_19_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(char *)(InstancePtr->Features_BaseAddress + XPREDICT_FEATURES_ADDR_FEATURES_19_BASE + offset + i) = *(data + i);
    }
    return length;
}

u32 XPredict_Read_features_19_Bytes(XPredict *InstancePtr, int offset, char *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length) > (XPREDICT_FEATURES_ADDR_FEATURES_19_HIGH - XPREDICT_FEATURES_ADDR_FEATURES_19_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(data + i) = *(char *)(InstancePtr->Features_BaseAddress + XPREDICT_FEATURES_ADDR_FEATURES_19_BASE + offset + i);
    }
    return length;
}

u32 XPredict_Get_features_20_BaseAddress(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (InstancePtr->Features_BaseAddress + XPREDICT_FEATURES_ADDR_FEATURES_20_BASE);
}

u32 XPredict_Get_features_20_HighAddress(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (InstancePtr->Features_BaseAddress + XPREDICT_FEATURES_ADDR_FEATURES_20_HIGH);
}

u32 XPredict_Get_features_20_TotalBytes(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (XPREDICT_FEATURES_ADDR_FEATURES_20_HIGH - XPREDICT_FEATURES_ADDR_FEATURES_20_BASE + 1);
}

u32 XPredict_Get_features_20_BitWidth(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XPREDICT_FEATURES_WIDTH_FEATURES_20;
}

u32 XPredict_Get_features_20_Depth(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XPREDICT_FEATURES_DEPTH_FEATURES_20;
}

u32 XPredict_Write_features_20_Words(XPredict *InstancePtr, int offset, word_type *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length)*4 > (XPREDICT_FEATURES_ADDR_FEATURES_20_HIGH - XPREDICT_FEATURES_ADDR_FEATURES_20_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(int *)(InstancePtr->Features_BaseAddress + XPREDICT_FEATURES_ADDR_FEATURES_20_BASE + (offset + i)*4) = *(data + i);
    }
    return length;
}

u32 XPredict_Read_features_20_Words(XPredict *InstancePtr, int offset, word_type *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length)*4 > (XPREDICT_FEATURES_ADDR_FEATURES_20_HIGH - XPREDICT_FEATURES_ADDR_FEATURES_20_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(data + i) = *(int *)(InstancePtr->Features_BaseAddress + XPREDICT_FEATURES_ADDR_FEATURES_20_BASE + (offset + i)*4);
    }
    return length;
}

u32 XPredict_Write_features_20_Bytes(XPredict *InstancePtr, int offset, char *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length) > (XPREDICT_FEATURES_ADDR_FEATURES_20_HIGH - XPREDICT_FEATURES_ADDR_FEATURES_20_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(char *)(InstancePtr->Features_BaseAddress + XPREDICT_FEATURES_ADDR_FEATURES_20_BASE + offset + i) = *(data + i);
    }
    return length;
}

u32 XPredict_Read_features_20_Bytes(XPredict *InstancePtr, int offset, char *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length) > (XPREDICT_FEATURES_ADDR_FEATURES_20_HIGH - XPREDICT_FEATURES_ADDR_FEATURES_20_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(data + i) = *(char *)(InstancePtr->Features_BaseAddress + XPREDICT_FEATURES_ADDR_FEATURES_20_BASE + offset + i);
    }
    return length;
}

u32 XPredict_Get_features_21_BaseAddress(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (InstancePtr->Features_BaseAddress + XPREDICT_FEATURES_ADDR_FEATURES_21_BASE);
}

u32 XPredict_Get_features_21_HighAddress(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (InstancePtr->Features_BaseAddress + XPREDICT_FEATURES_ADDR_FEATURES_21_HIGH);
}

u32 XPredict_Get_features_21_TotalBytes(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (XPREDICT_FEATURES_ADDR_FEATURES_21_HIGH - XPREDICT_FEATURES_ADDR_FEATURES_21_BASE + 1);
}

u32 XPredict_Get_features_21_BitWidth(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XPREDICT_FEATURES_WIDTH_FEATURES_21;
}

u32 XPredict_Get_features_21_Depth(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XPREDICT_FEATURES_DEPTH_FEATURES_21;
}

u32 XPredict_Write_features_21_Words(XPredict *InstancePtr, int offset, word_type *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length)*4 > (XPREDICT_FEATURES_ADDR_FEATURES_21_HIGH - XPREDICT_FEATURES_ADDR_FEATURES_21_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(int *)(InstancePtr->Features_BaseAddress + XPREDICT_FEATURES_ADDR_FEATURES_21_BASE + (offset + i)*4) = *(data + i);
    }
    return length;
}

u32 XPredict_Read_features_21_Words(XPredict *InstancePtr, int offset, word_type *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length)*4 > (XPREDICT_FEATURES_ADDR_FEATURES_21_HIGH - XPREDICT_FEATURES_ADDR_FEATURES_21_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(data + i) = *(int *)(InstancePtr->Features_BaseAddress + XPREDICT_FEATURES_ADDR_FEATURES_21_BASE + (offset + i)*4);
    }
    return length;
}

u32 XPredict_Write_features_21_Bytes(XPredict *InstancePtr, int offset, char *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length) > (XPREDICT_FEATURES_ADDR_FEATURES_21_HIGH - XPREDICT_FEATURES_ADDR_FEATURES_21_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(char *)(InstancePtr->Features_BaseAddress + XPREDICT_FEATURES_ADDR_FEATURES_21_BASE + offset + i) = *(data + i);
    }
    return length;
}

u32 XPredict_Read_features_21_Bytes(XPredict *InstancePtr, int offset, char *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length) > (XPREDICT_FEATURES_ADDR_FEATURES_21_HIGH - XPREDICT_FEATURES_ADDR_FEATURES_21_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(data + i) = *(char *)(InstancePtr->Features_BaseAddress + XPREDICT_FEATURES_ADDR_FEATURES_21_BASE + offset + i);
    }
    return length;
}

u32 XPredict_Get_features_22_BaseAddress(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (InstancePtr->Features_BaseAddress + XPREDICT_FEATURES_ADDR_FEATURES_22_BASE);
}

u32 XPredict_Get_features_22_HighAddress(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (InstancePtr->Features_BaseAddress + XPREDICT_FEATURES_ADDR_FEATURES_22_HIGH);
}

u32 XPredict_Get_features_22_TotalBytes(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (XPREDICT_FEATURES_ADDR_FEATURES_22_HIGH - XPREDICT_FEATURES_ADDR_FEATURES_22_BASE + 1);
}

u32 XPredict_Get_features_22_BitWidth(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XPREDICT_FEATURES_WIDTH_FEATURES_22;
}

u32 XPredict_Get_features_22_Depth(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XPREDICT_FEATURES_DEPTH_FEATURES_22;
}

u32 XPredict_Write_features_22_Words(XPredict *InstancePtr, int offset, word_type *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length)*4 > (XPREDICT_FEATURES_ADDR_FEATURES_22_HIGH - XPREDICT_FEATURES_ADDR_FEATURES_22_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(int *)(InstancePtr->Features_BaseAddress + XPREDICT_FEATURES_ADDR_FEATURES_22_BASE + (offset + i)*4) = *(data + i);
    }
    return length;
}

u32 XPredict_Read_features_22_Words(XPredict *InstancePtr, int offset, word_type *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length)*4 > (XPREDICT_FEATURES_ADDR_FEATURES_22_HIGH - XPREDICT_FEATURES_ADDR_FEATURES_22_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(data + i) = *(int *)(InstancePtr->Features_BaseAddress + XPREDICT_FEATURES_ADDR_FEATURES_22_BASE + (offset + i)*4);
    }
    return length;
}

u32 XPredict_Write_features_22_Bytes(XPredict *InstancePtr, int offset, char *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length) > (XPREDICT_FEATURES_ADDR_FEATURES_22_HIGH - XPREDICT_FEATURES_ADDR_FEATURES_22_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(char *)(InstancePtr->Features_BaseAddress + XPREDICT_FEATURES_ADDR_FEATURES_22_BASE + offset + i) = *(data + i);
    }
    return length;
}

u32 XPredict_Read_features_22_Bytes(XPredict *InstancePtr, int offset, char *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length) > (XPREDICT_FEATURES_ADDR_FEATURES_22_HIGH - XPREDICT_FEATURES_ADDR_FEATURES_22_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(data + i) = *(char *)(InstancePtr->Features_BaseAddress + XPREDICT_FEATURES_ADDR_FEATURES_22_BASE + offset + i);
    }
    return length;
}

u32 XPredict_Get_features_23_BaseAddress(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (InstancePtr->Features_BaseAddress + XPREDICT_FEATURES_ADDR_FEATURES_23_BASE);
}

u32 XPredict_Get_features_23_HighAddress(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (InstancePtr->Features_BaseAddress + XPREDICT_FEATURES_ADDR_FEATURES_23_HIGH);
}

u32 XPredict_Get_features_23_TotalBytes(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (XPREDICT_FEATURES_ADDR_FEATURES_23_HIGH - XPREDICT_FEATURES_ADDR_FEATURES_23_BASE + 1);
}

u32 XPredict_Get_features_23_BitWidth(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XPREDICT_FEATURES_WIDTH_FEATURES_23;
}

u32 XPredict_Get_features_23_Depth(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XPREDICT_FEATURES_DEPTH_FEATURES_23;
}

u32 XPredict_Write_features_23_Words(XPredict *InstancePtr, int offset, word_type *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length)*4 > (XPREDICT_FEATURES_ADDR_FEATURES_23_HIGH - XPREDICT_FEATURES_ADDR_FEATURES_23_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(int *)(InstancePtr->Features_BaseAddress + XPREDICT_FEATURES_ADDR_FEATURES_23_BASE + (offset + i)*4) = *(data + i);
    }
    return length;
}

u32 XPredict_Read_features_23_Words(XPredict *InstancePtr, int offset, word_type *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length)*4 > (XPREDICT_FEATURES_ADDR_FEATURES_23_HIGH - XPREDICT_FEATURES_ADDR_FEATURES_23_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(data + i) = *(int *)(InstancePtr->Features_BaseAddress + XPREDICT_FEATURES_ADDR_FEATURES_23_BASE + (offset + i)*4);
    }
    return length;
}

u32 XPredict_Write_features_23_Bytes(XPredict *InstancePtr, int offset, char *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length) > (XPREDICT_FEATURES_ADDR_FEATURES_23_HIGH - XPREDICT_FEATURES_ADDR_FEATURES_23_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(char *)(InstancePtr->Features_BaseAddress + XPREDICT_FEATURES_ADDR_FEATURES_23_BASE + offset + i) = *(data + i);
    }
    return length;
}

u32 XPredict_Read_features_23_Bytes(XPredict *InstancePtr, int offset, char *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length) > (XPREDICT_FEATURES_ADDR_FEATURES_23_HIGH - XPREDICT_FEATURES_ADDR_FEATURES_23_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(data + i) = *(char *)(InstancePtr->Features_BaseAddress + XPREDICT_FEATURES_ADDR_FEATURES_23_BASE + offset + i);
    }
    return length;
}

u32 XPredict_Get_features_24_BaseAddress(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (InstancePtr->Features_BaseAddress + XPREDICT_FEATURES_ADDR_FEATURES_24_BASE);
}

u32 XPredict_Get_features_24_HighAddress(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (InstancePtr->Features_BaseAddress + XPREDICT_FEATURES_ADDR_FEATURES_24_HIGH);
}

u32 XPredict_Get_features_24_TotalBytes(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (XPREDICT_FEATURES_ADDR_FEATURES_24_HIGH - XPREDICT_FEATURES_ADDR_FEATURES_24_BASE + 1);
}

u32 XPredict_Get_features_24_BitWidth(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XPREDICT_FEATURES_WIDTH_FEATURES_24;
}

u32 XPredict_Get_features_24_Depth(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XPREDICT_FEATURES_DEPTH_FEATURES_24;
}

u32 XPredict_Write_features_24_Words(XPredict *InstancePtr, int offset, word_type *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length)*4 > (XPREDICT_FEATURES_ADDR_FEATURES_24_HIGH - XPREDICT_FEATURES_ADDR_FEATURES_24_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(int *)(InstancePtr->Features_BaseAddress + XPREDICT_FEATURES_ADDR_FEATURES_24_BASE + (offset + i)*4) = *(data + i);
    }
    return length;
}

u32 XPredict_Read_features_24_Words(XPredict *InstancePtr, int offset, word_type *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length)*4 > (XPREDICT_FEATURES_ADDR_FEATURES_24_HIGH - XPREDICT_FEATURES_ADDR_FEATURES_24_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(data + i) = *(int *)(InstancePtr->Features_BaseAddress + XPREDICT_FEATURES_ADDR_FEATURES_24_BASE + (offset + i)*4);
    }
    return length;
}

u32 XPredict_Write_features_24_Bytes(XPredict *InstancePtr, int offset, char *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length) > (XPREDICT_FEATURES_ADDR_FEATURES_24_HIGH - XPREDICT_FEATURES_ADDR_FEATURES_24_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(char *)(InstancePtr->Features_BaseAddress + XPREDICT_FEATURES_ADDR_FEATURES_24_BASE + offset + i) = *(data + i);
    }
    return length;
}

u32 XPredict_Read_features_24_Bytes(XPredict *InstancePtr, int offset, char *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length) > (XPREDICT_FEATURES_ADDR_FEATURES_24_HIGH - XPREDICT_FEATURES_ADDR_FEATURES_24_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(data + i) = *(char *)(InstancePtr->Features_BaseAddress + XPREDICT_FEATURES_ADDR_FEATURES_24_BASE + offset + i);
    }
    return length;
}

u32 XPredict_Get_next_node_right_index_0_BaseAddress(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (InstancePtr->Next_node_right_index_BaseAddress + XPREDICT_NEXT_NODE_RIGHT_INDEX_ADDR_NEXT_NODE_RIGHT_INDEX_0_BASE);
}

u32 XPredict_Get_next_node_right_index_0_HighAddress(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (InstancePtr->Next_node_right_index_BaseAddress + XPREDICT_NEXT_NODE_RIGHT_INDEX_ADDR_NEXT_NODE_RIGHT_INDEX_0_HIGH);
}

u32 XPredict_Get_next_node_right_index_0_TotalBytes(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (XPREDICT_NEXT_NODE_RIGHT_INDEX_ADDR_NEXT_NODE_RIGHT_INDEX_0_HIGH - XPREDICT_NEXT_NODE_RIGHT_INDEX_ADDR_NEXT_NODE_RIGHT_INDEX_0_BASE + 1);
}

u32 XPredict_Get_next_node_right_index_0_BitWidth(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XPREDICT_NEXT_NODE_RIGHT_INDEX_WIDTH_NEXT_NODE_RIGHT_INDEX_0;
}

u32 XPredict_Get_next_node_right_index_0_Depth(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XPREDICT_NEXT_NODE_RIGHT_INDEX_DEPTH_NEXT_NODE_RIGHT_INDEX_0;
}

u32 XPredict_Write_next_node_right_index_0_Words(XPredict *InstancePtr, int offset, word_type *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length)*4 > (XPREDICT_NEXT_NODE_RIGHT_INDEX_ADDR_NEXT_NODE_RIGHT_INDEX_0_HIGH - XPREDICT_NEXT_NODE_RIGHT_INDEX_ADDR_NEXT_NODE_RIGHT_INDEX_0_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(int *)(InstancePtr->Next_node_right_index_BaseAddress + XPREDICT_NEXT_NODE_RIGHT_INDEX_ADDR_NEXT_NODE_RIGHT_INDEX_0_BASE + (offset + i)*4) = *(data + i);
    }
    return length;
}

u32 XPredict_Read_next_node_right_index_0_Words(XPredict *InstancePtr, int offset, word_type *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length)*4 > (XPREDICT_NEXT_NODE_RIGHT_INDEX_ADDR_NEXT_NODE_RIGHT_INDEX_0_HIGH - XPREDICT_NEXT_NODE_RIGHT_INDEX_ADDR_NEXT_NODE_RIGHT_INDEX_0_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(data + i) = *(int *)(InstancePtr->Next_node_right_index_BaseAddress + XPREDICT_NEXT_NODE_RIGHT_INDEX_ADDR_NEXT_NODE_RIGHT_INDEX_0_BASE + (offset + i)*4);
    }
    return length;
}

u32 XPredict_Write_next_node_right_index_0_Bytes(XPredict *InstancePtr, int offset, char *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length) > (XPREDICT_NEXT_NODE_RIGHT_INDEX_ADDR_NEXT_NODE_RIGHT_INDEX_0_HIGH - XPREDICT_NEXT_NODE_RIGHT_INDEX_ADDR_NEXT_NODE_RIGHT_INDEX_0_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(char *)(InstancePtr->Next_node_right_index_BaseAddress + XPREDICT_NEXT_NODE_RIGHT_INDEX_ADDR_NEXT_NODE_RIGHT_INDEX_0_BASE + offset + i) = *(data + i);
    }
    return length;
}

u32 XPredict_Read_next_node_right_index_0_Bytes(XPredict *InstancePtr, int offset, char *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length) > (XPREDICT_NEXT_NODE_RIGHT_INDEX_ADDR_NEXT_NODE_RIGHT_INDEX_0_HIGH - XPREDICT_NEXT_NODE_RIGHT_INDEX_ADDR_NEXT_NODE_RIGHT_INDEX_0_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(data + i) = *(char *)(InstancePtr->Next_node_right_index_BaseAddress + XPREDICT_NEXT_NODE_RIGHT_INDEX_ADDR_NEXT_NODE_RIGHT_INDEX_0_BASE + offset + i);
    }
    return length;
}

u32 XPredict_Get_next_node_right_index_1_BaseAddress(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (InstancePtr->Next_node_right_index_BaseAddress + XPREDICT_NEXT_NODE_RIGHT_INDEX_ADDR_NEXT_NODE_RIGHT_INDEX_1_BASE);
}

u32 XPredict_Get_next_node_right_index_1_HighAddress(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (InstancePtr->Next_node_right_index_BaseAddress + XPREDICT_NEXT_NODE_RIGHT_INDEX_ADDR_NEXT_NODE_RIGHT_INDEX_1_HIGH);
}

u32 XPredict_Get_next_node_right_index_1_TotalBytes(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (XPREDICT_NEXT_NODE_RIGHT_INDEX_ADDR_NEXT_NODE_RIGHT_INDEX_1_HIGH - XPREDICT_NEXT_NODE_RIGHT_INDEX_ADDR_NEXT_NODE_RIGHT_INDEX_1_BASE + 1);
}

u32 XPredict_Get_next_node_right_index_1_BitWidth(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XPREDICT_NEXT_NODE_RIGHT_INDEX_WIDTH_NEXT_NODE_RIGHT_INDEX_1;
}

u32 XPredict_Get_next_node_right_index_1_Depth(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XPREDICT_NEXT_NODE_RIGHT_INDEX_DEPTH_NEXT_NODE_RIGHT_INDEX_1;
}

u32 XPredict_Write_next_node_right_index_1_Words(XPredict *InstancePtr, int offset, word_type *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length)*4 > (XPREDICT_NEXT_NODE_RIGHT_INDEX_ADDR_NEXT_NODE_RIGHT_INDEX_1_HIGH - XPREDICT_NEXT_NODE_RIGHT_INDEX_ADDR_NEXT_NODE_RIGHT_INDEX_1_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(int *)(InstancePtr->Next_node_right_index_BaseAddress + XPREDICT_NEXT_NODE_RIGHT_INDEX_ADDR_NEXT_NODE_RIGHT_INDEX_1_BASE + (offset + i)*4) = *(data + i);
    }
    return length;
}

u32 XPredict_Read_next_node_right_index_1_Words(XPredict *InstancePtr, int offset, word_type *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length)*4 > (XPREDICT_NEXT_NODE_RIGHT_INDEX_ADDR_NEXT_NODE_RIGHT_INDEX_1_HIGH - XPREDICT_NEXT_NODE_RIGHT_INDEX_ADDR_NEXT_NODE_RIGHT_INDEX_1_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(data + i) = *(int *)(InstancePtr->Next_node_right_index_BaseAddress + XPREDICT_NEXT_NODE_RIGHT_INDEX_ADDR_NEXT_NODE_RIGHT_INDEX_1_BASE + (offset + i)*4);
    }
    return length;
}

u32 XPredict_Write_next_node_right_index_1_Bytes(XPredict *InstancePtr, int offset, char *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length) > (XPREDICT_NEXT_NODE_RIGHT_INDEX_ADDR_NEXT_NODE_RIGHT_INDEX_1_HIGH - XPREDICT_NEXT_NODE_RIGHT_INDEX_ADDR_NEXT_NODE_RIGHT_INDEX_1_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(char *)(InstancePtr->Next_node_right_index_BaseAddress + XPREDICT_NEXT_NODE_RIGHT_INDEX_ADDR_NEXT_NODE_RIGHT_INDEX_1_BASE + offset + i) = *(data + i);
    }
    return length;
}

u32 XPredict_Read_next_node_right_index_1_Bytes(XPredict *InstancePtr, int offset, char *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length) > (XPREDICT_NEXT_NODE_RIGHT_INDEX_ADDR_NEXT_NODE_RIGHT_INDEX_1_HIGH - XPREDICT_NEXT_NODE_RIGHT_INDEX_ADDR_NEXT_NODE_RIGHT_INDEX_1_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(data + i) = *(char *)(InstancePtr->Next_node_right_index_BaseAddress + XPREDICT_NEXT_NODE_RIGHT_INDEX_ADDR_NEXT_NODE_RIGHT_INDEX_1_BASE + offset + i);
    }
    return length;
}

u32 XPredict_Get_next_node_right_index_2_BaseAddress(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (InstancePtr->Next_node_right_index_BaseAddress + XPREDICT_NEXT_NODE_RIGHT_INDEX_ADDR_NEXT_NODE_RIGHT_INDEX_2_BASE);
}

u32 XPredict_Get_next_node_right_index_2_HighAddress(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (InstancePtr->Next_node_right_index_BaseAddress + XPREDICT_NEXT_NODE_RIGHT_INDEX_ADDR_NEXT_NODE_RIGHT_INDEX_2_HIGH);
}

u32 XPredict_Get_next_node_right_index_2_TotalBytes(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (XPREDICT_NEXT_NODE_RIGHT_INDEX_ADDR_NEXT_NODE_RIGHT_INDEX_2_HIGH - XPREDICT_NEXT_NODE_RIGHT_INDEX_ADDR_NEXT_NODE_RIGHT_INDEX_2_BASE + 1);
}

u32 XPredict_Get_next_node_right_index_2_BitWidth(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XPREDICT_NEXT_NODE_RIGHT_INDEX_WIDTH_NEXT_NODE_RIGHT_INDEX_2;
}

u32 XPredict_Get_next_node_right_index_2_Depth(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XPREDICT_NEXT_NODE_RIGHT_INDEX_DEPTH_NEXT_NODE_RIGHT_INDEX_2;
}

u32 XPredict_Write_next_node_right_index_2_Words(XPredict *InstancePtr, int offset, word_type *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length)*4 > (XPREDICT_NEXT_NODE_RIGHT_INDEX_ADDR_NEXT_NODE_RIGHT_INDEX_2_HIGH - XPREDICT_NEXT_NODE_RIGHT_INDEX_ADDR_NEXT_NODE_RIGHT_INDEX_2_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(int *)(InstancePtr->Next_node_right_index_BaseAddress + XPREDICT_NEXT_NODE_RIGHT_INDEX_ADDR_NEXT_NODE_RIGHT_INDEX_2_BASE + (offset + i)*4) = *(data + i);
    }
    return length;
}

u32 XPredict_Read_next_node_right_index_2_Words(XPredict *InstancePtr, int offset, word_type *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length)*4 > (XPREDICT_NEXT_NODE_RIGHT_INDEX_ADDR_NEXT_NODE_RIGHT_INDEX_2_HIGH - XPREDICT_NEXT_NODE_RIGHT_INDEX_ADDR_NEXT_NODE_RIGHT_INDEX_2_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(data + i) = *(int *)(InstancePtr->Next_node_right_index_BaseAddress + XPREDICT_NEXT_NODE_RIGHT_INDEX_ADDR_NEXT_NODE_RIGHT_INDEX_2_BASE + (offset + i)*4);
    }
    return length;
}

u32 XPredict_Write_next_node_right_index_2_Bytes(XPredict *InstancePtr, int offset, char *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length) > (XPREDICT_NEXT_NODE_RIGHT_INDEX_ADDR_NEXT_NODE_RIGHT_INDEX_2_HIGH - XPREDICT_NEXT_NODE_RIGHT_INDEX_ADDR_NEXT_NODE_RIGHT_INDEX_2_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(char *)(InstancePtr->Next_node_right_index_BaseAddress + XPREDICT_NEXT_NODE_RIGHT_INDEX_ADDR_NEXT_NODE_RIGHT_INDEX_2_BASE + offset + i) = *(data + i);
    }
    return length;
}

u32 XPredict_Read_next_node_right_index_2_Bytes(XPredict *InstancePtr, int offset, char *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length) > (XPREDICT_NEXT_NODE_RIGHT_INDEX_ADDR_NEXT_NODE_RIGHT_INDEX_2_HIGH - XPREDICT_NEXT_NODE_RIGHT_INDEX_ADDR_NEXT_NODE_RIGHT_INDEX_2_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(data + i) = *(char *)(InstancePtr->Next_node_right_index_BaseAddress + XPREDICT_NEXT_NODE_RIGHT_INDEX_ADDR_NEXT_NODE_RIGHT_INDEX_2_BASE + offset + i);
    }
    return length;
}

u32 XPredict_Get_next_node_right_index_3_BaseAddress(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (InstancePtr->Next_node_right_index_BaseAddress + XPREDICT_NEXT_NODE_RIGHT_INDEX_ADDR_NEXT_NODE_RIGHT_INDEX_3_BASE);
}

u32 XPredict_Get_next_node_right_index_3_HighAddress(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (InstancePtr->Next_node_right_index_BaseAddress + XPREDICT_NEXT_NODE_RIGHT_INDEX_ADDR_NEXT_NODE_RIGHT_INDEX_3_HIGH);
}

u32 XPredict_Get_next_node_right_index_3_TotalBytes(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (XPREDICT_NEXT_NODE_RIGHT_INDEX_ADDR_NEXT_NODE_RIGHT_INDEX_3_HIGH - XPREDICT_NEXT_NODE_RIGHT_INDEX_ADDR_NEXT_NODE_RIGHT_INDEX_3_BASE + 1);
}

u32 XPredict_Get_next_node_right_index_3_BitWidth(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XPREDICT_NEXT_NODE_RIGHT_INDEX_WIDTH_NEXT_NODE_RIGHT_INDEX_3;
}

u32 XPredict_Get_next_node_right_index_3_Depth(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XPREDICT_NEXT_NODE_RIGHT_INDEX_DEPTH_NEXT_NODE_RIGHT_INDEX_3;
}

u32 XPredict_Write_next_node_right_index_3_Words(XPredict *InstancePtr, int offset, word_type *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length)*4 > (XPREDICT_NEXT_NODE_RIGHT_INDEX_ADDR_NEXT_NODE_RIGHT_INDEX_3_HIGH - XPREDICT_NEXT_NODE_RIGHT_INDEX_ADDR_NEXT_NODE_RIGHT_INDEX_3_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(int *)(InstancePtr->Next_node_right_index_BaseAddress + XPREDICT_NEXT_NODE_RIGHT_INDEX_ADDR_NEXT_NODE_RIGHT_INDEX_3_BASE + (offset + i)*4) = *(data + i);
    }
    return length;
}

u32 XPredict_Read_next_node_right_index_3_Words(XPredict *InstancePtr, int offset, word_type *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length)*4 > (XPREDICT_NEXT_NODE_RIGHT_INDEX_ADDR_NEXT_NODE_RIGHT_INDEX_3_HIGH - XPREDICT_NEXT_NODE_RIGHT_INDEX_ADDR_NEXT_NODE_RIGHT_INDEX_3_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(data + i) = *(int *)(InstancePtr->Next_node_right_index_BaseAddress + XPREDICT_NEXT_NODE_RIGHT_INDEX_ADDR_NEXT_NODE_RIGHT_INDEX_3_BASE + (offset + i)*4);
    }
    return length;
}

u32 XPredict_Write_next_node_right_index_3_Bytes(XPredict *InstancePtr, int offset, char *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length) > (XPREDICT_NEXT_NODE_RIGHT_INDEX_ADDR_NEXT_NODE_RIGHT_INDEX_3_HIGH - XPREDICT_NEXT_NODE_RIGHT_INDEX_ADDR_NEXT_NODE_RIGHT_INDEX_3_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(char *)(InstancePtr->Next_node_right_index_BaseAddress + XPREDICT_NEXT_NODE_RIGHT_INDEX_ADDR_NEXT_NODE_RIGHT_INDEX_3_BASE + offset + i) = *(data + i);
    }
    return length;
}

u32 XPredict_Read_next_node_right_index_3_Bytes(XPredict *InstancePtr, int offset, char *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length) > (XPREDICT_NEXT_NODE_RIGHT_INDEX_ADDR_NEXT_NODE_RIGHT_INDEX_3_HIGH - XPREDICT_NEXT_NODE_RIGHT_INDEX_ADDR_NEXT_NODE_RIGHT_INDEX_3_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(data + i) = *(char *)(InstancePtr->Next_node_right_index_BaseAddress + XPREDICT_NEXT_NODE_RIGHT_INDEX_ADDR_NEXT_NODE_RIGHT_INDEX_3_BASE + offset + i);
    }
    return length;
}

u32 XPredict_Get_next_node_right_index_4_BaseAddress(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (InstancePtr->Next_node_right_index_BaseAddress + XPREDICT_NEXT_NODE_RIGHT_INDEX_ADDR_NEXT_NODE_RIGHT_INDEX_4_BASE);
}

u32 XPredict_Get_next_node_right_index_4_HighAddress(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (InstancePtr->Next_node_right_index_BaseAddress + XPREDICT_NEXT_NODE_RIGHT_INDEX_ADDR_NEXT_NODE_RIGHT_INDEX_4_HIGH);
}

u32 XPredict_Get_next_node_right_index_4_TotalBytes(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (XPREDICT_NEXT_NODE_RIGHT_INDEX_ADDR_NEXT_NODE_RIGHT_INDEX_4_HIGH - XPREDICT_NEXT_NODE_RIGHT_INDEX_ADDR_NEXT_NODE_RIGHT_INDEX_4_BASE + 1);
}

u32 XPredict_Get_next_node_right_index_4_BitWidth(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XPREDICT_NEXT_NODE_RIGHT_INDEX_WIDTH_NEXT_NODE_RIGHT_INDEX_4;
}

u32 XPredict_Get_next_node_right_index_4_Depth(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XPREDICT_NEXT_NODE_RIGHT_INDEX_DEPTH_NEXT_NODE_RIGHT_INDEX_4;
}

u32 XPredict_Write_next_node_right_index_4_Words(XPredict *InstancePtr, int offset, word_type *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length)*4 > (XPREDICT_NEXT_NODE_RIGHT_INDEX_ADDR_NEXT_NODE_RIGHT_INDEX_4_HIGH - XPREDICT_NEXT_NODE_RIGHT_INDEX_ADDR_NEXT_NODE_RIGHT_INDEX_4_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(int *)(InstancePtr->Next_node_right_index_BaseAddress + XPREDICT_NEXT_NODE_RIGHT_INDEX_ADDR_NEXT_NODE_RIGHT_INDEX_4_BASE + (offset + i)*4) = *(data + i);
    }
    return length;
}

u32 XPredict_Read_next_node_right_index_4_Words(XPredict *InstancePtr, int offset, word_type *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length)*4 > (XPREDICT_NEXT_NODE_RIGHT_INDEX_ADDR_NEXT_NODE_RIGHT_INDEX_4_HIGH - XPREDICT_NEXT_NODE_RIGHT_INDEX_ADDR_NEXT_NODE_RIGHT_INDEX_4_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(data + i) = *(int *)(InstancePtr->Next_node_right_index_BaseAddress + XPREDICT_NEXT_NODE_RIGHT_INDEX_ADDR_NEXT_NODE_RIGHT_INDEX_4_BASE + (offset + i)*4);
    }
    return length;
}

u32 XPredict_Write_next_node_right_index_4_Bytes(XPredict *InstancePtr, int offset, char *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length) > (XPREDICT_NEXT_NODE_RIGHT_INDEX_ADDR_NEXT_NODE_RIGHT_INDEX_4_HIGH - XPREDICT_NEXT_NODE_RIGHT_INDEX_ADDR_NEXT_NODE_RIGHT_INDEX_4_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(char *)(InstancePtr->Next_node_right_index_BaseAddress + XPREDICT_NEXT_NODE_RIGHT_INDEX_ADDR_NEXT_NODE_RIGHT_INDEX_4_BASE + offset + i) = *(data + i);
    }
    return length;
}

u32 XPredict_Read_next_node_right_index_4_Bytes(XPredict *InstancePtr, int offset, char *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length) > (XPREDICT_NEXT_NODE_RIGHT_INDEX_ADDR_NEXT_NODE_RIGHT_INDEX_4_HIGH - XPREDICT_NEXT_NODE_RIGHT_INDEX_ADDR_NEXT_NODE_RIGHT_INDEX_4_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(data + i) = *(char *)(InstancePtr->Next_node_right_index_BaseAddress + XPREDICT_NEXT_NODE_RIGHT_INDEX_ADDR_NEXT_NODE_RIGHT_INDEX_4_BASE + offset + i);
    }
    return length;
}

u32 XPredict_Get_next_node_right_index_5_BaseAddress(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (InstancePtr->Next_node_right_index_BaseAddress + XPREDICT_NEXT_NODE_RIGHT_INDEX_ADDR_NEXT_NODE_RIGHT_INDEX_5_BASE);
}

u32 XPredict_Get_next_node_right_index_5_HighAddress(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (InstancePtr->Next_node_right_index_BaseAddress + XPREDICT_NEXT_NODE_RIGHT_INDEX_ADDR_NEXT_NODE_RIGHT_INDEX_5_HIGH);
}

u32 XPredict_Get_next_node_right_index_5_TotalBytes(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (XPREDICT_NEXT_NODE_RIGHT_INDEX_ADDR_NEXT_NODE_RIGHT_INDEX_5_HIGH - XPREDICT_NEXT_NODE_RIGHT_INDEX_ADDR_NEXT_NODE_RIGHT_INDEX_5_BASE + 1);
}

u32 XPredict_Get_next_node_right_index_5_BitWidth(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XPREDICT_NEXT_NODE_RIGHT_INDEX_WIDTH_NEXT_NODE_RIGHT_INDEX_5;
}

u32 XPredict_Get_next_node_right_index_5_Depth(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XPREDICT_NEXT_NODE_RIGHT_INDEX_DEPTH_NEXT_NODE_RIGHT_INDEX_5;
}

u32 XPredict_Write_next_node_right_index_5_Words(XPredict *InstancePtr, int offset, word_type *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length)*4 > (XPREDICT_NEXT_NODE_RIGHT_INDEX_ADDR_NEXT_NODE_RIGHT_INDEX_5_HIGH - XPREDICT_NEXT_NODE_RIGHT_INDEX_ADDR_NEXT_NODE_RIGHT_INDEX_5_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(int *)(InstancePtr->Next_node_right_index_BaseAddress + XPREDICT_NEXT_NODE_RIGHT_INDEX_ADDR_NEXT_NODE_RIGHT_INDEX_5_BASE + (offset + i)*4) = *(data + i);
    }
    return length;
}

u32 XPredict_Read_next_node_right_index_5_Words(XPredict *InstancePtr, int offset, word_type *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length)*4 > (XPREDICT_NEXT_NODE_RIGHT_INDEX_ADDR_NEXT_NODE_RIGHT_INDEX_5_HIGH - XPREDICT_NEXT_NODE_RIGHT_INDEX_ADDR_NEXT_NODE_RIGHT_INDEX_5_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(data + i) = *(int *)(InstancePtr->Next_node_right_index_BaseAddress + XPREDICT_NEXT_NODE_RIGHT_INDEX_ADDR_NEXT_NODE_RIGHT_INDEX_5_BASE + (offset + i)*4);
    }
    return length;
}

u32 XPredict_Write_next_node_right_index_5_Bytes(XPredict *InstancePtr, int offset, char *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length) > (XPREDICT_NEXT_NODE_RIGHT_INDEX_ADDR_NEXT_NODE_RIGHT_INDEX_5_HIGH - XPREDICT_NEXT_NODE_RIGHT_INDEX_ADDR_NEXT_NODE_RIGHT_INDEX_5_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(char *)(InstancePtr->Next_node_right_index_BaseAddress + XPREDICT_NEXT_NODE_RIGHT_INDEX_ADDR_NEXT_NODE_RIGHT_INDEX_5_BASE + offset + i) = *(data + i);
    }
    return length;
}

u32 XPredict_Read_next_node_right_index_5_Bytes(XPredict *InstancePtr, int offset, char *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length) > (XPREDICT_NEXT_NODE_RIGHT_INDEX_ADDR_NEXT_NODE_RIGHT_INDEX_5_HIGH - XPREDICT_NEXT_NODE_RIGHT_INDEX_ADDR_NEXT_NODE_RIGHT_INDEX_5_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(data + i) = *(char *)(InstancePtr->Next_node_right_index_BaseAddress + XPREDICT_NEXT_NODE_RIGHT_INDEX_ADDR_NEXT_NODE_RIGHT_INDEX_5_BASE + offset + i);
    }
    return length;
}

u32 XPredict_Get_next_node_right_index_6_BaseAddress(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (InstancePtr->Next_node_right_index_BaseAddress + XPREDICT_NEXT_NODE_RIGHT_INDEX_ADDR_NEXT_NODE_RIGHT_INDEX_6_BASE);
}

u32 XPredict_Get_next_node_right_index_6_HighAddress(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (InstancePtr->Next_node_right_index_BaseAddress + XPREDICT_NEXT_NODE_RIGHT_INDEX_ADDR_NEXT_NODE_RIGHT_INDEX_6_HIGH);
}

u32 XPredict_Get_next_node_right_index_6_TotalBytes(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (XPREDICT_NEXT_NODE_RIGHT_INDEX_ADDR_NEXT_NODE_RIGHT_INDEX_6_HIGH - XPREDICT_NEXT_NODE_RIGHT_INDEX_ADDR_NEXT_NODE_RIGHT_INDEX_6_BASE + 1);
}

u32 XPredict_Get_next_node_right_index_6_BitWidth(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XPREDICT_NEXT_NODE_RIGHT_INDEX_WIDTH_NEXT_NODE_RIGHT_INDEX_6;
}

u32 XPredict_Get_next_node_right_index_6_Depth(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XPREDICT_NEXT_NODE_RIGHT_INDEX_DEPTH_NEXT_NODE_RIGHT_INDEX_6;
}

u32 XPredict_Write_next_node_right_index_6_Words(XPredict *InstancePtr, int offset, word_type *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length)*4 > (XPREDICT_NEXT_NODE_RIGHT_INDEX_ADDR_NEXT_NODE_RIGHT_INDEX_6_HIGH - XPREDICT_NEXT_NODE_RIGHT_INDEX_ADDR_NEXT_NODE_RIGHT_INDEX_6_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(int *)(InstancePtr->Next_node_right_index_BaseAddress + XPREDICT_NEXT_NODE_RIGHT_INDEX_ADDR_NEXT_NODE_RIGHT_INDEX_6_BASE + (offset + i)*4) = *(data + i);
    }
    return length;
}

u32 XPredict_Read_next_node_right_index_6_Words(XPredict *InstancePtr, int offset, word_type *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length)*4 > (XPREDICT_NEXT_NODE_RIGHT_INDEX_ADDR_NEXT_NODE_RIGHT_INDEX_6_HIGH - XPREDICT_NEXT_NODE_RIGHT_INDEX_ADDR_NEXT_NODE_RIGHT_INDEX_6_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(data + i) = *(int *)(InstancePtr->Next_node_right_index_BaseAddress + XPREDICT_NEXT_NODE_RIGHT_INDEX_ADDR_NEXT_NODE_RIGHT_INDEX_6_BASE + (offset + i)*4);
    }
    return length;
}

u32 XPredict_Write_next_node_right_index_6_Bytes(XPredict *InstancePtr, int offset, char *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length) > (XPREDICT_NEXT_NODE_RIGHT_INDEX_ADDR_NEXT_NODE_RIGHT_INDEX_6_HIGH - XPREDICT_NEXT_NODE_RIGHT_INDEX_ADDR_NEXT_NODE_RIGHT_INDEX_6_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(char *)(InstancePtr->Next_node_right_index_BaseAddress + XPREDICT_NEXT_NODE_RIGHT_INDEX_ADDR_NEXT_NODE_RIGHT_INDEX_6_BASE + offset + i) = *(data + i);
    }
    return length;
}

u32 XPredict_Read_next_node_right_index_6_Bytes(XPredict *InstancePtr, int offset, char *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length) > (XPREDICT_NEXT_NODE_RIGHT_INDEX_ADDR_NEXT_NODE_RIGHT_INDEX_6_HIGH - XPREDICT_NEXT_NODE_RIGHT_INDEX_ADDR_NEXT_NODE_RIGHT_INDEX_6_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(data + i) = *(char *)(InstancePtr->Next_node_right_index_BaseAddress + XPREDICT_NEXT_NODE_RIGHT_INDEX_ADDR_NEXT_NODE_RIGHT_INDEX_6_BASE + offset + i);
    }
    return length;
}

u32 XPredict_Get_next_node_right_index_7_BaseAddress(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (InstancePtr->Next_node_right_index_BaseAddress + XPREDICT_NEXT_NODE_RIGHT_INDEX_ADDR_NEXT_NODE_RIGHT_INDEX_7_BASE);
}

u32 XPredict_Get_next_node_right_index_7_HighAddress(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (InstancePtr->Next_node_right_index_BaseAddress + XPREDICT_NEXT_NODE_RIGHT_INDEX_ADDR_NEXT_NODE_RIGHT_INDEX_7_HIGH);
}

u32 XPredict_Get_next_node_right_index_7_TotalBytes(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (XPREDICT_NEXT_NODE_RIGHT_INDEX_ADDR_NEXT_NODE_RIGHT_INDEX_7_HIGH - XPREDICT_NEXT_NODE_RIGHT_INDEX_ADDR_NEXT_NODE_RIGHT_INDEX_7_BASE + 1);
}

u32 XPredict_Get_next_node_right_index_7_BitWidth(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XPREDICT_NEXT_NODE_RIGHT_INDEX_WIDTH_NEXT_NODE_RIGHT_INDEX_7;
}

u32 XPredict_Get_next_node_right_index_7_Depth(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XPREDICT_NEXT_NODE_RIGHT_INDEX_DEPTH_NEXT_NODE_RIGHT_INDEX_7;
}

u32 XPredict_Write_next_node_right_index_7_Words(XPredict *InstancePtr, int offset, word_type *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length)*4 > (XPREDICT_NEXT_NODE_RIGHT_INDEX_ADDR_NEXT_NODE_RIGHT_INDEX_7_HIGH - XPREDICT_NEXT_NODE_RIGHT_INDEX_ADDR_NEXT_NODE_RIGHT_INDEX_7_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(int *)(InstancePtr->Next_node_right_index_BaseAddress + XPREDICT_NEXT_NODE_RIGHT_INDEX_ADDR_NEXT_NODE_RIGHT_INDEX_7_BASE + (offset + i)*4) = *(data + i);
    }
    return length;
}

u32 XPredict_Read_next_node_right_index_7_Words(XPredict *InstancePtr, int offset, word_type *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length)*4 > (XPREDICT_NEXT_NODE_RIGHT_INDEX_ADDR_NEXT_NODE_RIGHT_INDEX_7_HIGH - XPREDICT_NEXT_NODE_RIGHT_INDEX_ADDR_NEXT_NODE_RIGHT_INDEX_7_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(data + i) = *(int *)(InstancePtr->Next_node_right_index_BaseAddress + XPREDICT_NEXT_NODE_RIGHT_INDEX_ADDR_NEXT_NODE_RIGHT_INDEX_7_BASE + (offset + i)*4);
    }
    return length;
}

u32 XPredict_Write_next_node_right_index_7_Bytes(XPredict *InstancePtr, int offset, char *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length) > (XPREDICT_NEXT_NODE_RIGHT_INDEX_ADDR_NEXT_NODE_RIGHT_INDEX_7_HIGH - XPREDICT_NEXT_NODE_RIGHT_INDEX_ADDR_NEXT_NODE_RIGHT_INDEX_7_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(char *)(InstancePtr->Next_node_right_index_BaseAddress + XPREDICT_NEXT_NODE_RIGHT_INDEX_ADDR_NEXT_NODE_RIGHT_INDEX_7_BASE + offset + i) = *(data + i);
    }
    return length;
}

u32 XPredict_Read_next_node_right_index_7_Bytes(XPredict *InstancePtr, int offset, char *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length) > (XPREDICT_NEXT_NODE_RIGHT_INDEX_ADDR_NEXT_NODE_RIGHT_INDEX_7_HIGH - XPREDICT_NEXT_NODE_RIGHT_INDEX_ADDR_NEXT_NODE_RIGHT_INDEX_7_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(data + i) = *(char *)(InstancePtr->Next_node_right_index_BaseAddress + XPREDICT_NEXT_NODE_RIGHT_INDEX_ADDR_NEXT_NODE_RIGHT_INDEX_7_BASE + offset + i);
    }
    return length;
}

u32 XPredict_Get_next_node_right_index_8_BaseAddress(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (InstancePtr->Next_node_right_index_BaseAddress + XPREDICT_NEXT_NODE_RIGHT_INDEX_ADDR_NEXT_NODE_RIGHT_INDEX_8_BASE);
}

u32 XPredict_Get_next_node_right_index_8_HighAddress(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (InstancePtr->Next_node_right_index_BaseAddress + XPREDICT_NEXT_NODE_RIGHT_INDEX_ADDR_NEXT_NODE_RIGHT_INDEX_8_HIGH);
}

u32 XPredict_Get_next_node_right_index_8_TotalBytes(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (XPREDICT_NEXT_NODE_RIGHT_INDEX_ADDR_NEXT_NODE_RIGHT_INDEX_8_HIGH - XPREDICT_NEXT_NODE_RIGHT_INDEX_ADDR_NEXT_NODE_RIGHT_INDEX_8_BASE + 1);
}

u32 XPredict_Get_next_node_right_index_8_BitWidth(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XPREDICT_NEXT_NODE_RIGHT_INDEX_WIDTH_NEXT_NODE_RIGHT_INDEX_8;
}

u32 XPredict_Get_next_node_right_index_8_Depth(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XPREDICT_NEXT_NODE_RIGHT_INDEX_DEPTH_NEXT_NODE_RIGHT_INDEX_8;
}

u32 XPredict_Write_next_node_right_index_8_Words(XPredict *InstancePtr, int offset, word_type *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length)*4 > (XPREDICT_NEXT_NODE_RIGHT_INDEX_ADDR_NEXT_NODE_RIGHT_INDEX_8_HIGH - XPREDICT_NEXT_NODE_RIGHT_INDEX_ADDR_NEXT_NODE_RIGHT_INDEX_8_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(int *)(InstancePtr->Next_node_right_index_BaseAddress + XPREDICT_NEXT_NODE_RIGHT_INDEX_ADDR_NEXT_NODE_RIGHT_INDEX_8_BASE + (offset + i)*4) = *(data + i);
    }
    return length;
}

u32 XPredict_Read_next_node_right_index_8_Words(XPredict *InstancePtr, int offset, word_type *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length)*4 > (XPREDICT_NEXT_NODE_RIGHT_INDEX_ADDR_NEXT_NODE_RIGHT_INDEX_8_HIGH - XPREDICT_NEXT_NODE_RIGHT_INDEX_ADDR_NEXT_NODE_RIGHT_INDEX_8_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(data + i) = *(int *)(InstancePtr->Next_node_right_index_BaseAddress + XPREDICT_NEXT_NODE_RIGHT_INDEX_ADDR_NEXT_NODE_RIGHT_INDEX_8_BASE + (offset + i)*4);
    }
    return length;
}

u32 XPredict_Write_next_node_right_index_8_Bytes(XPredict *InstancePtr, int offset, char *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length) > (XPREDICT_NEXT_NODE_RIGHT_INDEX_ADDR_NEXT_NODE_RIGHT_INDEX_8_HIGH - XPREDICT_NEXT_NODE_RIGHT_INDEX_ADDR_NEXT_NODE_RIGHT_INDEX_8_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(char *)(InstancePtr->Next_node_right_index_BaseAddress + XPREDICT_NEXT_NODE_RIGHT_INDEX_ADDR_NEXT_NODE_RIGHT_INDEX_8_BASE + offset + i) = *(data + i);
    }
    return length;
}

u32 XPredict_Read_next_node_right_index_8_Bytes(XPredict *InstancePtr, int offset, char *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length) > (XPREDICT_NEXT_NODE_RIGHT_INDEX_ADDR_NEXT_NODE_RIGHT_INDEX_8_HIGH - XPREDICT_NEXT_NODE_RIGHT_INDEX_ADDR_NEXT_NODE_RIGHT_INDEX_8_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(data + i) = *(char *)(InstancePtr->Next_node_right_index_BaseAddress + XPREDICT_NEXT_NODE_RIGHT_INDEX_ADDR_NEXT_NODE_RIGHT_INDEX_8_BASE + offset + i);
    }
    return length;
}

u32 XPredict_Get_next_node_right_index_9_BaseAddress(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (InstancePtr->Next_node_right_index_BaseAddress + XPREDICT_NEXT_NODE_RIGHT_INDEX_ADDR_NEXT_NODE_RIGHT_INDEX_9_BASE);
}

u32 XPredict_Get_next_node_right_index_9_HighAddress(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (InstancePtr->Next_node_right_index_BaseAddress + XPREDICT_NEXT_NODE_RIGHT_INDEX_ADDR_NEXT_NODE_RIGHT_INDEX_9_HIGH);
}

u32 XPredict_Get_next_node_right_index_9_TotalBytes(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (XPREDICT_NEXT_NODE_RIGHT_INDEX_ADDR_NEXT_NODE_RIGHT_INDEX_9_HIGH - XPREDICT_NEXT_NODE_RIGHT_INDEX_ADDR_NEXT_NODE_RIGHT_INDEX_9_BASE + 1);
}

u32 XPredict_Get_next_node_right_index_9_BitWidth(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XPREDICT_NEXT_NODE_RIGHT_INDEX_WIDTH_NEXT_NODE_RIGHT_INDEX_9;
}

u32 XPredict_Get_next_node_right_index_9_Depth(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XPREDICT_NEXT_NODE_RIGHT_INDEX_DEPTH_NEXT_NODE_RIGHT_INDEX_9;
}

u32 XPredict_Write_next_node_right_index_9_Words(XPredict *InstancePtr, int offset, word_type *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length)*4 > (XPREDICT_NEXT_NODE_RIGHT_INDEX_ADDR_NEXT_NODE_RIGHT_INDEX_9_HIGH - XPREDICT_NEXT_NODE_RIGHT_INDEX_ADDR_NEXT_NODE_RIGHT_INDEX_9_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(int *)(InstancePtr->Next_node_right_index_BaseAddress + XPREDICT_NEXT_NODE_RIGHT_INDEX_ADDR_NEXT_NODE_RIGHT_INDEX_9_BASE + (offset + i)*4) = *(data + i);
    }
    return length;
}

u32 XPredict_Read_next_node_right_index_9_Words(XPredict *InstancePtr, int offset, word_type *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length)*4 > (XPREDICT_NEXT_NODE_RIGHT_INDEX_ADDR_NEXT_NODE_RIGHT_INDEX_9_HIGH - XPREDICT_NEXT_NODE_RIGHT_INDEX_ADDR_NEXT_NODE_RIGHT_INDEX_9_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(data + i) = *(int *)(InstancePtr->Next_node_right_index_BaseAddress + XPREDICT_NEXT_NODE_RIGHT_INDEX_ADDR_NEXT_NODE_RIGHT_INDEX_9_BASE + (offset + i)*4);
    }
    return length;
}

u32 XPredict_Write_next_node_right_index_9_Bytes(XPredict *InstancePtr, int offset, char *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length) > (XPREDICT_NEXT_NODE_RIGHT_INDEX_ADDR_NEXT_NODE_RIGHT_INDEX_9_HIGH - XPREDICT_NEXT_NODE_RIGHT_INDEX_ADDR_NEXT_NODE_RIGHT_INDEX_9_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(char *)(InstancePtr->Next_node_right_index_BaseAddress + XPREDICT_NEXT_NODE_RIGHT_INDEX_ADDR_NEXT_NODE_RIGHT_INDEX_9_BASE + offset + i) = *(data + i);
    }
    return length;
}

u32 XPredict_Read_next_node_right_index_9_Bytes(XPredict *InstancePtr, int offset, char *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length) > (XPREDICT_NEXT_NODE_RIGHT_INDEX_ADDR_NEXT_NODE_RIGHT_INDEX_9_HIGH - XPREDICT_NEXT_NODE_RIGHT_INDEX_ADDR_NEXT_NODE_RIGHT_INDEX_9_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(data + i) = *(char *)(InstancePtr->Next_node_right_index_BaseAddress + XPREDICT_NEXT_NODE_RIGHT_INDEX_ADDR_NEXT_NODE_RIGHT_INDEX_9_BASE + offset + i);
    }
    return length;
}

u32 XPredict_Get_node_leaf_value_0_BaseAddress(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (InstancePtr->Node_leaf_value_BaseAddress + XPREDICT_NODE_LEAF_VALUE_ADDR_NODE_LEAF_VALUE_0_BASE);
}

u32 XPredict_Get_node_leaf_value_0_HighAddress(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (InstancePtr->Node_leaf_value_BaseAddress + XPREDICT_NODE_LEAF_VALUE_ADDR_NODE_LEAF_VALUE_0_HIGH);
}

u32 XPredict_Get_node_leaf_value_0_TotalBytes(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (XPREDICT_NODE_LEAF_VALUE_ADDR_NODE_LEAF_VALUE_0_HIGH - XPREDICT_NODE_LEAF_VALUE_ADDR_NODE_LEAF_VALUE_0_BASE + 1);
}

u32 XPredict_Get_node_leaf_value_0_BitWidth(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XPREDICT_NODE_LEAF_VALUE_WIDTH_NODE_LEAF_VALUE_0;
}

u32 XPredict_Get_node_leaf_value_0_Depth(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XPREDICT_NODE_LEAF_VALUE_DEPTH_NODE_LEAF_VALUE_0;
}

u32 XPredict_Write_node_leaf_value_0_Words(XPredict *InstancePtr, int offset, word_type *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length)*4 > (XPREDICT_NODE_LEAF_VALUE_ADDR_NODE_LEAF_VALUE_0_HIGH - XPREDICT_NODE_LEAF_VALUE_ADDR_NODE_LEAF_VALUE_0_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(int *)(InstancePtr->Node_leaf_value_BaseAddress + XPREDICT_NODE_LEAF_VALUE_ADDR_NODE_LEAF_VALUE_0_BASE + (offset + i)*4) = *(data + i);
    }
    return length;
}

u32 XPredict_Read_node_leaf_value_0_Words(XPredict *InstancePtr, int offset, word_type *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length)*4 > (XPREDICT_NODE_LEAF_VALUE_ADDR_NODE_LEAF_VALUE_0_HIGH - XPREDICT_NODE_LEAF_VALUE_ADDR_NODE_LEAF_VALUE_0_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(data + i) = *(int *)(InstancePtr->Node_leaf_value_BaseAddress + XPREDICT_NODE_LEAF_VALUE_ADDR_NODE_LEAF_VALUE_0_BASE + (offset + i)*4);
    }
    return length;
}

u32 XPredict_Write_node_leaf_value_0_Bytes(XPredict *InstancePtr, int offset, char *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length) > (XPREDICT_NODE_LEAF_VALUE_ADDR_NODE_LEAF_VALUE_0_HIGH - XPREDICT_NODE_LEAF_VALUE_ADDR_NODE_LEAF_VALUE_0_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(char *)(InstancePtr->Node_leaf_value_BaseAddress + XPREDICT_NODE_LEAF_VALUE_ADDR_NODE_LEAF_VALUE_0_BASE + offset + i) = *(data + i);
    }
    return length;
}

u32 XPredict_Read_node_leaf_value_0_Bytes(XPredict *InstancePtr, int offset, char *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length) > (XPREDICT_NODE_LEAF_VALUE_ADDR_NODE_LEAF_VALUE_0_HIGH - XPREDICT_NODE_LEAF_VALUE_ADDR_NODE_LEAF_VALUE_0_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(data + i) = *(char *)(InstancePtr->Node_leaf_value_BaseAddress + XPREDICT_NODE_LEAF_VALUE_ADDR_NODE_LEAF_VALUE_0_BASE + offset + i);
    }
    return length;
}

u32 XPredict_Get_node_leaf_value_1_BaseAddress(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (InstancePtr->Node_leaf_value_BaseAddress + XPREDICT_NODE_LEAF_VALUE_ADDR_NODE_LEAF_VALUE_1_BASE);
}

u32 XPredict_Get_node_leaf_value_1_HighAddress(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (InstancePtr->Node_leaf_value_BaseAddress + XPREDICT_NODE_LEAF_VALUE_ADDR_NODE_LEAF_VALUE_1_HIGH);
}

u32 XPredict_Get_node_leaf_value_1_TotalBytes(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (XPREDICT_NODE_LEAF_VALUE_ADDR_NODE_LEAF_VALUE_1_HIGH - XPREDICT_NODE_LEAF_VALUE_ADDR_NODE_LEAF_VALUE_1_BASE + 1);
}

u32 XPredict_Get_node_leaf_value_1_BitWidth(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XPREDICT_NODE_LEAF_VALUE_WIDTH_NODE_LEAF_VALUE_1;
}

u32 XPredict_Get_node_leaf_value_1_Depth(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XPREDICT_NODE_LEAF_VALUE_DEPTH_NODE_LEAF_VALUE_1;
}

u32 XPredict_Write_node_leaf_value_1_Words(XPredict *InstancePtr, int offset, word_type *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length)*4 > (XPREDICT_NODE_LEAF_VALUE_ADDR_NODE_LEAF_VALUE_1_HIGH - XPREDICT_NODE_LEAF_VALUE_ADDR_NODE_LEAF_VALUE_1_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(int *)(InstancePtr->Node_leaf_value_BaseAddress + XPREDICT_NODE_LEAF_VALUE_ADDR_NODE_LEAF_VALUE_1_BASE + (offset + i)*4) = *(data + i);
    }
    return length;
}

u32 XPredict_Read_node_leaf_value_1_Words(XPredict *InstancePtr, int offset, word_type *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length)*4 > (XPREDICT_NODE_LEAF_VALUE_ADDR_NODE_LEAF_VALUE_1_HIGH - XPREDICT_NODE_LEAF_VALUE_ADDR_NODE_LEAF_VALUE_1_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(data + i) = *(int *)(InstancePtr->Node_leaf_value_BaseAddress + XPREDICT_NODE_LEAF_VALUE_ADDR_NODE_LEAF_VALUE_1_BASE + (offset + i)*4);
    }
    return length;
}

u32 XPredict_Write_node_leaf_value_1_Bytes(XPredict *InstancePtr, int offset, char *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length) > (XPREDICT_NODE_LEAF_VALUE_ADDR_NODE_LEAF_VALUE_1_HIGH - XPREDICT_NODE_LEAF_VALUE_ADDR_NODE_LEAF_VALUE_1_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(char *)(InstancePtr->Node_leaf_value_BaseAddress + XPREDICT_NODE_LEAF_VALUE_ADDR_NODE_LEAF_VALUE_1_BASE + offset + i) = *(data + i);
    }
    return length;
}

u32 XPredict_Read_node_leaf_value_1_Bytes(XPredict *InstancePtr, int offset, char *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length) > (XPREDICT_NODE_LEAF_VALUE_ADDR_NODE_LEAF_VALUE_1_HIGH - XPREDICT_NODE_LEAF_VALUE_ADDR_NODE_LEAF_VALUE_1_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(data + i) = *(char *)(InstancePtr->Node_leaf_value_BaseAddress + XPREDICT_NODE_LEAF_VALUE_ADDR_NODE_LEAF_VALUE_1_BASE + offset + i);
    }
    return length;
}

u32 XPredict_Get_node_leaf_value_2_BaseAddress(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (InstancePtr->Node_leaf_value_BaseAddress + XPREDICT_NODE_LEAF_VALUE_ADDR_NODE_LEAF_VALUE_2_BASE);
}

u32 XPredict_Get_node_leaf_value_2_HighAddress(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (InstancePtr->Node_leaf_value_BaseAddress + XPREDICT_NODE_LEAF_VALUE_ADDR_NODE_LEAF_VALUE_2_HIGH);
}

u32 XPredict_Get_node_leaf_value_2_TotalBytes(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (XPREDICT_NODE_LEAF_VALUE_ADDR_NODE_LEAF_VALUE_2_HIGH - XPREDICT_NODE_LEAF_VALUE_ADDR_NODE_LEAF_VALUE_2_BASE + 1);
}

u32 XPredict_Get_node_leaf_value_2_BitWidth(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XPREDICT_NODE_LEAF_VALUE_WIDTH_NODE_LEAF_VALUE_2;
}

u32 XPredict_Get_node_leaf_value_2_Depth(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XPREDICT_NODE_LEAF_VALUE_DEPTH_NODE_LEAF_VALUE_2;
}

u32 XPredict_Write_node_leaf_value_2_Words(XPredict *InstancePtr, int offset, word_type *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length)*4 > (XPREDICT_NODE_LEAF_VALUE_ADDR_NODE_LEAF_VALUE_2_HIGH - XPREDICT_NODE_LEAF_VALUE_ADDR_NODE_LEAF_VALUE_2_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(int *)(InstancePtr->Node_leaf_value_BaseAddress + XPREDICT_NODE_LEAF_VALUE_ADDR_NODE_LEAF_VALUE_2_BASE + (offset + i)*4) = *(data + i);
    }
    return length;
}

u32 XPredict_Read_node_leaf_value_2_Words(XPredict *InstancePtr, int offset, word_type *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length)*4 > (XPREDICT_NODE_LEAF_VALUE_ADDR_NODE_LEAF_VALUE_2_HIGH - XPREDICT_NODE_LEAF_VALUE_ADDR_NODE_LEAF_VALUE_2_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(data + i) = *(int *)(InstancePtr->Node_leaf_value_BaseAddress + XPREDICT_NODE_LEAF_VALUE_ADDR_NODE_LEAF_VALUE_2_BASE + (offset + i)*4);
    }
    return length;
}

u32 XPredict_Write_node_leaf_value_2_Bytes(XPredict *InstancePtr, int offset, char *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length) > (XPREDICT_NODE_LEAF_VALUE_ADDR_NODE_LEAF_VALUE_2_HIGH - XPREDICT_NODE_LEAF_VALUE_ADDR_NODE_LEAF_VALUE_2_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(char *)(InstancePtr->Node_leaf_value_BaseAddress + XPREDICT_NODE_LEAF_VALUE_ADDR_NODE_LEAF_VALUE_2_BASE + offset + i) = *(data + i);
    }
    return length;
}

u32 XPredict_Read_node_leaf_value_2_Bytes(XPredict *InstancePtr, int offset, char *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length) > (XPREDICT_NODE_LEAF_VALUE_ADDR_NODE_LEAF_VALUE_2_HIGH - XPREDICT_NODE_LEAF_VALUE_ADDR_NODE_LEAF_VALUE_2_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(data + i) = *(char *)(InstancePtr->Node_leaf_value_BaseAddress + XPREDICT_NODE_LEAF_VALUE_ADDR_NODE_LEAF_VALUE_2_BASE + offset + i);
    }
    return length;
}

u32 XPredict_Get_node_leaf_value_3_BaseAddress(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (InstancePtr->Node_leaf_value_BaseAddress + XPREDICT_NODE_LEAF_VALUE_ADDR_NODE_LEAF_VALUE_3_BASE);
}

u32 XPredict_Get_node_leaf_value_3_HighAddress(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (InstancePtr->Node_leaf_value_BaseAddress + XPREDICT_NODE_LEAF_VALUE_ADDR_NODE_LEAF_VALUE_3_HIGH);
}

u32 XPredict_Get_node_leaf_value_3_TotalBytes(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (XPREDICT_NODE_LEAF_VALUE_ADDR_NODE_LEAF_VALUE_3_HIGH - XPREDICT_NODE_LEAF_VALUE_ADDR_NODE_LEAF_VALUE_3_BASE + 1);
}

u32 XPredict_Get_node_leaf_value_3_BitWidth(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XPREDICT_NODE_LEAF_VALUE_WIDTH_NODE_LEAF_VALUE_3;
}

u32 XPredict_Get_node_leaf_value_3_Depth(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XPREDICT_NODE_LEAF_VALUE_DEPTH_NODE_LEAF_VALUE_3;
}

u32 XPredict_Write_node_leaf_value_3_Words(XPredict *InstancePtr, int offset, word_type *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length)*4 > (XPREDICT_NODE_LEAF_VALUE_ADDR_NODE_LEAF_VALUE_3_HIGH - XPREDICT_NODE_LEAF_VALUE_ADDR_NODE_LEAF_VALUE_3_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(int *)(InstancePtr->Node_leaf_value_BaseAddress + XPREDICT_NODE_LEAF_VALUE_ADDR_NODE_LEAF_VALUE_3_BASE + (offset + i)*4) = *(data + i);
    }
    return length;
}

u32 XPredict_Read_node_leaf_value_3_Words(XPredict *InstancePtr, int offset, word_type *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length)*4 > (XPREDICT_NODE_LEAF_VALUE_ADDR_NODE_LEAF_VALUE_3_HIGH - XPREDICT_NODE_LEAF_VALUE_ADDR_NODE_LEAF_VALUE_3_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(data + i) = *(int *)(InstancePtr->Node_leaf_value_BaseAddress + XPREDICT_NODE_LEAF_VALUE_ADDR_NODE_LEAF_VALUE_3_BASE + (offset + i)*4);
    }
    return length;
}

u32 XPredict_Write_node_leaf_value_3_Bytes(XPredict *InstancePtr, int offset, char *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length) > (XPREDICT_NODE_LEAF_VALUE_ADDR_NODE_LEAF_VALUE_3_HIGH - XPREDICT_NODE_LEAF_VALUE_ADDR_NODE_LEAF_VALUE_3_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(char *)(InstancePtr->Node_leaf_value_BaseAddress + XPREDICT_NODE_LEAF_VALUE_ADDR_NODE_LEAF_VALUE_3_BASE + offset + i) = *(data + i);
    }
    return length;
}

u32 XPredict_Read_node_leaf_value_3_Bytes(XPredict *InstancePtr, int offset, char *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length) > (XPREDICT_NODE_LEAF_VALUE_ADDR_NODE_LEAF_VALUE_3_HIGH - XPREDICT_NODE_LEAF_VALUE_ADDR_NODE_LEAF_VALUE_3_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(data + i) = *(char *)(InstancePtr->Node_leaf_value_BaseAddress + XPREDICT_NODE_LEAF_VALUE_ADDR_NODE_LEAF_VALUE_3_BASE + offset + i);
    }
    return length;
}

u32 XPredict_Get_node_leaf_value_4_BaseAddress(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (InstancePtr->Node_leaf_value_BaseAddress + XPREDICT_NODE_LEAF_VALUE_ADDR_NODE_LEAF_VALUE_4_BASE);
}

u32 XPredict_Get_node_leaf_value_4_HighAddress(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (InstancePtr->Node_leaf_value_BaseAddress + XPREDICT_NODE_LEAF_VALUE_ADDR_NODE_LEAF_VALUE_4_HIGH);
}

u32 XPredict_Get_node_leaf_value_4_TotalBytes(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (XPREDICT_NODE_LEAF_VALUE_ADDR_NODE_LEAF_VALUE_4_HIGH - XPREDICT_NODE_LEAF_VALUE_ADDR_NODE_LEAF_VALUE_4_BASE + 1);
}

u32 XPredict_Get_node_leaf_value_4_BitWidth(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XPREDICT_NODE_LEAF_VALUE_WIDTH_NODE_LEAF_VALUE_4;
}

u32 XPredict_Get_node_leaf_value_4_Depth(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XPREDICT_NODE_LEAF_VALUE_DEPTH_NODE_LEAF_VALUE_4;
}

u32 XPredict_Write_node_leaf_value_4_Words(XPredict *InstancePtr, int offset, word_type *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length)*4 > (XPREDICT_NODE_LEAF_VALUE_ADDR_NODE_LEAF_VALUE_4_HIGH - XPREDICT_NODE_LEAF_VALUE_ADDR_NODE_LEAF_VALUE_4_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(int *)(InstancePtr->Node_leaf_value_BaseAddress + XPREDICT_NODE_LEAF_VALUE_ADDR_NODE_LEAF_VALUE_4_BASE + (offset + i)*4) = *(data + i);
    }
    return length;
}

u32 XPredict_Read_node_leaf_value_4_Words(XPredict *InstancePtr, int offset, word_type *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length)*4 > (XPREDICT_NODE_LEAF_VALUE_ADDR_NODE_LEAF_VALUE_4_HIGH - XPREDICT_NODE_LEAF_VALUE_ADDR_NODE_LEAF_VALUE_4_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(data + i) = *(int *)(InstancePtr->Node_leaf_value_BaseAddress + XPREDICT_NODE_LEAF_VALUE_ADDR_NODE_LEAF_VALUE_4_BASE + (offset + i)*4);
    }
    return length;
}

u32 XPredict_Write_node_leaf_value_4_Bytes(XPredict *InstancePtr, int offset, char *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length) > (XPREDICT_NODE_LEAF_VALUE_ADDR_NODE_LEAF_VALUE_4_HIGH - XPREDICT_NODE_LEAF_VALUE_ADDR_NODE_LEAF_VALUE_4_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(char *)(InstancePtr->Node_leaf_value_BaseAddress + XPREDICT_NODE_LEAF_VALUE_ADDR_NODE_LEAF_VALUE_4_BASE + offset + i) = *(data + i);
    }
    return length;
}

u32 XPredict_Read_node_leaf_value_4_Bytes(XPredict *InstancePtr, int offset, char *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length) > (XPREDICT_NODE_LEAF_VALUE_ADDR_NODE_LEAF_VALUE_4_HIGH - XPREDICT_NODE_LEAF_VALUE_ADDR_NODE_LEAF_VALUE_4_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(data + i) = *(char *)(InstancePtr->Node_leaf_value_BaseAddress + XPREDICT_NODE_LEAF_VALUE_ADDR_NODE_LEAF_VALUE_4_BASE + offset + i);
    }
    return length;
}

u32 XPredict_Get_node_leaf_value_5_BaseAddress(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (InstancePtr->Node_leaf_value_BaseAddress + XPREDICT_NODE_LEAF_VALUE_ADDR_NODE_LEAF_VALUE_5_BASE);
}

u32 XPredict_Get_node_leaf_value_5_HighAddress(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (InstancePtr->Node_leaf_value_BaseAddress + XPREDICT_NODE_LEAF_VALUE_ADDR_NODE_LEAF_VALUE_5_HIGH);
}

u32 XPredict_Get_node_leaf_value_5_TotalBytes(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (XPREDICT_NODE_LEAF_VALUE_ADDR_NODE_LEAF_VALUE_5_HIGH - XPREDICT_NODE_LEAF_VALUE_ADDR_NODE_LEAF_VALUE_5_BASE + 1);
}

u32 XPredict_Get_node_leaf_value_5_BitWidth(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XPREDICT_NODE_LEAF_VALUE_WIDTH_NODE_LEAF_VALUE_5;
}

u32 XPredict_Get_node_leaf_value_5_Depth(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XPREDICT_NODE_LEAF_VALUE_DEPTH_NODE_LEAF_VALUE_5;
}

u32 XPredict_Write_node_leaf_value_5_Words(XPredict *InstancePtr, int offset, word_type *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length)*4 > (XPREDICT_NODE_LEAF_VALUE_ADDR_NODE_LEAF_VALUE_5_HIGH - XPREDICT_NODE_LEAF_VALUE_ADDR_NODE_LEAF_VALUE_5_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(int *)(InstancePtr->Node_leaf_value_BaseAddress + XPREDICT_NODE_LEAF_VALUE_ADDR_NODE_LEAF_VALUE_5_BASE + (offset + i)*4) = *(data + i);
    }
    return length;
}

u32 XPredict_Read_node_leaf_value_5_Words(XPredict *InstancePtr, int offset, word_type *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length)*4 > (XPREDICT_NODE_LEAF_VALUE_ADDR_NODE_LEAF_VALUE_5_HIGH - XPREDICT_NODE_LEAF_VALUE_ADDR_NODE_LEAF_VALUE_5_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(data + i) = *(int *)(InstancePtr->Node_leaf_value_BaseAddress + XPREDICT_NODE_LEAF_VALUE_ADDR_NODE_LEAF_VALUE_5_BASE + (offset + i)*4);
    }
    return length;
}

u32 XPredict_Write_node_leaf_value_5_Bytes(XPredict *InstancePtr, int offset, char *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length) > (XPREDICT_NODE_LEAF_VALUE_ADDR_NODE_LEAF_VALUE_5_HIGH - XPREDICT_NODE_LEAF_VALUE_ADDR_NODE_LEAF_VALUE_5_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(char *)(InstancePtr->Node_leaf_value_BaseAddress + XPREDICT_NODE_LEAF_VALUE_ADDR_NODE_LEAF_VALUE_5_BASE + offset + i) = *(data + i);
    }
    return length;
}

u32 XPredict_Read_node_leaf_value_5_Bytes(XPredict *InstancePtr, int offset, char *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length) > (XPREDICT_NODE_LEAF_VALUE_ADDR_NODE_LEAF_VALUE_5_HIGH - XPREDICT_NODE_LEAF_VALUE_ADDR_NODE_LEAF_VALUE_5_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(data + i) = *(char *)(InstancePtr->Node_leaf_value_BaseAddress + XPREDICT_NODE_LEAF_VALUE_ADDR_NODE_LEAF_VALUE_5_BASE + offset + i);
    }
    return length;
}

u32 XPredict_Get_node_leaf_value_6_BaseAddress(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (InstancePtr->Node_leaf_value_BaseAddress + XPREDICT_NODE_LEAF_VALUE_ADDR_NODE_LEAF_VALUE_6_BASE);
}

u32 XPredict_Get_node_leaf_value_6_HighAddress(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (InstancePtr->Node_leaf_value_BaseAddress + XPREDICT_NODE_LEAF_VALUE_ADDR_NODE_LEAF_VALUE_6_HIGH);
}

u32 XPredict_Get_node_leaf_value_6_TotalBytes(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (XPREDICT_NODE_LEAF_VALUE_ADDR_NODE_LEAF_VALUE_6_HIGH - XPREDICT_NODE_LEAF_VALUE_ADDR_NODE_LEAF_VALUE_6_BASE + 1);
}

u32 XPredict_Get_node_leaf_value_6_BitWidth(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XPREDICT_NODE_LEAF_VALUE_WIDTH_NODE_LEAF_VALUE_6;
}

u32 XPredict_Get_node_leaf_value_6_Depth(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XPREDICT_NODE_LEAF_VALUE_DEPTH_NODE_LEAF_VALUE_6;
}

u32 XPredict_Write_node_leaf_value_6_Words(XPredict *InstancePtr, int offset, word_type *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length)*4 > (XPREDICT_NODE_LEAF_VALUE_ADDR_NODE_LEAF_VALUE_6_HIGH - XPREDICT_NODE_LEAF_VALUE_ADDR_NODE_LEAF_VALUE_6_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(int *)(InstancePtr->Node_leaf_value_BaseAddress + XPREDICT_NODE_LEAF_VALUE_ADDR_NODE_LEAF_VALUE_6_BASE + (offset + i)*4) = *(data + i);
    }
    return length;
}

u32 XPredict_Read_node_leaf_value_6_Words(XPredict *InstancePtr, int offset, word_type *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length)*4 > (XPREDICT_NODE_LEAF_VALUE_ADDR_NODE_LEAF_VALUE_6_HIGH - XPREDICT_NODE_LEAF_VALUE_ADDR_NODE_LEAF_VALUE_6_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(data + i) = *(int *)(InstancePtr->Node_leaf_value_BaseAddress + XPREDICT_NODE_LEAF_VALUE_ADDR_NODE_LEAF_VALUE_6_BASE + (offset + i)*4);
    }
    return length;
}

u32 XPredict_Write_node_leaf_value_6_Bytes(XPredict *InstancePtr, int offset, char *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length) > (XPREDICT_NODE_LEAF_VALUE_ADDR_NODE_LEAF_VALUE_6_HIGH - XPREDICT_NODE_LEAF_VALUE_ADDR_NODE_LEAF_VALUE_6_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(char *)(InstancePtr->Node_leaf_value_BaseAddress + XPREDICT_NODE_LEAF_VALUE_ADDR_NODE_LEAF_VALUE_6_BASE + offset + i) = *(data + i);
    }
    return length;
}

u32 XPredict_Read_node_leaf_value_6_Bytes(XPredict *InstancePtr, int offset, char *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length) > (XPREDICT_NODE_LEAF_VALUE_ADDR_NODE_LEAF_VALUE_6_HIGH - XPREDICT_NODE_LEAF_VALUE_ADDR_NODE_LEAF_VALUE_6_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(data + i) = *(char *)(InstancePtr->Node_leaf_value_BaseAddress + XPREDICT_NODE_LEAF_VALUE_ADDR_NODE_LEAF_VALUE_6_BASE + offset + i);
    }
    return length;
}

u32 XPredict_Get_node_leaf_value_7_BaseAddress(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (InstancePtr->Node_leaf_value_BaseAddress + XPREDICT_NODE_LEAF_VALUE_ADDR_NODE_LEAF_VALUE_7_BASE);
}

u32 XPredict_Get_node_leaf_value_7_HighAddress(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (InstancePtr->Node_leaf_value_BaseAddress + XPREDICT_NODE_LEAF_VALUE_ADDR_NODE_LEAF_VALUE_7_HIGH);
}

u32 XPredict_Get_node_leaf_value_7_TotalBytes(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (XPREDICT_NODE_LEAF_VALUE_ADDR_NODE_LEAF_VALUE_7_HIGH - XPREDICT_NODE_LEAF_VALUE_ADDR_NODE_LEAF_VALUE_7_BASE + 1);
}

u32 XPredict_Get_node_leaf_value_7_BitWidth(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XPREDICT_NODE_LEAF_VALUE_WIDTH_NODE_LEAF_VALUE_7;
}

u32 XPredict_Get_node_leaf_value_7_Depth(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XPREDICT_NODE_LEAF_VALUE_DEPTH_NODE_LEAF_VALUE_7;
}

u32 XPredict_Write_node_leaf_value_7_Words(XPredict *InstancePtr, int offset, word_type *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length)*4 > (XPREDICT_NODE_LEAF_VALUE_ADDR_NODE_LEAF_VALUE_7_HIGH - XPREDICT_NODE_LEAF_VALUE_ADDR_NODE_LEAF_VALUE_7_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(int *)(InstancePtr->Node_leaf_value_BaseAddress + XPREDICT_NODE_LEAF_VALUE_ADDR_NODE_LEAF_VALUE_7_BASE + (offset + i)*4) = *(data + i);
    }
    return length;
}

u32 XPredict_Read_node_leaf_value_7_Words(XPredict *InstancePtr, int offset, word_type *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length)*4 > (XPREDICT_NODE_LEAF_VALUE_ADDR_NODE_LEAF_VALUE_7_HIGH - XPREDICT_NODE_LEAF_VALUE_ADDR_NODE_LEAF_VALUE_7_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(data + i) = *(int *)(InstancePtr->Node_leaf_value_BaseAddress + XPREDICT_NODE_LEAF_VALUE_ADDR_NODE_LEAF_VALUE_7_BASE + (offset + i)*4);
    }
    return length;
}

u32 XPredict_Write_node_leaf_value_7_Bytes(XPredict *InstancePtr, int offset, char *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length) > (XPREDICT_NODE_LEAF_VALUE_ADDR_NODE_LEAF_VALUE_7_HIGH - XPREDICT_NODE_LEAF_VALUE_ADDR_NODE_LEAF_VALUE_7_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(char *)(InstancePtr->Node_leaf_value_BaseAddress + XPREDICT_NODE_LEAF_VALUE_ADDR_NODE_LEAF_VALUE_7_BASE + offset + i) = *(data + i);
    }
    return length;
}

u32 XPredict_Read_node_leaf_value_7_Bytes(XPredict *InstancePtr, int offset, char *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length) > (XPREDICT_NODE_LEAF_VALUE_ADDR_NODE_LEAF_VALUE_7_HIGH - XPREDICT_NODE_LEAF_VALUE_ADDR_NODE_LEAF_VALUE_7_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(data + i) = *(char *)(InstancePtr->Node_leaf_value_BaseAddress + XPREDICT_NODE_LEAF_VALUE_ADDR_NODE_LEAF_VALUE_7_BASE + offset + i);
    }
    return length;
}

u32 XPredict_Get_node_leaf_value_8_BaseAddress(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (InstancePtr->Node_leaf_value_BaseAddress + XPREDICT_NODE_LEAF_VALUE_ADDR_NODE_LEAF_VALUE_8_BASE);
}

u32 XPredict_Get_node_leaf_value_8_HighAddress(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (InstancePtr->Node_leaf_value_BaseAddress + XPREDICT_NODE_LEAF_VALUE_ADDR_NODE_LEAF_VALUE_8_HIGH);
}

u32 XPredict_Get_node_leaf_value_8_TotalBytes(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (XPREDICT_NODE_LEAF_VALUE_ADDR_NODE_LEAF_VALUE_8_HIGH - XPREDICT_NODE_LEAF_VALUE_ADDR_NODE_LEAF_VALUE_8_BASE + 1);
}

u32 XPredict_Get_node_leaf_value_8_BitWidth(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XPREDICT_NODE_LEAF_VALUE_WIDTH_NODE_LEAF_VALUE_8;
}

u32 XPredict_Get_node_leaf_value_8_Depth(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XPREDICT_NODE_LEAF_VALUE_DEPTH_NODE_LEAF_VALUE_8;
}

u32 XPredict_Write_node_leaf_value_8_Words(XPredict *InstancePtr, int offset, word_type *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length)*4 > (XPREDICT_NODE_LEAF_VALUE_ADDR_NODE_LEAF_VALUE_8_HIGH - XPREDICT_NODE_LEAF_VALUE_ADDR_NODE_LEAF_VALUE_8_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(int *)(InstancePtr->Node_leaf_value_BaseAddress + XPREDICT_NODE_LEAF_VALUE_ADDR_NODE_LEAF_VALUE_8_BASE + (offset + i)*4) = *(data + i);
    }
    return length;
}

u32 XPredict_Read_node_leaf_value_8_Words(XPredict *InstancePtr, int offset, word_type *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length)*4 > (XPREDICT_NODE_LEAF_VALUE_ADDR_NODE_LEAF_VALUE_8_HIGH - XPREDICT_NODE_LEAF_VALUE_ADDR_NODE_LEAF_VALUE_8_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(data + i) = *(int *)(InstancePtr->Node_leaf_value_BaseAddress + XPREDICT_NODE_LEAF_VALUE_ADDR_NODE_LEAF_VALUE_8_BASE + (offset + i)*4);
    }
    return length;
}

u32 XPredict_Write_node_leaf_value_8_Bytes(XPredict *InstancePtr, int offset, char *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length) > (XPREDICT_NODE_LEAF_VALUE_ADDR_NODE_LEAF_VALUE_8_HIGH - XPREDICT_NODE_LEAF_VALUE_ADDR_NODE_LEAF_VALUE_8_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(char *)(InstancePtr->Node_leaf_value_BaseAddress + XPREDICT_NODE_LEAF_VALUE_ADDR_NODE_LEAF_VALUE_8_BASE + offset + i) = *(data + i);
    }
    return length;
}

u32 XPredict_Read_node_leaf_value_8_Bytes(XPredict *InstancePtr, int offset, char *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length) > (XPREDICT_NODE_LEAF_VALUE_ADDR_NODE_LEAF_VALUE_8_HIGH - XPREDICT_NODE_LEAF_VALUE_ADDR_NODE_LEAF_VALUE_8_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(data + i) = *(char *)(InstancePtr->Node_leaf_value_BaseAddress + XPREDICT_NODE_LEAF_VALUE_ADDR_NODE_LEAF_VALUE_8_BASE + offset + i);
    }
    return length;
}

u32 XPredict_Get_node_leaf_value_9_BaseAddress(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (InstancePtr->Node_leaf_value_BaseAddress + XPREDICT_NODE_LEAF_VALUE_ADDR_NODE_LEAF_VALUE_9_BASE);
}

u32 XPredict_Get_node_leaf_value_9_HighAddress(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (InstancePtr->Node_leaf_value_BaseAddress + XPREDICT_NODE_LEAF_VALUE_ADDR_NODE_LEAF_VALUE_9_HIGH);
}

u32 XPredict_Get_node_leaf_value_9_TotalBytes(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (XPREDICT_NODE_LEAF_VALUE_ADDR_NODE_LEAF_VALUE_9_HIGH - XPREDICT_NODE_LEAF_VALUE_ADDR_NODE_LEAF_VALUE_9_BASE + 1);
}

u32 XPredict_Get_node_leaf_value_9_BitWidth(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XPREDICT_NODE_LEAF_VALUE_WIDTH_NODE_LEAF_VALUE_9;
}

u32 XPredict_Get_node_leaf_value_9_Depth(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XPREDICT_NODE_LEAF_VALUE_DEPTH_NODE_LEAF_VALUE_9;
}

u32 XPredict_Write_node_leaf_value_9_Words(XPredict *InstancePtr, int offset, word_type *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length)*4 > (XPREDICT_NODE_LEAF_VALUE_ADDR_NODE_LEAF_VALUE_9_HIGH - XPREDICT_NODE_LEAF_VALUE_ADDR_NODE_LEAF_VALUE_9_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(int *)(InstancePtr->Node_leaf_value_BaseAddress + XPREDICT_NODE_LEAF_VALUE_ADDR_NODE_LEAF_VALUE_9_BASE + (offset + i)*4) = *(data + i);
    }
    return length;
}

u32 XPredict_Read_node_leaf_value_9_Words(XPredict *InstancePtr, int offset, word_type *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length)*4 > (XPREDICT_NODE_LEAF_VALUE_ADDR_NODE_LEAF_VALUE_9_HIGH - XPREDICT_NODE_LEAF_VALUE_ADDR_NODE_LEAF_VALUE_9_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(data + i) = *(int *)(InstancePtr->Node_leaf_value_BaseAddress + XPREDICT_NODE_LEAF_VALUE_ADDR_NODE_LEAF_VALUE_9_BASE + (offset + i)*4);
    }
    return length;
}

u32 XPredict_Write_node_leaf_value_9_Bytes(XPredict *InstancePtr, int offset, char *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length) > (XPREDICT_NODE_LEAF_VALUE_ADDR_NODE_LEAF_VALUE_9_HIGH - XPREDICT_NODE_LEAF_VALUE_ADDR_NODE_LEAF_VALUE_9_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(char *)(InstancePtr->Node_leaf_value_BaseAddress + XPREDICT_NODE_LEAF_VALUE_ADDR_NODE_LEAF_VALUE_9_BASE + offset + i) = *(data + i);
    }
    return length;
}

u32 XPredict_Read_node_leaf_value_9_Bytes(XPredict *InstancePtr, int offset, char *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length) > (XPREDICT_NODE_LEAF_VALUE_ADDR_NODE_LEAF_VALUE_9_HIGH - XPREDICT_NODE_LEAF_VALUE_ADDR_NODE_LEAF_VALUE_9_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(data + i) = *(char *)(InstancePtr->Node_leaf_value_BaseAddress + XPREDICT_NODE_LEAF_VALUE_ADDR_NODE_LEAF_VALUE_9_BASE + offset + i);
    }
    return length;
}

void XPredict_InterruptGlobalEnable(XPredict *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XPredict_WriteReg(InstancePtr->Results_BaseAddress, XPREDICT_RESULTS_ADDR_GIE, 1);
}

void XPredict_InterruptGlobalDisable(XPredict *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XPredict_WriteReg(InstancePtr->Results_BaseAddress, XPREDICT_RESULTS_ADDR_GIE, 0);
}

void XPredict_InterruptEnable(XPredict *InstancePtr, u32 Mask) {
    u32 Register;

    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Register =  XPredict_ReadReg(InstancePtr->Results_BaseAddress, XPREDICT_RESULTS_ADDR_IER);
    XPredict_WriteReg(InstancePtr->Results_BaseAddress, XPREDICT_RESULTS_ADDR_IER, Register | Mask);
}

void XPredict_InterruptDisable(XPredict *InstancePtr, u32 Mask) {
    u32 Register;

    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Register =  XPredict_ReadReg(InstancePtr->Results_BaseAddress, XPREDICT_RESULTS_ADDR_IER);
    XPredict_WriteReg(InstancePtr->Results_BaseAddress, XPREDICT_RESULTS_ADDR_IER, Register & (~Mask));
}

void XPredict_InterruptClear(XPredict *InstancePtr, u32 Mask) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XPredict_WriteReg(InstancePtr->Results_BaseAddress, XPREDICT_RESULTS_ADDR_ISR, Mask);
}

u32 XPredict_InterruptGetEnabled(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XPredict_ReadReg(InstancePtr->Results_BaseAddress, XPREDICT_RESULTS_ADDR_IER);
}

u32 XPredict_InterruptGetStatus(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XPredict_ReadReg(InstancePtr->Results_BaseAddress, XPREDICT_RESULTS_ADDR_ISR);
}

