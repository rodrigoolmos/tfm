// ==============================================================
// Vitis HLS - High-Level Synthesis from C, C++ and OpenCL v2023.1.1 (64-bit)
// Tool Version Limit: 2023.06
// Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
// Copyright 2022-2023 Advanced Micro Devices, Inc. All Rights Reserved.
// 
// ==============================================================
// compact_data
// 0x040 ~
// 0x07f : Memory 'compact_data_0' (64 * 8b)
//         Word n : bit [ 7: 0] - compact_data_0[4n]
//                  bit [15: 8] - compact_data_0[4n+1]
//                  bit [23:16] - compact_data_0[4n+2]
//                  bit [31:24] - compact_data_0[4n+3]
// 0x080 ~
// 0x0bf : Memory 'compact_data_1' (64 * 8b)
//         Word n : bit [ 7: 0] - compact_data_1[4n]
//                  bit [15: 8] - compact_data_1[4n+1]
//                  bit [23:16] - compact_data_1[4n+2]
//                  bit [31:24] - compact_data_1[4n+3]
// 0x0c0 ~
// 0x0ff : Memory 'compact_data_2' (64 * 8b)
//         Word n : bit [ 7: 0] - compact_data_2[4n]
//                  bit [15: 8] - compact_data_2[4n+1]
//                  bit [23:16] - compact_data_2[4n+2]
//                  bit [31:24] - compact_data_2[4n+3]
// 0x100 ~
// 0x13f : Memory 'compact_data_3' (64 * 8b)
//         Word n : bit [ 7: 0] - compact_data_3[4n]
//                  bit [15: 8] - compact_data_3[4n+1]
//                  bit [23:16] - compact_data_3[4n+2]
//                  bit [31:24] - compact_data_3[4n+3]
// 0x140 ~
// 0x17f : Memory 'compact_data_4' (64 * 8b)
//         Word n : bit [ 7: 0] - compact_data_4[4n]
//                  bit [15: 8] - compact_data_4[4n+1]
//                  bit [23:16] - compact_data_4[4n+2]
//                  bit [31:24] - compact_data_4[4n+3]
// 0x180 ~
// 0x1bf : Memory 'compact_data_5' (64 * 8b)
//         Word n : bit [ 7: 0] - compact_data_5[4n]
//                  bit [15: 8] - compact_data_5[4n+1]
//                  bit [23:16] - compact_data_5[4n+2]
//                  bit [31:24] - compact_data_5[4n+3]
// 0x1c0 ~
// 0x1ff : Memory 'compact_data_6' (64 * 8b)
//         Word n : bit [ 7: 0] - compact_data_6[4n]
//                  bit [15: 8] - compact_data_6[4n+1]
//                  bit [23:16] - compact_data_6[4n+2]
//                  bit [31:24] - compact_data_6[4n+3]
// 0x200 ~
// 0x23f : Memory 'compact_data_7' (64 * 8b)
//         Word n : bit [ 7: 0] - compact_data_7[4n]
//                  bit [15: 8] - compact_data_7[4n+1]
//                  bit [23:16] - compact_data_7[4n+2]
//                  bit [31:24] - compact_data_7[4n+3]
// 0x240 ~
// 0x27f : Memory 'compact_data_8' (64 * 8b)
//         Word n : bit [ 7: 0] - compact_data_8[4n]
//                  bit [15: 8] - compact_data_8[4n+1]
//                  bit [23:16] - compact_data_8[4n+2]
//                  bit [31:24] - compact_data_8[4n+3]
// 0x280 ~
// 0x2bf : Memory 'compact_data_9' (64 * 8b)
//         Word n : bit [ 7: 0] - compact_data_9[4n]
//                  bit [15: 8] - compact_data_9[4n+1]
//                  bit [23:16] - compact_data_9[4n+2]
//                  bit [31:24] - compact_data_9[4n+3]
// (SC = Self Clear, COR = Clear on Read, TOW = Toggle on Write, COH = Clear on Handshake)

#define XPREDICT_COMPACT_DATA_ADDR_COMPACT_DATA_0_BASE 0x040
#define XPREDICT_COMPACT_DATA_ADDR_COMPACT_DATA_0_HIGH 0x07f
#define XPREDICT_COMPACT_DATA_WIDTH_COMPACT_DATA_0     8
#define XPREDICT_COMPACT_DATA_DEPTH_COMPACT_DATA_0     64
#define XPREDICT_COMPACT_DATA_ADDR_COMPACT_DATA_1_BASE 0x080
#define XPREDICT_COMPACT_DATA_ADDR_COMPACT_DATA_1_HIGH 0x0bf
#define XPREDICT_COMPACT_DATA_WIDTH_COMPACT_DATA_1     8
#define XPREDICT_COMPACT_DATA_DEPTH_COMPACT_DATA_1     64
#define XPREDICT_COMPACT_DATA_ADDR_COMPACT_DATA_2_BASE 0x0c0
#define XPREDICT_COMPACT_DATA_ADDR_COMPACT_DATA_2_HIGH 0x0ff
#define XPREDICT_COMPACT_DATA_WIDTH_COMPACT_DATA_2     8
#define XPREDICT_COMPACT_DATA_DEPTH_COMPACT_DATA_2     64
#define XPREDICT_COMPACT_DATA_ADDR_COMPACT_DATA_3_BASE 0x100
#define XPREDICT_COMPACT_DATA_ADDR_COMPACT_DATA_3_HIGH 0x13f
#define XPREDICT_COMPACT_DATA_WIDTH_COMPACT_DATA_3     8
#define XPREDICT_COMPACT_DATA_DEPTH_COMPACT_DATA_3     64
#define XPREDICT_COMPACT_DATA_ADDR_COMPACT_DATA_4_BASE 0x140
#define XPREDICT_COMPACT_DATA_ADDR_COMPACT_DATA_4_HIGH 0x17f
#define XPREDICT_COMPACT_DATA_WIDTH_COMPACT_DATA_4     8
#define XPREDICT_COMPACT_DATA_DEPTH_COMPACT_DATA_4     64
#define XPREDICT_COMPACT_DATA_ADDR_COMPACT_DATA_5_BASE 0x180
#define XPREDICT_COMPACT_DATA_ADDR_COMPACT_DATA_5_HIGH 0x1bf
#define XPREDICT_COMPACT_DATA_WIDTH_COMPACT_DATA_5     8
#define XPREDICT_COMPACT_DATA_DEPTH_COMPACT_DATA_5     64
#define XPREDICT_COMPACT_DATA_ADDR_COMPACT_DATA_6_BASE 0x1c0
#define XPREDICT_COMPACT_DATA_ADDR_COMPACT_DATA_6_HIGH 0x1ff
#define XPREDICT_COMPACT_DATA_WIDTH_COMPACT_DATA_6     8
#define XPREDICT_COMPACT_DATA_DEPTH_COMPACT_DATA_6     64
#define XPREDICT_COMPACT_DATA_ADDR_COMPACT_DATA_7_BASE 0x200
#define XPREDICT_COMPACT_DATA_ADDR_COMPACT_DATA_7_HIGH 0x23f
#define XPREDICT_COMPACT_DATA_WIDTH_COMPACT_DATA_7     8
#define XPREDICT_COMPACT_DATA_DEPTH_COMPACT_DATA_7     64
#define XPREDICT_COMPACT_DATA_ADDR_COMPACT_DATA_8_BASE 0x240
#define XPREDICT_COMPACT_DATA_ADDR_COMPACT_DATA_8_HIGH 0x27f
#define XPREDICT_COMPACT_DATA_WIDTH_COMPACT_DATA_8     8
#define XPREDICT_COMPACT_DATA_DEPTH_COMPACT_DATA_8     64
#define XPREDICT_COMPACT_DATA_ADDR_COMPACT_DATA_9_BASE 0x280
#define XPREDICT_COMPACT_DATA_ADDR_COMPACT_DATA_9_HIGH 0x2bf
#define XPREDICT_COMPACT_DATA_WIDTH_COMPACT_DATA_9     8
#define XPREDICT_COMPACT_DATA_DEPTH_COMPACT_DATA_9     64

// features
// 0x10 ~
// 0x17 : Memory 'features_0' (2 * 32b)
//        Word n : bit [31:0] - features_0[n]
// 0x18 ~
// 0x1f : Memory 'features_1' (2 * 32b)
//        Word n : bit [31:0] - features_1[n]
// 0x20 ~
// 0x27 : Memory 'features_2' (2 * 32b)
//        Word n : bit [31:0] - features_2[n]
// 0x28 ~
// 0x2f : Memory 'features_3' (2 * 32b)
//        Word n : bit [31:0] - features_3[n]
// 0x30 ~
// 0x37 : Memory 'features_4' (2 * 32b)
//        Word n : bit [31:0] - features_4[n]
// 0x38 ~
// 0x3f : Memory 'features_5' (2 * 32b)
//        Word n : bit [31:0] - features_5[n]
// 0x40 ~
// 0x47 : Memory 'features_6' (2 * 32b)
//        Word n : bit [31:0] - features_6[n]
// 0x48 ~
// 0x4f : Memory 'features_7' (2 * 32b)
//        Word n : bit [31:0] - features_7[n]
// 0x50 ~
// 0x57 : Memory 'features_8' (2 * 32b)
//        Word n : bit [31:0] - features_8[n]
// 0x58 ~
// 0x5f : Memory 'features_9' (2 * 32b)
//        Word n : bit [31:0] - features_9[n]
// 0x60 ~
// 0x67 : Memory 'features_10' (2 * 32b)
//        Word n : bit [31:0] - features_10[n]
// 0x68 ~
// 0x6f : Memory 'features_11' (2 * 32b)
//        Word n : bit [31:0] - features_11[n]
// 0x70 ~
// 0x77 : Memory 'features_12' (2 * 32b)
//        Word n : bit [31:0] - features_12[n]
// 0x78 ~
// 0x7f : Memory 'features_13' (2 * 32b)
//        Word n : bit [31:0] - features_13[n]
// 0x80 ~
// 0x87 : Memory 'features_14' (2 * 32b)
//        Word n : bit [31:0] - features_14[n]
// 0x88 ~
// 0x8f : Memory 'features_15' (2 * 32b)
//        Word n : bit [31:0] - features_15[n]
// 0x90 ~
// 0x97 : Memory 'features_16' (2 * 32b)
//        Word n : bit [31:0] - features_16[n]
// 0x98 ~
// 0x9f : Memory 'features_17' (2 * 32b)
//        Word n : bit [31:0] - features_17[n]
// 0xa0 ~
// 0xa7 : Memory 'features_18' (2 * 32b)
//        Word n : bit [31:0] - features_18[n]
// 0xa8 ~
// 0xaf : Memory 'features_19' (2 * 32b)
//        Word n : bit [31:0] - features_19[n]
// 0xb0 ~
// 0xb7 : Memory 'features_20' (2 * 32b)
//        Word n : bit [31:0] - features_20[n]
// 0xb8 ~
// 0xbf : Memory 'features_21' (2 * 32b)
//        Word n : bit [31:0] - features_21[n]
// 0xc0 ~
// 0xc7 : Memory 'features_22' (2 * 32b)
//        Word n : bit [31:0] - features_22[n]
// 0xc8 ~
// 0xcf : Memory 'features_23' (2 * 32b)
//        Word n : bit [31:0] - features_23[n]
// 0xd0 ~
// 0xd7 : Memory 'features_24' (2 * 32b)
//        Word n : bit [31:0] - features_24[n]
// (SC = Self Clear, COR = Clear on Read, TOW = Toggle on Write, COH = Clear on Handshake)

#define XPREDICT_FEATURES_ADDR_FEATURES_0_BASE  0x10
#define XPREDICT_FEATURES_ADDR_FEATURES_0_HIGH  0x17
#define XPREDICT_FEATURES_WIDTH_FEATURES_0      32
#define XPREDICT_FEATURES_DEPTH_FEATURES_0      2
#define XPREDICT_FEATURES_ADDR_FEATURES_1_BASE  0x18
#define XPREDICT_FEATURES_ADDR_FEATURES_1_HIGH  0x1f
#define XPREDICT_FEATURES_WIDTH_FEATURES_1      32
#define XPREDICT_FEATURES_DEPTH_FEATURES_1      2
#define XPREDICT_FEATURES_ADDR_FEATURES_2_BASE  0x20
#define XPREDICT_FEATURES_ADDR_FEATURES_2_HIGH  0x27
#define XPREDICT_FEATURES_WIDTH_FEATURES_2      32
#define XPREDICT_FEATURES_DEPTH_FEATURES_2      2
#define XPREDICT_FEATURES_ADDR_FEATURES_3_BASE  0x28
#define XPREDICT_FEATURES_ADDR_FEATURES_3_HIGH  0x2f
#define XPREDICT_FEATURES_WIDTH_FEATURES_3      32
#define XPREDICT_FEATURES_DEPTH_FEATURES_3      2
#define XPREDICT_FEATURES_ADDR_FEATURES_4_BASE  0x30
#define XPREDICT_FEATURES_ADDR_FEATURES_4_HIGH  0x37
#define XPREDICT_FEATURES_WIDTH_FEATURES_4      32
#define XPREDICT_FEATURES_DEPTH_FEATURES_4      2
#define XPREDICT_FEATURES_ADDR_FEATURES_5_BASE  0x38
#define XPREDICT_FEATURES_ADDR_FEATURES_5_HIGH  0x3f
#define XPREDICT_FEATURES_WIDTH_FEATURES_5      32
#define XPREDICT_FEATURES_DEPTH_FEATURES_5      2
#define XPREDICT_FEATURES_ADDR_FEATURES_6_BASE  0x40
#define XPREDICT_FEATURES_ADDR_FEATURES_6_HIGH  0x47
#define XPREDICT_FEATURES_WIDTH_FEATURES_6      32
#define XPREDICT_FEATURES_DEPTH_FEATURES_6      2
#define XPREDICT_FEATURES_ADDR_FEATURES_7_BASE  0x48
#define XPREDICT_FEATURES_ADDR_FEATURES_7_HIGH  0x4f
#define XPREDICT_FEATURES_WIDTH_FEATURES_7      32
#define XPREDICT_FEATURES_DEPTH_FEATURES_7      2
#define XPREDICT_FEATURES_ADDR_FEATURES_8_BASE  0x50
#define XPREDICT_FEATURES_ADDR_FEATURES_8_HIGH  0x57
#define XPREDICT_FEATURES_WIDTH_FEATURES_8      32
#define XPREDICT_FEATURES_DEPTH_FEATURES_8      2
#define XPREDICT_FEATURES_ADDR_FEATURES_9_BASE  0x58
#define XPREDICT_FEATURES_ADDR_FEATURES_9_HIGH  0x5f
#define XPREDICT_FEATURES_WIDTH_FEATURES_9      32
#define XPREDICT_FEATURES_DEPTH_FEATURES_9      2
#define XPREDICT_FEATURES_ADDR_FEATURES_10_BASE 0x60
#define XPREDICT_FEATURES_ADDR_FEATURES_10_HIGH 0x67
#define XPREDICT_FEATURES_WIDTH_FEATURES_10     32
#define XPREDICT_FEATURES_DEPTH_FEATURES_10     2
#define XPREDICT_FEATURES_ADDR_FEATURES_11_BASE 0x68
#define XPREDICT_FEATURES_ADDR_FEATURES_11_HIGH 0x6f
#define XPREDICT_FEATURES_WIDTH_FEATURES_11     32
#define XPREDICT_FEATURES_DEPTH_FEATURES_11     2
#define XPREDICT_FEATURES_ADDR_FEATURES_12_BASE 0x70
#define XPREDICT_FEATURES_ADDR_FEATURES_12_HIGH 0x77
#define XPREDICT_FEATURES_WIDTH_FEATURES_12     32
#define XPREDICT_FEATURES_DEPTH_FEATURES_12     2
#define XPREDICT_FEATURES_ADDR_FEATURES_13_BASE 0x78
#define XPREDICT_FEATURES_ADDR_FEATURES_13_HIGH 0x7f
#define XPREDICT_FEATURES_WIDTH_FEATURES_13     32
#define XPREDICT_FEATURES_DEPTH_FEATURES_13     2
#define XPREDICT_FEATURES_ADDR_FEATURES_14_BASE 0x80
#define XPREDICT_FEATURES_ADDR_FEATURES_14_HIGH 0x87
#define XPREDICT_FEATURES_WIDTH_FEATURES_14     32
#define XPREDICT_FEATURES_DEPTH_FEATURES_14     2
#define XPREDICT_FEATURES_ADDR_FEATURES_15_BASE 0x88
#define XPREDICT_FEATURES_ADDR_FEATURES_15_HIGH 0x8f
#define XPREDICT_FEATURES_WIDTH_FEATURES_15     32
#define XPREDICT_FEATURES_DEPTH_FEATURES_15     2
#define XPREDICT_FEATURES_ADDR_FEATURES_16_BASE 0x90
#define XPREDICT_FEATURES_ADDR_FEATURES_16_HIGH 0x97
#define XPREDICT_FEATURES_WIDTH_FEATURES_16     32
#define XPREDICT_FEATURES_DEPTH_FEATURES_16     2
#define XPREDICT_FEATURES_ADDR_FEATURES_17_BASE 0x98
#define XPREDICT_FEATURES_ADDR_FEATURES_17_HIGH 0x9f
#define XPREDICT_FEATURES_WIDTH_FEATURES_17     32
#define XPREDICT_FEATURES_DEPTH_FEATURES_17     2
#define XPREDICT_FEATURES_ADDR_FEATURES_18_BASE 0xa0
#define XPREDICT_FEATURES_ADDR_FEATURES_18_HIGH 0xa7
#define XPREDICT_FEATURES_WIDTH_FEATURES_18     32
#define XPREDICT_FEATURES_DEPTH_FEATURES_18     2
#define XPREDICT_FEATURES_ADDR_FEATURES_19_BASE 0xa8
#define XPREDICT_FEATURES_ADDR_FEATURES_19_HIGH 0xaf
#define XPREDICT_FEATURES_WIDTH_FEATURES_19     32
#define XPREDICT_FEATURES_DEPTH_FEATURES_19     2
#define XPREDICT_FEATURES_ADDR_FEATURES_20_BASE 0xb0
#define XPREDICT_FEATURES_ADDR_FEATURES_20_HIGH 0xb7
#define XPREDICT_FEATURES_WIDTH_FEATURES_20     32
#define XPREDICT_FEATURES_DEPTH_FEATURES_20     2
#define XPREDICT_FEATURES_ADDR_FEATURES_21_BASE 0xb8
#define XPREDICT_FEATURES_ADDR_FEATURES_21_HIGH 0xbf
#define XPREDICT_FEATURES_WIDTH_FEATURES_21     32
#define XPREDICT_FEATURES_DEPTH_FEATURES_21     2
#define XPREDICT_FEATURES_ADDR_FEATURES_22_BASE 0xc0
#define XPREDICT_FEATURES_ADDR_FEATURES_22_HIGH 0xc7
#define XPREDICT_FEATURES_WIDTH_FEATURES_22     32
#define XPREDICT_FEATURES_DEPTH_FEATURES_22     2
#define XPREDICT_FEATURES_ADDR_FEATURES_23_BASE 0xc8
#define XPREDICT_FEATURES_ADDR_FEATURES_23_HIGH 0xcf
#define XPREDICT_FEATURES_WIDTH_FEATURES_23     32
#define XPREDICT_FEATURES_DEPTH_FEATURES_23     2
#define XPREDICT_FEATURES_ADDR_FEATURES_24_BASE 0xd0
#define XPREDICT_FEATURES_ADDR_FEATURES_24_HIGH 0xd7
#define XPREDICT_FEATURES_WIDTH_FEATURES_24     32
#define XPREDICT_FEATURES_DEPTH_FEATURES_24     2

// next_node_right_index
// 0x040 ~
// 0x07f : Memory 'next_node_right_index_0' (64 * 8b)
//         Word n : bit [ 7: 0] - next_node_right_index_0[4n]
//                  bit [15: 8] - next_node_right_index_0[4n+1]
//                  bit [23:16] - next_node_right_index_0[4n+2]
//                  bit [31:24] - next_node_right_index_0[4n+3]
// 0x080 ~
// 0x0bf : Memory 'next_node_right_index_1' (64 * 8b)
//         Word n : bit [ 7: 0] - next_node_right_index_1[4n]
//                  bit [15: 8] - next_node_right_index_1[4n+1]
//                  bit [23:16] - next_node_right_index_1[4n+2]
//                  bit [31:24] - next_node_right_index_1[4n+3]
// 0x0c0 ~
// 0x0ff : Memory 'next_node_right_index_2' (64 * 8b)
//         Word n : bit [ 7: 0] - next_node_right_index_2[4n]
//                  bit [15: 8] - next_node_right_index_2[4n+1]
//                  bit [23:16] - next_node_right_index_2[4n+2]
//                  bit [31:24] - next_node_right_index_2[4n+3]
// 0x100 ~
// 0x13f : Memory 'next_node_right_index_3' (64 * 8b)
//         Word n : bit [ 7: 0] - next_node_right_index_3[4n]
//                  bit [15: 8] - next_node_right_index_3[4n+1]
//                  bit [23:16] - next_node_right_index_3[4n+2]
//                  bit [31:24] - next_node_right_index_3[4n+3]
// 0x140 ~
// 0x17f : Memory 'next_node_right_index_4' (64 * 8b)
//         Word n : bit [ 7: 0] - next_node_right_index_4[4n]
//                  bit [15: 8] - next_node_right_index_4[4n+1]
//                  bit [23:16] - next_node_right_index_4[4n+2]
//                  bit [31:24] - next_node_right_index_4[4n+3]
// 0x180 ~
// 0x1bf : Memory 'next_node_right_index_5' (64 * 8b)
//         Word n : bit [ 7: 0] - next_node_right_index_5[4n]
//                  bit [15: 8] - next_node_right_index_5[4n+1]
//                  bit [23:16] - next_node_right_index_5[4n+2]
//                  bit [31:24] - next_node_right_index_5[4n+3]
// 0x1c0 ~
// 0x1ff : Memory 'next_node_right_index_6' (64 * 8b)
//         Word n : bit [ 7: 0] - next_node_right_index_6[4n]
//                  bit [15: 8] - next_node_right_index_6[4n+1]
//                  bit [23:16] - next_node_right_index_6[4n+2]
//                  bit [31:24] - next_node_right_index_6[4n+3]
// 0x200 ~
// 0x23f : Memory 'next_node_right_index_7' (64 * 8b)
//         Word n : bit [ 7: 0] - next_node_right_index_7[4n]
//                  bit [15: 8] - next_node_right_index_7[4n+1]
//                  bit [23:16] - next_node_right_index_7[4n+2]
//                  bit [31:24] - next_node_right_index_7[4n+3]
// 0x240 ~
// 0x27f : Memory 'next_node_right_index_8' (64 * 8b)
//         Word n : bit [ 7: 0] - next_node_right_index_8[4n]
//                  bit [15: 8] - next_node_right_index_8[4n+1]
//                  bit [23:16] - next_node_right_index_8[4n+2]
//                  bit [31:24] - next_node_right_index_8[4n+3]
// 0x280 ~
// 0x2bf : Memory 'next_node_right_index_9' (64 * 8b)
//         Word n : bit [ 7: 0] - next_node_right_index_9[4n]
//                  bit [15: 8] - next_node_right_index_9[4n+1]
//                  bit [23:16] - next_node_right_index_9[4n+2]
//                  bit [31:24] - next_node_right_index_9[4n+3]
// (SC = Self Clear, COR = Clear on Read, TOW = Toggle on Write, COH = Clear on Handshake)

#define XPREDICT_NEXT_NODE_RIGHT_INDEX_ADDR_NEXT_NODE_RIGHT_INDEX_0_BASE 0x040
#define XPREDICT_NEXT_NODE_RIGHT_INDEX_ADDR_NEXT_NODE_RIGHT_INDEX_0_HIGH 0x07f
#define XPREDICT_NEXT_NODE_RIGHT_INDEX_WIDTH_NEXT_NODE_RIGHT_INDEX_0     8
#define XPREDICT_NEXT_NODE_RIGHT_INDEX_DEPTH_NEXT_NODE_RIGHT_INDEX_0     64
#define XPREDICT_NEXT_NODE_RIGHT_INDEX_ADDR_NEXT_NODE_RIGHT_INDEX_1_BASE 0x080
#define XPREDICT_NEXT_NODE_RIGHT_INDEX_ADDR_NEXT_NODE_RIGHT_INDEX_1_HIGH 0x0bf
#define XPREDICT_NEXT_NODE_RIGHT_INDEX_WIDTH_NEXT_NODE_RIGHT_INDEX_1     8
#define XPREDICT_NEXT_NODE_RIGHT_INDEX_DEPTH_NEXT_NODE_RIGHT_INDEX_1     64
#define XPREDICT_NEXT_NODE_RIGHT_INDEX_ADDR_NEXT_NODE_RIGHT_INDEX_2_BASE 0x0c0
#define XPREDICT_NEXT_NODE_RIGHT_INDEX_ADDR_NEXT_NODE_RIGHT_INDEX_2_HIGH 0x0ff
#define XPREDICT_NEXT_NODE_RIGHT_INDEX_WIDTH_NEXT_NODE_RIGHT_INDEX_2     8
#define XPREDICT_NEXT_NODE_RIGHT_INDEX_DEPTH_NEXT_NODE_RIGHT_INDEX_2     64
#define XPREDICT_NEXT_NODE_RIGHT_INDEX_ADDR_NEXT_NODE_RIGHT_INDEX_3_BASE 0x100
#define XPREDICT_NEXT_NODE_RIGHT_INDEX_ADDR_NEXT_NODE_RIGHT_INDEX_3_HIGH 0x13f
#define XPREDICT_NEXT_NODE_RIGHT_INDEX_WIDTH_NEXT_NODE_RIGHT_INDEX_3     8
#define XPREDICT_NEXT_NODE_RIGHT_INDEX_DEPTH_NEXT_NODE_RIGHT_INDEX_3     64
#define XPREDICT_NEXT_NODE_RIGHT_INDEX_ADDR_NEXT_NODE_RIGHT_INDEX_4_BASE 0x140
#define XPREDICT_NEXT_NODE_RIGHT_INDEX_ADDR_NEXT_NODE_RIGHT_INDEX_4_HIGH 0x17f
#define XPREDICT_NEXT_NODE_RIGHT_INDEX_WIDTH_NEXT_NODE_RIGHT_INDEX_4     8
#define XPREDICT_NEXT_NODE_RIGHT_INDEX_DEPTH_NEXT_NODE_RIGHT_INDEX_4     64
#define XPREDICT_NEXT_NODE_RIGHT_INDEX_ADDR_NEXT_NODE_RIGHT_INDEX_5_BASE 0x180
#define XPREDICT_NEXT_NODE_RIGHT_INDEX_ADDR_NEXT_NODE_RIGHT_INDEX_5_HIGH 0x1bf
#define XPREDICT_NEXT_NODE_RIGHT_INDEX_WIDTH_NEXT_NODE_RIGHT_INDEX_5     8
#define XPREDICT_NEXT_NODE_RIGHT_INDEX_DEPTH_NEXT_NODE_RIGHT_INDEX_5     64
#define XPREDICT_NEXT_NODE_RIGHT_INDEX_ADDR_NEXT_NODE_RIGHT_INDEX_6_BASE 0x1c0
#define XPREDICT_NEXT_NODE_RIGHT_INDEX_ADDR_NEXT_NODE_RIGHT_INDEX_6_HIGH 0x1ff
#define XPREDICT_NEXT_NODE_RIGHT_INDEX_WIDTH_NEXT_NODE_RIGHT_INDEX_6     8
#define XPREDICT_NEXT_NODE_RIGHT_INDEX_DEPTH_NEXT_NODE_RIGHT_INDEX_6     64
#define XPREDICT_NEXT_NODE_RIGHT_INDEX_ADDR_NEXT_NODE_RIGHT_INDEX_7_BASE 0x200
#define XPREDICT_NEXT_NODE_RIGHT_INDEX_ADDR_NEXT_NODE_RIGHT_INDEX_7_HIGH 0x23f
#define XPREDICT_NEXT_NODE_RIGHT_INDEX_WIDTH_NEXT_NODE_RIGHT_INDEX_7     8
#define XPREDICT_NEXT_NODE_RIGHT_INDEX_DEPTH_NEXT_NODE_RIGHT_INDEX_7     64
#define XPREDICT_NEXT_NODE_RIGHT_INDEX_ADDR_NEXT_NODE_RIGHT_INDEX_8_BASE 0x240
#define XPREDICT_NEXT_NODE_RIGHT_INDEX_ADDR_NEXT_NODE_RIGHT_INDEX_8_HIGH 0x27f
#define XPREDICT_NEXT_NODE_RIGHT_INDEX_WIDTH_NEXT_NODE_RIGHT_INDEX_8     8
#define XPREDICT_NEXT_NODE_RIGHT_INDEX_DEPTH_NEXT_NODE_RIGHT_INDEX_8     64
#define XPREDICT_NEXT_NODE_RIGHT_INDEX_ADDR_NEXT_NODE_RIGHT_INDEX_9_BASE 0x280
#define XPREDICT_NEXT_NODE_RIGHT_INDEX_ADDR_NEXT_NODE_RIGHT_INDEX_9_HIGH 0x2bf
#define XPREDICT_NEXT_NODE_RIGHT_INDEX_WIDTH_NEXT_NODE_RIGHT_INDEX_9     8
#define XPREDICT_NEXT_NODE_RIGHT_INDEX_DEPTH_NEXT_NODE_RIGHT_INDEX_9     64

// node_leaf_value
// 0x100 ~
// 0x1ff : Memory 'node_leaf_value_0' (64 * 32b)
//         Word n : bit [31:0] - node_leaf_value_0[n]
// 0x200 ~
// 0x2ff : Memory 'node_leaf_value_1' (64 * 32b)
//         Word n : bit [31:0] - node_leaf_value_1[n]
// 0x300 ~
// 0x3ff : Memory 'node_leaf_value_2' (64 * 32b)
//         Word n : bit [31:0] - node_leaf_value_2[n]
// 0x400 ~
// 0x4ff : Memory 'node_leaf_value_3' (64 * 32b)
//         Word n : bit [31:0] - node_leaf_value_3[n]
// 0x500 ~
// 0x5ff : Memory 'node_leaf_value_4' (64 * 32b)
//         Word n : bit [31:0] - node_leaf_value_4[n]
// 0x600 ~
// 0x6ff : Memory 'node_leaf_value_5' (64 * 32b)
//         Word n : bit [31:0] - node_leaf_value_5[n]
// 0x700 ~
// 0x7ff : Memory 'node_leaf_value_6' (64 * 32b)
//         Word n : bit [31:0] - node_leaf_value_6[n]
// 0x800 ~
// 0x8ff : Memory 'node_leaf_value_7' (64 * 32b)
//         Word n : bit [31:0] - node_leaf_value_7[n]
// 0x900 ~
// 0x9ff : Memory 'node_leaf_value_8' (64 * 32b)
//         Word n : bit [31:0] - node_leaf_value_8[n]
// 0xa00 ~
// 0xaff : Memory 'node_leaf_value_9' (64 * 32b)
//         Word n : bit [31:0] - node_leaf_value_9[n]
// (SC = Self Clear, COR = Clear on Read, TOW = Toggle on Write, COH = Clear on Handshake)

#define XPREDICT_NODE_LEAF_VALUE_ADDR_NODE_LEAF_VALUE_0_BASE 0x100
#define XPREDICT_NODE_LEAF_VALUE_ADDR_NODE_LEAF_VALUE_0_HIGH 0x1ff
#define XPREDICT_NODE_LEAF_VALUE_WIDTH_NODE_LEAF_VALUE_0     32
#define XPREDICT_NODE_LEAF_VALUE_DEPTH_NODE_LEAF_VALUE_0     64
#define XPREDICT_NODE_LEAF_VALUE_ADDR_NODE_LEAF_VALUE_1_BASE 0x200
#define XPREDICT_NODE_LEAF_VALUE_ADDR_NODE_LEAF_VALUE_1_HIGH 0x2ff
#define XPREDICT_NODE_LEAF_VALUE_WIDTH_NODE_LEAF_VALUE_1     32
#define XPREDICT_NODE_LEAF_VALUE_DEPTH_NODE_LEAF_VALUE_1     64
#define XPREDICT_NODE_LEAF_VALUE_ADDR_NODE_LEAF_VALUE_2_BASE 0x300
#define XPREDICT_NODE_LEAF_VALUE_ADDR_NODE_LEAF_VALUE_2_HIGH 0x3ff
#define XPREDICT_NODE_LEAF_VALUE_WIDTH_NODE_LEAF_VALUE_2     32
#define XPREDICT_NODE_LEAF_VALUE_DEPTH_NODE_LEAF_VALUE_2     64
#define XPREDICT_NODE_LEAF_VALUE_ADDR_NODE_LEAF_VALUE_3_BASE 0x400
#define XPREDICT_NODE_LEAF_VALUE_ADDR_NODE_LEAF_VALUE_3_HIGH 0x4ff
#define XPREDICT_NODE_LEAF_VALUE_WIDTH_NODE_LEAF_VALUE_3     32
#define XPREDICT_NODE_LEAF_VALUE_DEPTH_NODE_LEAF_VALUE_3     64
#define XPREDICT_NODE_LEAF_VALUE_ADDR_NODE_LEAF_VALUE_4_BASE 0x500
#define XPREDICT_NODE_LEAF_VALUE_ADDR_NODE_LEAF_VALUE_4_HIGH 0x5ff
#define XPREDICT_NODE_LEAF_VALUE_WIDTH_NODE_LEAF_VALUE_4     32
#define XPREDICT_NODE_LEAF_VALUE_DEPTH_NODE_LEAF_VALUE_4     64
#define XPREDICT_NODE_LEAF_VALUE_ADDR_NODE_LEAF_VALUE_5_BASE 0x600
#define XPREDICT_NODE_LEAF_VALUE_ADDR_NODE_LEAF_VALUE_5_HIGH 0x6ff
#define XPREDICT_NODE_LEAF_VALUE_WIDTH_NODE_LEAF_VALUE_5     32
#define XPREDICT_NODE_LEAF_VALUE_DEPTH_NODE_LEAF_VALUE_5     64
#define XPREDICT_NODE_LEAF_VALUE_ADDR_NODE_LEAF_VALUE_6_BASE 0x700
#define XPREDICT_NODE_LEAF_VALUE_ADDR_NODE_LEAF_VALUE_6_HIGH 0x7ff
#define XPREDICT_NODE_LEAF_VALUE_WIDTH_NODE_LEAF_VALUE_6     32
#define XPREDICT_NODE_LEAF_VALUE_DEPTH_NODE_LEAF_VALUE_6     64
#define XPREDICT_NODE_LEAF_VALUE_ADDR_NODE_LEAF_VALUE_7_BASE 0x800
#define XPREDICT_NODE_LEAF_VALUE_ADDR_NODE_LEAF_VALUE_7_HIGH 0x8ff
#define XPREDICT_NODE_LEAF_VALUE_WIDTH_NODE_LEAF_VALUE_7     32
#define XPREDICT_NODE_LEAF_VALUE_DEPTH_NODE_LEAF_VALUE_7     64
#define XPREDICT_NODE_LEAF_VALUE_ADDR_NODE_LEAF_VALUE_8_BASE 0x900
#define XPREDICT_NODE_LEAF_VALUE_ADDR_NODE_LEAF_VALUE_8_HIGH 0x9ff
#define XPREDICT_NODE_LEAF_VALUE_WIDTH_NODE_LEAF_VALUE_8     32
#define XPREDICT_NODE_LEAF_VALUE_DEPTH_NODE_LEAF_VALUE_8     64
#define XPREDICT_NODE_LEAF_VALUE_ADDR_NODE_LEAF_VALUE_9_BASE 0xa00
#define XPREDICT_NODE_LEAF_VALUE_ADDR_NODE_LEAF_VALUE_9_HIGH 0xaff
#define XPREDICT_NODE_LEAF_VALUE_WIDTH_NODE_LEAF_VALUE_9     32
#define XPREDICT_NODE_LEAF_VALUE_DEPTH_NODE_LEAF_VALUE_9     64

// prediction
// 0x00 : reserved
// 0x04 : reserved
// 0x08 : reserved
// 0x0c : reserved
// 0x10 : Data signal of prediction
//        bit 7~0 - prediction[7:0] (Read)
//        others  - reserved
// 0x14 : Control signal of prediction
//        bit 0  - prediction_ap_vld (Read/COR)
//        others - reserved
// (SC = Self Clear, COR = Clear on Read, TOW = Toggle on Write, COH = Clear on Handshake)

#define XPREDICT_PREDICTION_ADDR_PREDICTION_DATA 0x10
#define XPREDICT_PREDICTION_BITS_PREDICTION_DATA 8
#define XPREDICT_PREDICTION_ADDR_PREDICTION_CTRL 0x14

// results
// 0x0 : Control signals
//       bit 0  - ap_start (Read/Write/COH)
//       bit 1  - ap_done (Read/COR)
//       bit 2  - ap_idle (Read)
//       bit 3  - ap_ready (Read/COR)
//       bit 7  - auto_restart (Read/Write)
//       bit 9  - interrupt (Read)
//       others - reserved
// 0x4 : Global Interrupt Enable Register
//       bit 0  - Global Interrupt Enable (Read/Write)
//       others - reserved
// 0x8 : IP Interrupt Enable Register (Read/Write)
//       bit 0 - enable ap_done interrupt (Read/Write)
//       bit 1 - enable ap_ready interrupt (Read/Write)
//       others - reserved
// 0xc : IP Interrupt Status Register (Read/TOW)
//       bit 0 - ap_done (Read/TOW)
//       bit 1 - ap_ready (Read/TOW)
//       others - reserved
// (SC = Self Clear, COR = Clear on Read, TOW = Toggle on Write, COH = Clear on Handshake)

#define XPREDICT_RESULTS_ADDR_AP_CTRL 0x0
#define XPREDICT_RESULTS_ADDR_GIE     0x4
#define XPREDICT_RESULTS_ADDR_IER     0x8
#define XPREDICT_RESULTS_ADDR_ISR     0xc

