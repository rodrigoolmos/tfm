// ==============================================================
// Vitis HLS - High-Level Synthesis from C, C++ and OpenCL v2023.1.1 (64-bit)
// Tool Version Limit: 2023.06
// Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
// Copyright 2022-2023 Advanced Micro Devices, Inc. All Rights Reserved.
// 
// ==============================================================
// compact_data
// 0x400 ~
// 0x7ff : Memory 'compact_data' (640 * 8b)
//         Word n : bit [ 7: 0] - compact_data[4n]
//                  bit [15: 8] - compact_data[4n+1]
//                  bit [23:16] - compact_data[4n+2]
//                  bit [31:24] - compact_data[4n+3]
// (SC = Self Clear, COR = Clear on Read, TOW = Toggle on Write, COH = Clear on Handshake)

#define XPREDICT_COMPACT_DATA_ADDR_COMPACT_DATA_BASE 0x400
#define XPREDICT_COMPACT_DATA_ADDR_COMPACT_DATA_HIGH 0x7ff
#define XPREDICT_COMPACT_DATA_WIDTH_COMPACT_DATA     8
#define XPREDICT_COMPACT_DATA_DEPTH_COMPACT_DATA     640

// features
// 0x100 ~
// 0x1ff : Memory 'features' (50 * 32b)
//         Word n : bit [31:0] - features[n]
// (SC = Self Clear, COR = Clear on Read, TOW = Toggle on Write, COH = Clear on Handshake)

#define XPREDICT_FEATURES_ADDR_FEATURES_BASE 0x100
#define XPREDICT_FEATURES_ADDR_FEATURES_HIGH 0x1ff
#define XPREDICT_FEATURES_WIDTH_FEATURES     32
#define XPREDICT_FEATURES_DEPTH_FEATURES     50

// next_node_right_index
// 0x400 ~
// 0x7ff : Memory 'next_node_right_index' (640 * 8b)
//         Word n : bit [ 7: 0] - next_node_right_index[4n]
//                  bit [15: 8] - next_node_right_index[4n+1]
//                  bit [23:16] - next_node_right_index[4n+2]
//                  bit [31:24] - next_node_right_index[4n+3]
// (SC = Self Clear, COR = Clear on Read, TOW = Toggle on Write, COH = Clear on Handshake)

#define XPREDICT_NEXT_NODE_RIGHT_INDEX_ADDR_NEXT_NODE_RIGHT_INDEX_BASE 0x400
#define XPREDICT_NEXT_NODE_RIGHT_INDEX_ADDR_NEXT_NODE_RIGHT_INDEX_HIGH 0x7ff
#define XPREDICT_NEXT_NODE_RIGHT_INDEX_WIDTH_NEXT_NODE_RIGHT_INDEX     8
#define XPREDICT_NEXT_NODE_RIGHT_INDEX_DEPTH_NEXT_NODE_RIGHT_INDEX     640

// node_leaf_value
// 0x1000 ~
// 0x1fff : Memory 'node_leaf_value' (640 * 32b)
//          Word n : bit [31:0] - node_leaf_value[n]
// (SC = Self Clear, COR = Clear on Read, TOW = Toggle on Write, COH = Clear on Handshake)

#define XPREDICT_NODE_LEAF_VALUE_ADDR_NODE_LEAF_VALUE_BASE 0x1000
#define XPREDICT_NODE_LEAF_VALUE_ADDR_NODE_LEAF_VALUE_HIGH 0x1fff
#define XPREDICT_NODE_LEAF_VALUE_WIDTH_NODE_LEAF_VALUE     32
#define XPREDICT_NODE_LEAF_VALUE_DEPTH_NODE_LEAF_VALUE     640

// prediction
// 0x00 : reserved
// 0x04 : reserved
// 0x08 : reserved
// 0x0c : reserved
// 0x10 : Data signal of prediction
//        bit 7~0 - prediction[7:0] (Read)
//        others  - reserved
// 0x14 : Control signal of prediction
//        bit 0  - prediction_ap_vld (Read/COR)
//        others - reserved
// (SC = Self Clear, COR = Clear on Read, TOW = Toggle on Write, COH = Clear on Handshake)

#define XPREDICT_PREDICTION_ADDR_PREDICTION_DATA 0x10
#define XPREDICT_PREDICTION_BITS_PREDICTION_DATA 8
#define XPREDICT_PREDICTION_ADDR_PREDICTION_CTRL 0x14

// results
// 0x0 : Control signals
//       bit 0  - ap_start (Read/Write/COH)
//       bit 1  - ap_done (Read/COR)
//       bit 2  - ap_idle (Read)
//       bit 3  - ap_ready (Read/COR)
//       bit 7  - auto_restart (Read/Write)
//       bit 9  - interrupt (Read)
//       others - reserved
// 0x4 : Global Interrupt Enable Register
//       bit 0  - Global Interrupt Enable (Read/Write)
//       others - reserved
// 0x8 : IP Interrupt Enable Register (Read/Write)
//       bit 0 - enable ap_done interrupt (Read/Write)
//       bit 1 - enable ap_ready interrupt (Read/Write)
//       others - reserved
// 0xc : IP Interrupt Status Register (Read/TOW)
//       bit 0 - ap_done (Read/TOW)
//       bit 1 - ap_ready (Read/TOW)
//       others - reserved
// (SC = Self Clear, COR = Clear on Read, TOW = Toggle on Write, COH = Clear on Handshake)

#define XPREDICT_RESULTS_ADDR_AP_CTRL 0x0
#define XPREDICT_RESULTS_ADDR_GIE     0x4
#define XPREDICT_RESULTS_ADDR_IER     0x8
#define XPREDICT_RESULTS_ADDR_ISR     0xc

