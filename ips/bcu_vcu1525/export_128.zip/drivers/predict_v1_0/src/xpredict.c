// ==============================================================
// Vitis HLS - High-Level Synthesis from C, C++ and OpenCL v2023.1.1 (64-bit)
// Tool Version Limit: 2023.06
// Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
// Copyright 2022-2023 Advanced Micro Devices, Inc. All Rights Reserved.
// 
// ==============================================================
/***************************** Include Files *********************************/
#include "xpredict.h"

/************************** Function Implementation *************************/
#ifndef __linux__
int XPredict_CfgInitialize(XPredict *InstancePtr, XPredict_Config *ConfigPtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(ConfigPtr != NULL);

    InstancePtr->Control_BaseAddress = ConfigPtr->Control_BaseAddress;
    InstancePtr->Tree_BaseAddress = ConfigPtr->Tree_BaseAddress;
    InstancePtr->IsReady = XIL_COMPONENT_IS_READY;

    return XST_SUCCESS;
}
#endif

void XPredict_Start(XPredict *InstancePtr) {
    u32 Data;

    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XPredict_ReadReg(InstancePtr->Control_BaseAddress, XPREDICT_CONTROL_ADDR_AP_CTRL) & 0x80;
    XPredict_WriteReg(InstancePtr->Control_BaseAddress, XPREDICT_CONTROL_ADDR_AP_CTRL, Data | 0x01);
}

u32 XPredict_IsDone(XPredict *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XPredict_ReadReg(InstancePtr->Control_BaseAddress, XPREDICT_CONTROL_ADDR_AP_CTRL);
    return (Data >> 1) & 0x1;
}

u32 XPredict_IsIdle(XPredict *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XPredict_ReadReg(InstancePtr->Control_BaseAddress, XPREDICT_CONTROL_ADDR_AP_CTRL);
    return (Data >> 2) & 0x1;
}

u32 XPredict_IsReady(XPredict *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XPredict_ReadReg(InstancePtr->Control_BaseAddress, XPREDICT_CONTROL_ADDR_AP_CTRL);
    // check ap_start to see if the pcore is ready for next input
    return !(Data & 0x1);
}

void XPredict_EnableAutoRestart(XPredict *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XPredict_WriteReg(InstancePtr->Control_BaseAddress, XPREDICT_CONTROL_ADDR_AP_CTRL, 0x80);
}

void XPredict_DisableAutoRestart(XPredict *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XPredict_WriteReg(InstancePtr->Control_BaseAddress, XPREDICT_CONTROL_ADDR_AP_CTRL, 0);
}

void XPredict_Set_features_burst_length(XPredict *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XPredict_WriteReg(InstancePtr->Control_BaseAddress, XPREDICT_CONTROL_ADDR_FEATURES_BURST_LENGTH_DATA, Data);
}

u32 XPredict_Get_features_burst_length(XPredict *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XPredict_ReadReg(InstancePtr->Control_BaseAddress, XPREDICT_CONTROL_ADDR_FEATURES_BURST_LENGTH_DATA);
    return Data;
}

void XPredict_Set_ping_pong(XPredict *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XPredict_WriteReg(InstancePtr->Control_BaseAddress, XPREDICT_CONTROL_ADDR_PING_PONG_DATA, Data);
}

u32 XPredict_Get_ping_pong(XPredict *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XPredict_ReadReg(InstancePtr->Control_BaseAddress, XPREDICT_CONTROL_ADDR_PING_PONG_DATA);
    return Data;
}

u32 XPredict_Get_tree_0_BaseAddress(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_0_BASE);
}

u32 XPredict_Get_tree_0_HighAddress(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_0_HIGH);
}

u32 XPredict_Get_tree_0_TotalBytes(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (XPREDICT_TREE_ADDR_TREE_0_HIGH - XPREDICT_TREE_ADDR_TREE_0_BASE + 1);
}

u32 XPredict_Get_tree_0_BitWidth(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XPREDICT_TREE_WIDTH_TREE_0;
}

u32 XPredict_Get_tree_0_Depth(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XPREDICT_TREE_DEPTH_TREE_0;
}

u32 XPredict_Write_tree_0_Words(XPredict *InstancePtr, int offset, word_type *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length)*4 > (XPREDICT_TREE_ADDR_TREE_0_HIGH - XPREDICT_TREE_ADDR_TREE_0_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(int *)(InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_0_BASE + (offset + i)*4) = *(data + i);
    }
    return length;
}

u32 XPredict_Read_tree_0_Words(XPredict *InstancePtr, int offset, word_type *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length)*4 > (XPREDICT_TREE_ADDR_TREE_0_HIGH - XPREDICT_TREE_ADDR_TREE_0_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(data + i) = *(int *)(InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_0_BASE + (offset + i)*4);
    }
    return length;
}

u32 XPredict_Write_tree_0_Bytes(XPredict *InstancePtr, int offset, char *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length) > (XPREDICT_TREE_ADDR_TREE_0_HIGH - XPREDICT_TREE_ADDR_TREE_0_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(char *)(InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_0_BASE + offset + i) = *(data + i);
    }
    return length;
}

u32 XPredict_Read_tree_0_Bytes(XPredict *InstancePtr, int offset, char *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length) > (XPREDICT_TREE_ADDR_TREE_0_HIGH - XPREDICT_TREE_ADDR_TREE_0_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(data + i) = *(char *)(InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_0_BASE + offset + i);
    }
    return length;
}

u32 XPredict_Get_tree_1_BaseAddress(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_1_BASE);
}

u32 XPredict_Get_tree_1_HighAddress(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_1_HIGH);
}

u32 XPredict_Get_tree_1_TotalBytes(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (XPREDICT_TREE_ADDR_TREE_1_HIGH - XPREDICT_TREE_ADDR_TREE_1_BASE + 1);
}

u32 XPredict_Get_tree_1_BitWidth(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XPREDICT_TREE_WIDTH_TREE_1;
}

u32 XPredict_Get_tree_1_Depth(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XPREDICT_TREE_DEPTH_TREE_1;
}

u32 XPredict_Write_tree_1_Words(XPredict *InstancePtr, int offset, word_type *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length)*4 > (XPREDICT_TREE_ADDR_TREE_1_HIGH - XPREDICT_TREE_ADDR_TREE_1_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(int *)(InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_1_BASE + (offset + i)*4) = *(data + i);
    }
    return length;
}

u32 XPredict_Read_tree_1_Words(XPredict *InstancePtr, int offset, word_type *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length)*4 > (XPREDICT_TREE_ADDR_TREE_1_HIGH - XPREDICT_TREE_ADDR_TREE_1_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(data + i) = *(int *)(InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_1_BASE + (offset + i)*4);
    }
    return length;
}

u32 XPredict_Write_tree_1_Bytes(XPredict *InstancePtr, int offset, char *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length) > (XPREDICT_TREE_ADDR_TREE_1_HIGH - XPREDICT_TREE_ADDR_TREE_1_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(char *)(InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_1_BASE + offset + i) = *(data + i);
    }
    return length;
}

u32 XPredict_Read_tree_1_Bytes(XPredict *InstancePtr, int offset, char *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length) > (XPREDICT_TREE_ADDR_TREE_1_HIGH - XPREDICT_TREE_ADDR_TREE_1_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(data + i) = *(char *)(InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_1_BASE + offset + i);
    }
    return length;
}

u32 XPredict_Get_tree_2_BaseAddress(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_2_BASE);
}

u32 XPredict_Get_tree_2_HighAddress(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_2_HIGH);
}

u32 XPredict_Get_tree_2_TotalBytes(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (XPREDICT_TREE_ADDR_TREE_2_HIGH - XPREDICT_TREE_ADDR_TREE_2_BASE + 1);
}

u32 XPredict_Get_tree_2_BitWidth(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XPREDICT_TREE_WIDTH_TREE_2;
}

u32 XPredict_Get_tree_2_Depth(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XPREDICT_TREE_DEPTH_TREE_2;
}

u32 XPredict_Write_tree_2_Words(XPredict *InstancePtr, int offset, word_type *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length)*4 > (XPREDICT_TREE_ADDR_TREE_2_HIGH - XPREDICT_TREE_ADDR_TREE_2_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(int *)(InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_2_BASE + (offset + i)*4) = *(data + i);
    }
    return length;
}

u32 XPredict_Read_tree_2_Words(XPredict *InstancePtr, int offset, word_type *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length)*4 > (XPREDICT_TREE_ADDR_TREE_2_HIGH - XPREDICT_TREE_ADDR_TREE_2_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(data + i) = *(int *)(InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_2_BASE + (offset + i)*4);
    }
    return length;
}

u32 XPredict_Write_tree_2_Bytes(XPredict *InstancePtr, int offset, char *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length) > (XPREDICT_TREE_ADDR_TREE_2_HIGH - XPREDICT_TREE_ADDR_TREE_2_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(char *)(InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_2_BASE + offset + i) = *(data + i);
    }
    return length;
}

u32 XPredict_Read_tree_2_Bytes(XPredict *InstancePtr, int offset, char *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length) > (XPREDICT_TREE_ADDR_TREE_2_HIGH - XPREDICT_TREE_ADDR_TREE_2_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(data + i) = *(char *)(InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_2_BASE + offset + i);
    }
    return length;
}

u32 XPredict_Get_tree_3_BaseAddress(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_3_BASE);
}

u32 XPredict_Get_tree_3_HighAddress(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_3_HIGH);
}

u32 XPredict_Get_tree_3_TotalBytes(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (XPREDICT_TREE_ADDR_TREE_3_HIGH - XPREDICT_TREE_ADDR_TREE_3_BASE + 1);
}

u32 XPredict_Get_tree_3_BitWidth(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XPREDICT_TREE_WIDTH_TREE_3;
}

u32 XPredict_Get_tree_3_Depth(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XPREDICT_TREE_DEPTH_TREE_3;
}

u32 XPredict_Write_tree_3_Words(XPredict *InstancePtr, int offset, word_type *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length)*4 > (XPREDICT_TREE_ADDR_TREE_3_HIGH - XPREDICT_TREE_ADDR_TREE_3_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(int *)(InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_3_BASE + (offset + i)*4) = *(data + i);
    }
    return length;
}

u32 XPredict_Read_tree_3_Words(XPredict *InstancePtr, int offset, word_type *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length)*4 > (XPREDICT_TREE_ADDR_TREE_3_HIGH - XPREDICT_TREE_ADDR_TREE_3_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(data + i) = *(int *)(InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_3_BASE + (offset + i)*4);
    }
    return length;
}

u32 XPredict_Write_tree_3_Bytes(XPredict *InstancePtr, int offset, char *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length) > (XPREDICT_TREE_ADDR_TREE_3_HIGH - XPREDICT_TREE_ADDR_TREE_3_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(char *)(InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_3_BASE + offset + i) = *(data + i);
    }
    return length;
}

u32 XPredict_Read_tree_3_Bytes(XPredict *InstancePtr, int offset, char *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length) > (XPREDICT_TREE_ADDR_TREE_3_HIGH - XPREDICT_TREE_ADDR_TREE_3_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(data + i) = *(char *)(InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_3_BASE + offset + i);
    }
    return length;
}

u32 XPredict_Get_tree_4_BaseAddress(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_4_BASE);
}

u32 XPredict_Get_tree_4_HighAddress(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_4_HIGH);
}

u32 XPredict_Get_tree_4_TotalBytes(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (XPREDICT_TREE_ADDR_TREE_4_HIGH - XPREDICT_TREE_ADDR_TREE_4_BASE + 1);
}

u32 XPredict_Get_tree_4_BitWidth(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XPREDICT_TREE_WIDTH_TREE_4;
}

u32 XPredict_Get_tree_4_Depth(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XPREDICT_TREE_DEPTH_TREE_4;
}

u32 XPredict_Write_tree_4_Words(XPredict *InstancePtr, int offset, word_type *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length)*4 > (XPREDICT_TREE_ADDR_TREE_4_HIGH - XPREDICT_TREE_ADDR_TREE_4_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(int *)(InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_4_BASE + (offset + i)*4) = *(data + i);
    }
    return length;
}

u32 XPredict_Read_tree_4_Words(XPredict *InstancePtr, int offset, word_type *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length)*4 > (XPREDICT_TREE_ADDR_TREE_4_HIGH - XPREDICT_TREE_ADDR_TREE_4_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(data + i) = *(int *)(InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_4_BASE + (offset + i)*4);
    }
    return length;
}

u32 XPredict_Write_tree_4_Bytes(XPredict *InstancePtr, int offset, char *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length) > (XPREDICT_TREE_ADDR_TREE_4_HIGH - XPREDICT_TREE_ADDR_TREE_4_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(char *)(InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_4_BASE + offset + i) = *(data + i);
    }
    return length;
}

u32 XPredict_Read_tree_4_Bytes(XPredict *InstancePtr, int offset, char *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length) > (XPREDICT_TREE_ADDR_TREE_4_HIGH - XPREDICT_TREE_ADDR_TREE_4_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(data + i) = *(char *)(InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_4_BASE + offset + i);
    }
    return length;
}

u32 XPredict_Get_tree_5_BaseAddress(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_5_BASE);
}

u32 XPredict_Get_tree_5_HighAddress(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_5_HIGH);
}

u32 XPredict_Get_tree_5_TotalBytes(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (XPREDICT_TREE_ADDR_TREE_5_HIGH - XPREDICT_TREE_ADDR_TREE_5_BASE + 1);
}

u32 XPredict_Get_tree_5_BitWidth(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XPREDICT_TREE_WIDTH_TREE_5;
}

u32 XPredict_Get_tree_5_Depth(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XPREDICT_TREE_DEPTH_TREE_5;
}

u32 XPredict_Write_tree_5_Words(XPredict *InstancePtr, int offset, word_type *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length)*4 > (XPREDICT_TREE_ADDR_TREE_5_HIGH - XPREDICT_TREE_ADDR_TREE_5_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(int *)(InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_5_BASE + (offset + i)*4) = *(data + i);
    }
    return length;
}

u32 XPredict_Read_tree_5_Words(XPredict *InstancePtr, int offset, word_type *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length)*4 > (XPREDICT_TREE_ADDR_TREE_5_HIGH - XPREDICT_TREE_ADDR_TREE_5_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(data + i) = *(int *)(InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_5_BASE + (offset + i)*4);
    }
    return length;
}

u32 XPredict_Write_tree_5_Bytes(XPredict *InstancePtr, int offset, char *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length) > (XPREDICT_TREE_ADDR_TREE_5_HIGH - XPREDICT_TREE_ADDR_TREE_5_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(char *)(InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_5_BASE + offset + i) = *(data + i);
    }
    return length;
}

u32 XPredict_Read_tree_5_Bytes(XPredict *InstancePtr, int offset, char *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length) > (XPREDICT_TREE_ADDR_TREE_5_HIGH - XPREDICT_TREE_ADDR_TREE_5_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(data + i) = *(char *)(InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_5_BASE + offset + i);
    }
    return length;
}

u32 XPredict_Get_tree_6_BaseAddress(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_6_BASE);
}

u32 XPredict_Get_tree_6_HighAddress(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_6_HIGH);
}

u32 XPredict_Get_tree_6_TotalBytes(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (XPREDICT_TREE_ADDR_TREE_6_HIGH - XPREDICT_TREE_ADDR_TREE_6_BASE + 1);
}

u32 XPredict_Get_tree_6_BitWidth(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XPREDICT_TREE_WIDTH_TREE_6;
}

u32 XPredict_Get_tree_6_Depth(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XPREDICT_TREE_DEPTH_TREE_6;
}

u32 XPredict_Write_tree_6_Words(XPredict *InstancePtr, int offset, word_type *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length)*4 > (XPREDICT_TREE_ADDR_TREE_6_HIGH - XPREDICT_TREE_ADDR_TREE_6_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(int *)(InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_6_BASE + (offset + i)*4) = *(data + i);
    }
    return length;
}

u32 XPredict_Read_tree_6_Words(XPredict *InstancePtr, int offset, word_type *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length)*4 > (XPREDICT_TREE_ADDR_TREE_6_HIGH - XPREDICT_TREE_ADDR_TREE_6_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(data + i) = *(int *)(InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_6_BASE + (offset + i)*4);
    }
    return length;
}

u32 XPredict_Write_tree_6_Bytes(XPredict *InstancePtr, int offset, char *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length) > (XPREDICT_TREE_ADDR_TREE_6_HIGH - XPREDICT_TREE_ADDR_TREE_6_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(char *)(InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_6_BASE + offset + i) = *(data + i);
    }
    return length;
}

u32 XPredict_Read_tree_6_Bytes(XPredict *InstancePtr, int offset, char *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length) > (XPREDICT_TREE_ADDR_TREE_6_HIGH - XPREDICT_TREE_ADDR_TREE_6_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(data + i) = *(char *)(InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_6_BASE + offset + i);
    }
    return length;
}

u32 XPredict_Get_tree_7_BaseAddress(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_7_BASE);
}

u32 XPredict_Get_tree_7_HighAddress(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_7_HIGH);
}

u32 XPredict_Get_tree_7_TotalBytes(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (XPREDICT_TREE_ADDR_TREE_7_HIGH - XPREDICT_TREE_ADDR_TREE_7_BASE + 1);
}

u32 XPredict_Get_tree_7_BitWidth(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XPREDICT_TREE_WIDTH_TREE_7;
}

u32 XPredict_Get_tree_7_Depth(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XPREDICT_TREE_DEPTH_TREE_7;
}

u32 XPredict_Write_tree_7_Words(XPredict *InstancePtr, int offset, word_type *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length)*4 > (XPREDICT_TREE_ADDR_TREE_7_HIGH - XPREDICT_TREE_ADDR_TREE_7_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(int *)(InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_7_BASE + (offset + i)*4) = *(data + i);
    }
    return length;
}

u32 XPredict_Read_tree_7_Words(XPredict *InstancePtr, int offset, word_type *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length)*4 > (XPREDICT_TREE_ADDR_TREE_7_HIGH - XPREDICT_TREE_ADDR_TREE_7_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(data + i) = *(int *)(InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_7_BASE + (offset + i)*4);
    }
    return length;
}

u32 XPredict_Write_tree_7_Bytes(XPredict *InstancePtr, int offset, char *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length) > (XPREDICT_TREE_ADDR_TREE_7_HIGH - XPREDICT_TREE_ADDR_TREE_7_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(char *)(InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_7_BASE + offset + i) = *(data + i);
    }
    return length;
}

u32 XPredict_Read_tree_7_Bytes(XPredict *InstancePtr, int offset, char *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length) > (XPREDICT_TREE_ADDR_TREE_7_HIGH - XPREDICT_TREE_ADDR_TREE_7_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(data + i) = *(char *)(InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_7_BASE + offset + i);
    }
    return length;
}

u32 XPredict_Get_tree_8_BaseAddress(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_8_BASE);
}

u32 XPredict_Get_tree_8_HighAddress(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_8_HIGH);
}

u32 XPredict_Get_tree_8_TotalBytes(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (XPREDICT_TREE_ADDR_TREE_8_HIGH - XPREDICT_TREE_ADDR_TREE_8_BASE + 1);
}

u32 XPredict_Get_tree_8_BitWidth(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XPREDICT_TREE_WIDTH_TREE_8;
}

u32 XPredict_Get_tree_8_Depth(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XPREDICT_TREE_DEPTH_TREE_8;
}

u32 XPredict_Write_tree_8_Words(XPredict *InstancePtr, int offset, word_type *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length)*4 > (XPREDICT_TREE_ADDR_TREE_8_HIGH - XPREDICT_TREE_ADDR_TREE_8_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(int *)(InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_8_BASE + (offset + i)*4) = *(data + i);
    }
    return length;
}

u32 XPredict_Read_tree_8_Words(XPredict *InstancePtr, int offset, word_type *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length)*4 > (XPREDICT_TREE_ADDR_TREE_8_HIGH - XPREDICT_TREE_ADDR_TREE_8_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(data + i) = *(int *)(InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_8_BASE + (offset + i)*4);
    }
    return length;
}

u32 XPredict_Write_tree_8_Bytes(XPredict *InstancePtr, int offset, char *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length) > (XPREDICT_TREE_ADDR_TREE_8_HIGH - XPREDICT_TREE_ADDR_TREE_8_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(char *)(InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_8_BASE + offset + i) = *(data + i);
    }
    return length;
}

u32 XPredict_Read_tree_8_Bytes(XPredict *InstancePtr, int offset, char *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length) > (XPREDICT_TREE_ADDR_TREE_8_HIGH - XPREDICT_TREE_ADDR_TREE_8_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(data + i) = *(char *)(InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_8_BASE + offset + i);
    }
    return length;
}

u32 XPredict_Get_tree_9_BaseAddress(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_9_BASE);
}

u32 XPredict_Get_tree_9_HighAddress(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_9_HIGH);
}

u32 XPredict_Get_tree_9_TotalBytes(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (XPREDICT_TREE_ADDR_TREE_9_HIGH - XPREDICT_TREE_ADDR_TREE_9_BASE + 1);
}

u32 XPredict_Get_tree_9_BitWidth(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XPREDICT_TREE_WIDTH_TREE_9;
}

u32 XPredict_Get_tree_9_Depth(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XPREDICT_TREE_DEPTH_TREE_9;
}

u32 XPredict_Write_tree_9_Words(XPredict *InstancePtr, int offset, word_type *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length)*4 > (XPREDICT_TREE_ADDR_TREE_9_HIGH - XPREDICT_TREE_ADDR_TREE_9_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(int *)(InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_9_BASE + (offset + i)*4) = *(data + i);
    }
    return length;
}

u32 XPredict_Read_tree_9_Words(XPredict *InstancePtr, int offset, word_type *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length)*4 > (XPREDICT_TREE_ADDR_TREE_9_HIGH - XPREDICT_TREE_ADDR_TREE_9_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(data + i) = *(int *)(InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_9_BASE + (offset + i)*4);
    }
    return length;
}

u32 XPredict_Write_tree_9_Bytes(XPredict *InstancePtr, int offset, char *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length) > (XPREDICT_TREE_ADDR_TREE_9_HIGH - XPREDICT_TREE_ADDR_TREE_9_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(char *)(InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_9_BASE + offset + i) = *(data + i);
    }
    return length;
}

u32 XPredict_Read_tree_9_Bytes(XPredict *InstancePtr, int offset, char *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length) > (XPREDICT_TREE_ADDR_TREE_9_HIGH - XPREDICT_TREE_ADDR_TREE_9_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(data + i) = *(char *)(InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_9_BASE + offset + i);
    }
    return length;
}

u32 XPredict_Get_tree_10_BaseAddress(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_10_BASE);
}

u32 XPredict_Get_tree_10_HighAddress(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_10_HIGH);
}

u32 XPredict_Get_tree_10_TotalBytes(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (XPREDICT_TREE_ADDR_TREE_10_HIGH - XPREDICT_TREE_ADDR_TREE_10_BASE + 1);
}

u32 XPredict_Get_tree_10_BitWidth(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XPREDICT_TREE_WIDTH_TREE_10;
}

u32 XPredict_Get_tree_10_Depth(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XPREDICT_TREE_DEPTH_TREE_10;
}

u32 XPredict_Write_tree_10_Words(XPredict *InstancePtr, int offset, word_type *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length)*4 > (XPREDICT_TREE_ADDR_TREE_10_HIGH - XPREDICT_TREE_ADDR_TREE_10_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(int *)(InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_10_BASE + (offset + i)*4) = *(data + i);
    }
    return length;
}

u32 XPredict_Read_tree_10_Words(XPredict *InstancePtr, int offset, word_type *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length)*4 > (XPREDICT_TREE_ADDR_TREE_10_HIGH - XPREDICT_TREE_ADDR_TREE_10_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(data + i) = *(int *)(InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_10_BASE + (offset + i)*4);
    }
    return length;
}

u32 XPredict_Write_tree_10_Bytes(XPredict *InstancePtr, int offset, char *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length) > (XPREDICT_TREE_ADDR_TREE_10_HIGH - XPREDICT_TREE_ADDR_TREE_10_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(char *)(InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_10_BASE + offset + i) = *(data + i);
    }
    return length;
}

u32 XPredict_Read_tree_10_Bytes(XPredict *InstancePtr, int offset, char *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length) > (XPREDICT_TREE_ADDR_TREE_10_HIGH - XPREDICT_TREE_ADDR_TREE_10_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(data + i) = *(char *)(InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_10_BASE + offset + i);
    }
    return length;
}

u32 XPredict_Get_tree_11_BaseAddress(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_11_BASE);
}

u32 XPredict_Get_tree_11_HighAddress(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_11_HIGH);
}

u32 XPredict_Get_tree_11_TotalBytes(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (XPREDICT_TREE_ADDR_TREE_11_HIGH - XPREDICT_TREE_ADDR_TREE_11_BASE + 1);
}

u32 XPredict_Get_tree_11_BitWidth(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XPREDICT_TREE_WIDTH_TREE_11;
}

u32 XPredict_Get_tree_11_Depth(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XPREDICT_TREE_DEPTH_TREE_11;
}

u32 XPredict_Write_tree_11_Words(XPredict *InstancePtr, int offset, word_type *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length)*4 > (XPREDICT_TREE_ADDR_TREE_11_HIGH - XPREDICT_TREE_ADDR_TREE_11_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(int *)(InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_11_BASE + (offset + i)*4) = *(data + i);
    }
    return length;
}

u32 XPredict_Read_tree_11_Words(XPredict *InstancePtr, int offset, word_type *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length)*4 > (XPREDICT_TREE_ADDR_TREE_11_HIGH - XPREDICT_TREE_ADDR_TREE_11_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(data + i) = *(int *)(InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_11_BASE + (offset + i)*4);
    }
    return length;
}

u32 XPredict_Write_tree_11_Bytes(XPredict *InstancePtr, int offset, char *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length) > (XPREDICT_TREE_ADDR_TREE_11_HIGH - XPREDICT_TREE_ADDR_TREE_11_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(char *)(InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_11_BASE + offset + i) = *(data + i);
    }
    return length;
}

u32 XPredict_Read_tree_11_Bytes(XPredict *InstancePtr, int offset, char *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length) > (XPREDICT_TREE_ADDR_TREE_11_HIGH - XPREDICT_TREE_ADDR_TREE_11_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(data + i) = *(char *)(InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_11_BASE + offset + i);
    }
    return length;
}

u32 XPredict_Get_tree_12_BaseAddress(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_12_BASE);
}

u32 XPredict_Get_tree_12_HighAddress(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_12_HIGH);
}

u32 XPredict_Get_tree_12_TotalBytes(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (XPREDICT_TREE_ADDR_TREE_12_HIGH - XPREDICT_TREE_ADDR_TREE_12_BASE + 1);
}

u32 XPredict_Get_tree_12_BitWidth(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XPREDICT_TREE_WIDTH_TREE_12;
}

u32 XPredict_Get_tree_12_Depth(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XPREDICT_TREE_DEPTH_TREE_12;
}

u32 XPredict_Write_tree_12_Words(XPredict *InstancePtr, int offset, word_type *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length)*4 > (XPREDICT_TREE_ADDR_TREE_12_HIGH - XPREDICT_TREE_ADDR_TREE_12_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(int *)(InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_12_BASE + (offset + i)*4) = *(data + i);
    }
    return length;
}

u32 XPredict_Read_tree_12_Words(XPredict *InstancePtr, int offset, word_type *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length)*4 > (XPREDICT_TREE_ADDR_TREE_12_HIGH - XPREDICT_TREE_ADDR_TREE_12_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(data + i) = *(int *)(InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_12_BASE + (offset + i)*4);
    }
    return length;
}

u32 XPredict_Write_tree_12_Bytes(XPredict *InstancePtr, int offset, char *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length) > (XPREDICT_TREE_ADDR_TREE_12_HIGH - XPREDICT_TREE_ADDR_TREE_12_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(char *)(InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_12_BASE + offset + i) = *(data + i);
    }
    return length;
}

u32 XPredict_Read_tree_12_Bytes(XPredict *InstancePtr, int offset, char *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length) > (XPREDICT_TREE_ADDR_TREE_12_HIGH - XPREDICT_TREE_ADDR_TREE_12_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(data + i) = *(char *)(InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_12_BASE + offset + i);
    }
    return length;
}

u32 XPredict_Get_tree_13_BaseAddress(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_13_BASE);
}

u32 XPredict_Get_tree_13_HighAddress(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_13_HIGH);
}

u32 XPredict_Get_tree_13_TotalBytes(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (XPREDICT_TREE_ADDR_TREE_13_HIGH - XPREDICT_TREE_ADDR_TREE_13_BASE + 1);
}

u32 XPredict_Get_tree_13_BitWidth(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XPREDICT_TREE_WIDTH_TREE_13;
}

u32 XPredict_Get_tree_13_Depth(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XPREDICT_TREE_DEPTH_TREE_13;
}

u32 XPredict_Write_tree_13_Words(XPredict *InstancePtr, int offset, word_type *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length)*4 > (XPREDICT_TREE_ADDR_TREE_13_HIGH - XPREDICT_TREE_ADDR_TREE_13_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(int *)(InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_13_BASE + (offset + i)*4) = *(data + i);
    }
    return length;
}

u32 XPredict_Read_tree_13_Words(XPredict *InstancePtr, int offset, word_type *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length)*4 > (XPREDICT_TREE_ADDR_TREE_13_HIGH - XPREDICT_TREE_ADDR_TREE_13_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(data + i) = *(int *)(InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_13_BASE + (offset + i)*4);
    }
    return length;
}

u32 XPredict_Write_tree_13_Bytes(XPredict *InstancePtr, int offset, char *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length) > (XPREDICT_TREE_ADDR_TREE_13_HIGH - XPREDICT_TREE_ADDR_TREE_13_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(char *)(InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_13_BASE + offset + i) = *(data + i);
    }
    return length;
}

u32 XPredict_Read_tree_13_Bytes(XPredict *InstancePtr, int offset, char *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length) > (XPREDICT_TREE_ADDR_TREE_13_HIGH - XPREDICT_TREE_ADDR_TREE_13_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(data + i) = *(char *)(InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_13_BASE + offset + i);
    }
    return length;
}

u32 XPredict_Get_tree_14_BaseAddress(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_14_BASE);
}

u32 XPredict_Get_tree_14_HighAddress(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_14_HIGH);
}

u32 XPredict_Get_tree_14_TotalBytes(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (XPREDICT_TREE_ADDR_TREE_14_HIGH - XPREDICT_TREE_ADDR_TREE_14_BASE + 1);
}

u32 XPredict_Get_tree_14_BitWidth(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XPREDICT_TREE_WIDTH_TREE_14;
}

u32 XPredict_Get_tree_14_Depth(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XPREDICT_TREE_DEPTH_TREE_14;
}

u32 XPredict_Write_tree_14_Words(XPredict *InstancePtr, int offset, word_type *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length)*4 > (XPREDICT_TREE_ADDR_TREE_14_HIGH - XPREDICT_TREE_ADDR_TREE_14_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(int *)(InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_14_BASE + (offset + i)*4) = *(data + i);
    }
    return length;
}

u32 XPredict_Read_tree_14_Words(XPredict *InstancePtr, int offset, word_type *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length)*4 > (XPREDICT_TREE_ADDR_TREE_14_HIGH - XPREDICT_TREE_ADDR_TREE_14_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(data + i) = *(int *)(InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_14_BASE + (offset + i)*4);
    }
    return length;
}

u32 XPredict_Write_tree_14_Bytes(XPredict *InstancePtr, int offset, char *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length) > (XPREDICT_TREE_ADDR_TREE_14_HIGH - XPREDICT_TREE_ADDR_TREE_14_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(char *)(InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_14_BASE + offset + i) = *(data + i);
    }
    return length;
}

u32 XPredict_Read_tree_14_Bytes(XPredict *InstancePtr, int offset, char *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length) > (XPREDICT_TREE_ADDR_TREE_14_HIGH - XPREDICT_TREE_ADDR_TREE_14_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(data + i) = *(char *)(InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_14_BASE + offset + i);
    }
    return length;
}

u32 XPredict_Get_tree_15_BaseAddress(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_15_BASE);
}

u32 XPredict_Get_tree_15_HighAddress(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_15_HIGH);
}

u32 XPredict_Get_tree_15_TotalBytes(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (XPREDICT_TREE_ADDR_TREE_15_HIGH - XPREDICT_TREE_ADDR_TREE_15_BASE + 1);
}

u32 XPredict_Get_tree_15_BitWidth(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XPREDICT_TREE_WIDTH_TREE_15;
}

u32 XPredict_Get_tree_15_Depth(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XPREDICT_TREE_DEPTH_TREE_15;
}

u32 XPredict_Write_tree_15_Words(XPredict *InstancePtr, int offset, word_type *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length)*4 > (XPREDICT_TREE_ADDR_TREE_15_HIGH - XPREDICT_TREE_ADDR_TREE_15_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(int *)(InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_15_BASE + (offset + i)*4) = *(data + i);
    }
    return length;
}

u32 XPredict_Read_tree_15_Words(XPredict *InstancePtr, int offset, word_type *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length)*4 > (XPREDICT_TREE_ADDR_TREE_15_HIGH - XPREDICT_TREE_ADDR_TREE_15_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(data + i) = *(int *)(InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_15_BASE + (offset + i)*4);
    }
    return length;
}

u32 XPredict_Write_tree_15_Bytes(XPredict *InstancePtr, int offset, char *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length) > (XPREDICT_TREE_ADDR_TREE_15_HIGH - XPREDICT_TREE_ADDR_TREE_15_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(char *)(InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_15_BASE + offset + i) = *(data + i);
    }
    return length;
}

u32 XPredict_Read_tree_15_Bytes(XPredict *InstancePtr, int offset, char *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length) > (XPREDICT_TREE_ADDR_TREE_15_HIGH - XPREDICT_TREE_ADDR_TREE_15_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(data + i) = *(char *)(InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_15_BASE + offset + i);
    }
    return length;
}

u32 XPredict_Get_tree_16_BaseAddress(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_16_BASE);
}

u32 XPredict_Get_tree_16_HighAddress(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_16_HIGH);
}

u32 XPredict_Get_tree_16_TotalBytes(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (XPREDICT_TREE_ADDR_TREE_16_HIGH - XPREDICT_TREE_ADDR_TREE_16_BASE + 1);
}

u32 XPredict_Get_tree_16_BitWidth(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XPREDICT_TREE_WIDTH_TREE_16;
}

u32 XPredict_Get_tree_16_Depth(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XPREDICT_TREE_DEPTH_TREE_16;
}

u32 XPredict_Write_tree_16_Words(XPredict *InstancePtr, int offset, word_type *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length)*4 > (XPREDICT_TREE_ADDR_TREE_16_HIGH - XPREDICT_TREE_ADDR_TREE_16_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(int *)(InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_16_BASE + (offset + i)*4) = *(data + i);
    }
    return length;
}

u32 XPredict_Read_tree_16_Words(XPredict *InstancePtr, int offset, word_type *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length)*4 > (XPREDICT_TREE_ADDR_TREE_16_HIGH - XPREDICT_TREE_ADDR_TREE_16_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(data + i) = *(int *)(InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_16_BASE + (offset + i)*4);
    }
    return length;
}

u32 XPredict_Write_tree_16_Bytes(XPredict *InstancePtr, int offset, char *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length) > (XPREDICT_TREE_ADDR_TREE_16_HIGH - XPREDICT_TREE_ADDR_TREE_16_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(char *)(InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_16_BASE + offset + i) = *(data + i);
    }
    return length;
}

u32 XPredict_Read_tree_16_Bytes(XPredict *InstancePtr, int offset, char *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length) > (XPREDICT_TREE_ADDR_TREE_16_HIGH - XPREDICT_TREE_ADDR_TREE_16_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(data + i) = *(char *)(InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_16_BASE + offset + i);
    }
    return length;
}

u32 XPredict_Get_tree_17_BaseAddress(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_17_BASE);
}

u32 XPredict_Get_tree_17_HighAddress(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_17_HIGH);
}

u32 XPredict_Get_tree_17_TotalBytes(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (XPREDICT_TREE_ADDR_TREE_17_HIGH - XPREDICT_TREE_ADDR_TREE_17_BASE + 1);
}

u32 XPredict_Get_tree_17_BitWidth(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XPREDICT_TREE_WIDTH_TREE_17;
}

u32 XPredict_Get_tree_17_Depth(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XPREDICT_TREE_DEPTH_TREE_17;
}

u32 XPredict_Write_tree_17_Words(XPredict *InstancePtr, int offset, word_type *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length)*4 > (XPREDICT_TREE_ADDR_TREE_17_HIGH - XPREDICT_TREE_ADDR_TREE_17_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(int *)(InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_17_BASE + (offset + i)*4) = *(data + i);
    }
    return length;
}

u32 XPredict_Read_tree_17_Words(XPredict *InstancePtr, int offset, word_type *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length)*4 > (XPREDICT_TREE_ADDR_TREE_17_HIGH - XPREDICT_TREE_ADDR_TREE_17_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(data + i) = *(int *)(InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_17_BASE + (offset + i)*4);
    }
    return length;
}

u32 XPredict_Write_tree_17_Bytes(XPredict *InstancePtr, int offset, char *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length) > (XPREDICT_TREE_ADDR_TREE_17_HIGH - XPREDICT_TREE_ADDR_TREE_17_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(char *)(InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_17_BASE + offset + i) = *(data + i);
    }
    return length;
}

u32 XPredict_Read_tree_17_Bytes(XPredict *InstancePtr, int offset, char *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length) > (XPREDICT_TREE_ADDR_TREE_17_HIGH - XPREDICT_TREE_ADDR_TREE_17_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(data + i) = *(char *)(InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_17_BASE + offset + i);
    }
    return length;
}

u32 XPredict_Get_tree_18_BaseAddress(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_18_BASE);
}

u32 XPredict_Get_tree_18_HighAddress(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_18_HIGH);
}

u32 XPredict_Get_tree_18_TotalBytes(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (XPREDICT_TREE_ADDR_TREE_18_HIGH - XPREDICT_TREE_ADDR_TREE_18_BASE + 1);
}

u32 XPredict_Get_tree_18_BitWidth(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XPREDICT_TREE_WIDTH_TREE_18;
}

u32 XPredict_Get_tree_18_Depth(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XPREDICT_TREE_DEPTH_TREE_18;
}

u32 XPredict_Write_tree_18_Words(XPredict *InstancePtr, int offset, word_type *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length)*4 > (XPREDICT_TREE_ADDR_TREE_18_HIGH - XPREDICT_TREE_ADDR_TREE_18_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(int *)(InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_18_BASE + (offset + i)*4) = *(data + i);
    }
    return length;
}

u32 XPredict_Read_tree_18_Words(XPredict *InstancePtr, int offset, word_type *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length)*4 > (XPREDICT_TREE_ADDR_TREE_18_HIGH - XPREDICT_TREE_ADDR_TREE_18_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(data + i) = *(int *)(InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_18_BASE + (offset + i)*4);
    }
    return length;
}

u32 XPredict_Write_tree_18_Bytes(XPredict *InstancePtr, int offset, char *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length) > (XPREDICT_TREE_ADDR_TREE_18_HIGH - XPREDICT_TREE_ADDR_TREE_18_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(char *)(InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_18_BASE + offset + i) = *(data + i);
    }
    return length;
}

u32 XPredict_Read_tree_18_Bytes(XPredict *InstancePtr, int offset, char *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length) > (XPREDICT_TREE_ADDR_TREE_18_HIGH - XPREDICT_TREE_ADDR_TREE_18_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(data + i) = *(char *)(InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_18_BASE + offset + i);
    }
    return length;
}

u32 XPredict_Get_tree_19_BaseAddress(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_19_BASE);
}

u32 XPredict_Get_tree_19_HighAddress(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_19_HIGH);
}

u32 XPredict_Get_tree_19_TotalBytes(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (XPREDICT_TREE_ADDR_TREE_19_HIGH - XPREDICT_TREE_ADDR_TREE_19_BASE + 1);
}

u32 XPredict_Get_tree_19_BitWidth(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XPREDICT_TREE_WIDTH_TREE_19;
}

u32 XPredict_Get_tree_19_Depth(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XPREDICT_TREE_DEPTH_TREE_19;
}

u32 XPredict_Write_tree_19_Words(XPredict *InstancePtr, int offset, word_type *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length)*4 > (XPREDICT_TREE_ADDR_TREE_19_HIGH - XPREDICT_TREE_ADDR_TREE_19_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(int *)(InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_19_BASE + (offset + i)*4) = *(data + i);
    }
    return length;
}

u32 XPredict_Read_tree_19_Words(XPredict *InstancePtr, int offset, word_type *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length)*4 > (XPREDICT_TREE_ADDR_TREE_19_HIGH - XPREDICT_TREE_ADDR_TREE_19_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(data + i) = *(int *)(InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_19_BASE + (offset + i)*4);
    }
    return length;
}

u32 XPredict_Write_tree_19_Bytes(XPredict *InstancePtr, int offset, char *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length) > (XPREDICT_TREE_ADDR_TREE_19_HIGH - XPREDICT_TREE_ADDR_TREE_19_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(char *)(InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_19_BASE + offset + i) = *(data + i);
    }
    return length;
}

u32 XPredict_Read_tree_19_Bytes(XPredict *InstancePtr, int offset, char *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length) > (XPREDICT_TREE_ADDR_TREE_19_HIGH - XPREDICT_TREE_ADDR_TREE_19_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(data + i) = *(char *)(InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_19_BASE + offset + i);
    }
    return length;
}

u32 XPredict_Get_tree_20_BaseAddress(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_20_BASE);
}

u32 XPredict_Get_tree_20_HighAddress(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_20_HIGH);
}

u32 XPredict_Get_tree_20_TotalBytes(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (XPREDICT_TREE_ADDR_TREE_20_HIGH - XPREDICT_TREE_ADDR_TREE_20_BASE + 1);
}

u32 XPredict_Get_tree_20_BitWidth(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XPREDICT_TREE_WIDTH_TREE_20;
}

u32 XPredict_Get_tree_20_Depth(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XPREDICT_TREE_DEPTH_TREE_20;
}

u32 XPredict_Write_tree_20_Words(XPredict *InstancePtr, int offset, word_type *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length)*4 > (XPREDICT_TREE_ADDR_TREE_20_HIGH - XPREDICT_TREE_ADDR_TREE_20_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(int *)(InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_20_BASE + (offset + i)*4) = *(data + i);
    }
    return length;
}

u32 XPredict_Read_tree_20_Words(XPredict *InstancePtr, int offset, word_type *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length)*4 > (XPREDICT_TREE_ADDR_TREE_20_HIGH - XPREDICT_TREE_ADDR_TREE_20_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(data + i) = *(int *)(InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_20_BASE + (offset + i)*4);
    }
    return length;
}

u32 XPredict_Write_tree_20_Bytes(XPredict *InstancePtr, int offset, char *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length) > (XPREDICT_TREE_ADDR_TREE_20_HIGH - XPREDICT_TREE_ADDR_TREE_20_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(char *)(InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_20_BASE + offset + i) = *(data + i);
    }
    return length;
}

u32 XPredict_Read_tree_20_Bytes(XPredict *InstancePtr, int offset, char *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length) > (XPREDICT_TREE_ADDR_TREE_20_HIGH - XPREDICT_TREE_ADDR_TREE_20_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(data + i) = *(char *)(InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_20_BASE + offset + i);
    }
    return length;
}

u32 XPredict_Get_tree_21_BaseAddress(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_21_BASE);
}

u32 XPredict_Get_tree_21_HighAddress(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_21_HIGH);
}

u32 XPredict_Get_tree_21_TotalBytes(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (XPREDICT_TREE_ADDR_TREE_21_HIGH - XPREDICT_TREE_ADDR_TREE_21_BASE + 1);
}

u32 XPredict_Get_tree_21_BitWidth(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XPREDICT_TREE_WIDTH_TREE_21;
}

u32 XPredict_Get_tree_21_Depth(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XPREDICT_TREE_DEPTH_TREE_21;
}

u32 XPredict_Write_tree_21_Words(XPredict *InstancePtr, int offset, word_type *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length)*4 > (XPREDICT_TREE_ADDR_TREE_21_HIGH - XPREDICT_TREE_ADDR_TREE_21_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(int *)(InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_21_BASE + (offset + i)*4) = *(data + i);
    }
    return length;
}

u32 XPredict_Read_tree_21_Words(XPredict *InstancePtr, int offset, word_type *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length)*4 > (XPREDICT_TREE_ADDR_TREE_21_HIGH - XPREDICT_TREE_ADDR_TREE_21_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(data + i) = *(int *)(InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_21_BASE + (offset + i)*4);
    }
    return length;
}

u32 XPredict_Write_tree_21_Bytes(XPredict *InstancePtr, int offset, char *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length) > (XPREDICT_TREE_ADDR_TREE_21_HIGH - XPREDICT_TREE_ADDR_TREE_21_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(char *)(InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_21_BASE + offset + i) = *(data + i);
    }
    return length;
}

u32 XPredict_Read_tree_21_Bytes(XPredict *InstancePtr, int offset, char *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length) > (XPREDICT_TREE_ADDR_TREE_21_HIGH - XPREDICT_TREE_ADDR_TREE_21_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(data + i) = *(char *)(InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_21_BASE + offset + i);
    }
    return length;
}

u32 XPredict_Get_tree_22_BaseAddress(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_22_BASE);
}

u32 XPredict_Get_tree_22_HighAddress(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_22_HIGH);
}

u32 XPredict_Get_tree_22_TotalBytes(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (XPREDICT_TREE_ADDR_TREE_22_HIGH - XPREDICT_TREE_ADDR_TREE_22_BASE + 1);
}

u32 XPredict_Get_tree_22_BitWidth(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XPREDICT_TREE_WIDTH_TREE_22;
}

u32 XPredict_Get_tree_22_Depth(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XPREDICT_TREE_DEPTH_TREE_22;
}

u32 XPredict_Write_tree_22_Words(XPredict *InstancePtr, int offset, word_type *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length)*4 > (XPREDICT_TREE_ADDR_TREE_22_HIGH - XPREDICT_TREE_ADDR_TREE_22_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(int *)(InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_22_BASE + (offset + i)*4) = *(data + i);
    }
    return length;
}

u32 XPredict_Read_tree_22_Words(XPredict *InstancePtr, int offset, word_type *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length)*4 > (XPREDICT_TREE_ADDR_TREE_22_HIGH - XPREDICT_TREE_ADDR_TREE_22_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(data + i) = *(int *)(InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_22_BASE + (offset + i)*4);
    }
    return length;
}

u32 XPredict_Write_tree_22_Bytes(XPredict *InstancePtr, int offset, char *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length) > (XPREDICT_TREE_ADDR_TREE_22_HIGH - XPREDICT_TREE_ADDR_TREE_22_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(char *)(InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_22_BASE + offset + i) = *(data + i);
    }
    return length;
}

u32 XPredict_Read_tree_22_Bytes(XPredict *InstancePtr, int offset, char *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length) > (XPREDICT_TREE_ADDR_TREE_22_HIGH - XPREDICT_TREE_ADDR_TREE_22_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(data + i) = *(char *)(InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_22_BASE + offset + i);
    }
    return length;
}

u32 XPredict_Get_tree_23_BaseAddress(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_23_BASE);
}

u32 XPredict_Get_tree_23_HighAddress(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_23_HIGH);
}

u32 XPredict_Get_tree_23_TotalBytes(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (XPREDICT_TREE_ADDR_TREE_23_HIGH - XPREDICT_TREE_ADDR_TREE_23_BASE + 1);
}

u32 XPredict_Get_tree_23_BitWidth(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XPREDICT_TREE_WIDTH_TREE_23;
}

u32 XPredict_Get_tree_23_Depth(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XPREDICT_TREE_DEPTH_TREE_23;
}

u32 XPredict_Write_tree_23_Words(XPredict *InstancePtr, int offset, word_type *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length)*4 > (XPREDICT_TREE_ADDR_TREE_23_HIGH - XPREDICT_TREE_ADDR_TREE_23_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(int *)(InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_23_BASE + (offset + i)*4) = *(data + i);
    }
    return length;
}

u32 XPredict_Read_tree_23_Words(XPredict *InstancePtr, int offset, word_type *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length)*4 > (XPREDICT_TREE_ADDR_TREE_23_HIGH - XPREDICT_TREE_ADDR_TREE_23_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(data + i) = *(int *)(InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_23_BASE + (offset + i)*4);
    }
    return length;
}

u32 XPredict_Write_tree_23_Bytes(XPredict *InstancePtr, int offset, char *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length) > (XPREDICT_TREE_ADDR_TREE_23_HIGH - XPREDICT_TREE_ADDR_TREE_23_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(char *)(InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_23_BASE + offset + i) = *(data + i);
    }
    return length;
}

u32 XPredict_Read_tree_23_Bytes(XPredict *InstancePtr, int offset, char *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length) > (XPREDICT_TREE_ADDR_TREE_23_HIGH - XPREDICT_TREE_ADDR_TREE_23_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(data + i) = *(char *)(InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_23_BASE + offset + i);
    }
    return length;
}

u32 XPredict_Get_tree_24_BaseAddress(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_24_BASE);
}

u32 XPredict_Get_tree_24_HighAddress(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_24_HIGH);
}

u32 XPredict_Get_tree_24_TotalBytes(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (XPREDICT_TREE_ADDR_TREE_24_HIGH - XPREDICT_TREE_ADDR_TREE_24_BASE + 1);
}

u32 XPredict_Get_tree_24_BitWidth(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XPREDICT_TREE_WIDTH_TREE_24;
}

u32 XPredict_Get_tree_24_Depth(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XPREDICT_TREE_DEPTH_TREE_24;
}

u32 XPredict_Write_tree_24_Words(XPredict *InstancePtr, int offset, word_type *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length)*4 > (XPREDICT_TREE_ADDR_TREE_24_HIGH - XPREDICT_TREE_ADDR_TREE_24_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(int *)(InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_24_BASE + (offset + i)*4) = *(data + i);
    }
    return length;
}

u32 XPredict_Read_tree_24_Words(XPredict *InstancePtr, int offset, word_type *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length)*4 > (XPREDICT_TREE_ADDR_TREE_24_HIGH - XPREDICT_TREE_ADDR_TREE_24_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(data + i) = *(int *)(InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_24_BASE + (offset + i)*4);
    }
    return length;
}

u32 XPredict_Write_tree_24_Bytes(XPredict *InstancePtr, int offset, char *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length) > (XPREDICT_TREE_ADDR_TREE_24_HIGH - XPREDICT_TREE_ADDR_TREE_24_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(char *)(InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_24_BASE + offset + i) = *(data + i);
    }
    return length;
}

u32 XPredict_Read_tree_24_Bytes(XPredict *InstancePtr, int offset, char *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length) > (XPREDICT_TREE_ADDR_TREE_24_HIGH - XPREDICT_TREE_ADDR_TREE_24_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(data + i) = *(char *)(InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_24_BASE + offset + i);
    }
    return length;
}

u32 XPredict_Get_tree_25_BaseAddress(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_25_BASE);
}

u32 XPredict_Get_tree_25_HighAddress(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_25_HIGH);
}

u32 XPredict_Get_tree_25_TotalBytes(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (XPREDICT_TREE_ADDR_TREE_25_HIGH - XPREDICT_TREE_ADDR_TREE_25_BASE + 1);
}

u32 XPredict_Get_tree_25_BitWidth(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XPREDICT_TREE_WIDTH_TREE_25;
}

u32 XPredict_Get_tree_25_Depth(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XPREDICT_TREE_DEPTH_TREE_25;
}

u32 XPredict_Write_tree_25_Words(XPredict *InstancePtr, int offset, word_type *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length)*4 > (XPREDICT_TREE_ADDR_TREE_25_HIGH - XPREDICT_TREE_ADDR_TREE_25_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(int *)(InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_25_BASE + (offset + i)*4) = *(data + i);
    }
    return length;
}

u32 XPredict_Read_tree_25_Words(XPredict *InstancePtr, int offset, word_type *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length)*4 > (XPREDICT_TREE_ADDR_TREE_25_HIGH - XPREDICT_TREE_ADDR_TREE_25_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(data + i) = *(int *)(InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_25_BASE + (offset + i)*4);
    }
    return length;
}

u32 XPredict_Write_tree_25_Bytes(XPredict *InstancePtr, int offset, char *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length) > (XPREDICT_TREE_ADDR_TREE_25_HIGH - XPREDICT_TREE_ADDR_TREE_25_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(char *)(InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_25_BASE + offset + i) = *(data + i);
    }
    return length;
}

u32 XPredict_Read_tree_25_Bytes(XPredict *InstancePtr, int offset, char *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length) > (XPREDICT_TREE_ADDR_TREE_25_HIGH - XPREDICT_TREE_ADDR_TREE_25_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(data + i) = *(char *)(InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_25_BASE + offset + i);
    }
    return length;
}

u32 XPredict_Get_tree_26_BaseAddress(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_26_BASE);
}

u32 XPredict_Get_tree_26_HighAddress(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_26_HIGH);
}

u32 XPredict_Get_tree_26_TotalBytes(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (XPREDICT_TREE_ADDR_TREE_26_HIGH - XPREDICT_TREE_ADDR_TREE_26_BASE + 1);
}

u32 XPredict_Get_tree_26_BitWidth(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XPREDICT_TREE_WIDTH_TREE_26;
}

u32 XPredict_Get_tree_26_Depth(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XPREDICT_TREE_DEPTH_TREE_26;
}

u32 XPredict_Write_tree_26_Words(XPredict *InstancePtr, int offset, word_type *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length)*4 > (XPREDICT_TREE_ADDR_TREE_26_HIGH - XPREDICT_TREE_ADDR_TREE_26_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(int *)(InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_26_BASE + (offset + i)*4) = *(data + i);
    }
    return length;
}

u32 XPredict_Read_tree_26_Words(XPredict *InstancePtr, int offset, word_type *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length)*4 > (XPREDICT_TREE_ADDR_TREE_26_HIGH - XPREDICT_TREE_ADDR_TREE_26_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(data + i) = *(int *)(InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_26_BASE + (offset + i)*4);
    }
    return length;
}

u32 XPredict_Write_tree_26_Bytes(XPredict *InstancePtr, int offset, char *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length) > (XPREDICT_TREE_ADDR_TREE_26_HIGH - XPREDICT_TREE_ADDR_TREE_26_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(char *)(InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_26_BASE + offset + i) = *(data + i);
    }
    return length;
}

u32 XPredict_Read_tree_26_Bytes(XPredict *InstancePtr, int offset, char *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length) > (XPREDICT_TREE_ADDR_TREE_26_HIGH - XPREDICT_TREE_ADDR_TREE_26_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(data + i) = *(char *)(InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_26_BASE + offset + i);
    }
    return length;
}

u32 XPredict_Get_tree_27_BaseAddress(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_27_BASE);
}

u32 XPredict_Get_tree_27_HighAddress(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_27_HIGH);
}

u32 XPredict_Get_tree_27_TotalBytes(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (XPREDICT_TREE_ADDR_TREE_27_HIGH - XPREDICT_TREE_ADDR_TREE_27_BASE + 1);
}

u32 XPredict_Get_tree_27_BitWidth(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XPREDICT_TREE_WIDTH_TREE_27;
}

u32 XPredict_Get_tree_27_Depth(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XPREDICT_TREE_DEPTH_TREE_27;
}

u32 XPredict_Write_tree_27_Words(XPredict *InstancePtr, int offset, word_type *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length)*4 > (XPREDICT_TREE_ADDR_TREE_27_HIGH - XPREDICT_TREE_ADDR_TREE_27_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(int *)(InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_27_BASE + (offset + i)*4) = *(data + i);
    }
    return length;
}

u32 XPredict_Read_tree_27_Words(XPredict *InstancePtr, int offset, word_type *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length)*4 > (XPREDICT_TREE_ADDR_TREE_27_HIGH - XPREDICT_TREE_ADDR_TREE_27_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(data + i) = *(int *)(InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_27_BASE + (offset + i)*4);
    }
    return length;
}

u32 XPredict_Write_tree_27_Bytes(XPredict *InstancePtr, int offset, char *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length) > (XPREDICT_TREE_ADDR_TREE_27_HIGH - XPREDICT_TREE_ADDR_TREE_27_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(char *)(InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_27_BASE + offset + i) = *(data + i);
    }
    return length;
}

u32 XPredict_Read_tree_27_Bytes(XPredict *InstancePtr, int offset, char *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length) > (XPREDICT_TREE_ADDR_TREE_27_HIGH - XPREDICT_TREE_ADDR_TREE_27_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(data + i) = *(char *)(InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_27_BASE + offset + i);
    }
    return length;
}

u32 XPredict_Get_tree_28_BaseAddress(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_28_BASE);
}

u32 XPredict_Get_tree_28_HighAddress(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_28_HIGH);
}

u32 XPredict_Get_tree_28_TotalBytes(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (XPREDICT_TREE_ADDR_TREE_28_HIGH - XPREDICT_TREE_ADDR_TREE_28_BASE + 1);
}

u32 XPredict_Get_tree_28_BitWidth(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XPREDICT_TREE_WIDTH_TREE_28;
}

u32 XPredict_Get_tree_28_Depth(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XPREDICT_TREE_DEPTH_TREE_28;
}

u32 XPredict_Write_tree_28_Words(XPredict *InstancePtr, int offset, word_type *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length)*4 > (XPREDICT_TREE_ADDR_TREE_28_HIGH - XPREDICT_TREE_ADDR_TREE_28_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(int *)(InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_28_BASE + (offset + i)*4) = *(data + i);
    }
    return length;
}

u32 XPredict_Read_tree_28_Words(XPredict *InstancePtr, int offset, word_type *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length)*4 > (XPREDICT_TREE_ADDR_TREE_28_HIGH - XPREDICT_TREE_ADDR_TREE_28_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(data + i) = *(int *)(InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_28_BASE + (offset + i)*4);
    }
    return length;
}

u32 XPredict_Write_tree_28_Bytes(XPredict *InstancePtr, int offset, char *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length) > (XPREDICT_TREE_ADDR_TREE_28_HIGH - XPREDICT_TREE_ADDR_TREE_28_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(char *)(InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_28_BASE + offset + i) = *(data + i);
    }
    return length;
}

u32 XPredict_Read_tree_28_Bytes(XPredict *InstancePtr, int offset, char *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length) > (XPREDICT_TREE_ADDR_TREE_28_HIGH - XPREDICT_TREE_ADDR_TREE_28_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(data + i) = *(char *)(InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_28_BASE + offset + i);
    }
    return length;
}

u32 XPredict_Get_tree_29_BaseAddress(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_29_BASE);
}

u32 XPredict_Get_tree_29_HighAddress(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_29_HIGH);
}

u32 XPredict_Get_tree_29_TotalBytes(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (XPREDICT_TREE_ADDR_TREE_29_HIGH - XPREDICT_TREE_ADDR_TREE_29_BASE + 1);
}

u32 XPredict_Get_tree_29_BitWidth(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XPREDICT_TREE_WIDTH_TREE_29;
}

u32 XPredict_Get_tree_29_Depth(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XPREDICT_TREE_DEPTH_TREE_29;
}

u32 XPredict_Write_tree_29_Words(XPredict *InstancePtr, int offset, word_type *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length)*4 > (XPREDICT_TREE_ADDR_TREE_29_HIGH - XPREDICT_TREE_ADDR_TREE_29_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(int *)(InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_29_BASE + (offset + i)*4) = *(data + i);
    }
    return length;
}

u32 XPredict_Read_tree_29_Words(XPredict *InstancePtr, int offset, word_type *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length)*4 > (XPREDICT_TREE_ADDR_TREE_29_HIGH - XPREDICT_TREE_ADDR_TREE_29_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(data + i) = *(int *)(InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_29_BASE + (offset + i)*4);
    }
    return length;
}

u32 XPredict_Write_tree_29_Bytes(XPredict *InstancePtr, int offset, char *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length) > (XPREDICT_TREE_ADDR_TREE_29_HIGH - XPREDICT_TREE_ADDR_TREE_29_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(char *)(InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_29_BASE + offset + i) = *(data + i);
    }
    return length;
}

u32 XPredict_Read_tree_29_Bytes(XPredict *InstancePtr, int offset, char *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length) > (XPREDICT_TREE_ADDR_TREE_29_HIGH - XPREDICT_TREE_ADDR_TREE_29_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(data + i) = *(char *)(InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_29_BASE + offset + i);
    }
    return length;
}

u32 XPredict_Get_tree_30_BaseAddress(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_30_BASE);
}

u32 XPredict_Get_tree_30_HighAddress(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_30_HIGH);
}

u32 XPredict_Get_tree_30_TotalBytes(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (XPREDICT_TREE_ADDR_TREE_30_HIGH - XPREDICT_TREE_ADDR_TREE_30_BASE + 1);
}

u32 XPredict_Get_tree_30_BitWidth(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XPREDICT_TREE_WIDTH_TREE_30;
}

u32 XPredict_Get_tree_30_Depth(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XPREDICT_TREE_DEPTH_TREE_30;
}

u32 XPredict_Write_tree_30_Words(XPredict *InstancePtr, int offset, word_type *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length)*4 > (XPREDICT_TREE_ADDR_TREE_30_HIGH - XPREDICT_TREE_ADDR_TREE_30_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(int *)(InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_30_BASE + (offset + i)*4) = *(data + i);
    }
    return length;
}

u32 XPredict_Read_tree_30_Words(XPredict *InstancePtr, int offset, word_type *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length)*4 > (XPREDICT_TREE_ADDR_TREE_30_HIGH - XPREDICT_TREE_ADDR_TREE_30_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(data + i) = *(int *)(InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_30_BASE + (offset + i)*4);
    }
    return length;
}

u32 XPredict_Write_tree_30_Bytes(XPredict *InstancePtr, int offset, char *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length) > (XPREDICT_TREE_ADDR_TREE_30_HIGH - XPREDICT_TREE_ADDR_TREE_30_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(char *)(InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_30_BASE + offset + i) = *(data + i);
    }
    return length;
}

u32 XPredict_Read_tree_30_Bytes(XPredict *InstancePtr, int offset, char *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length) > (XPREDICT_TREE_ADDR_TREE_30_HIGH - XPREDICT_TREE_ADDR_TREE_30_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(data + i) = *(char *)(InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_30_BASE + offset + i);
    }
    return length;
}

u32 XPredict_Get_tree_31_BaseAddress(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_31_BASE);
}

u32 XPredict_Get_tree_31_HighAddress(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_31_HIGH);
}

u32 XPredict_Get_tree_31_TotalBytes(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (XPREDICT_TREE_ADDR_TREE_31_HIGH - XPREDICT_TREE_ADDR_TREE_31_BASE + 1);
}

u32 XPredict_Get_tree_31_BitWidth(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XPREDICT_TREE_WIDTH_TREE_31;
}

u32 XPredict_Get_tree_31_Depth(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XPREDICT_TREE_DEPTH_TREE_31;
}

u32 XPredict_Write_tree_31_Words(XPredict *InstancePtr, int offset, word_type *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length)*4 > (XPREDICT_TREE_ADDR_TREE_31_HIGH - XPREDICT_TREE_ADDR_TREE_31_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(int *)(InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_31_BASE + (offset + i)*4) = *(data + i);
    }
    return length;
}

u32 XPredict_Read_tree_31_Words(XPredict *InstancePtr, int offset, word_type *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length)*4 > (XPREDICT_TREE_ADDR_TREE_31_HIGH - XPREDICT_TREE_ADDR_TREE_31_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(data + i) = *(int *)(InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_31_BASE + (offset + i)*4);
    }
    return length;
}

u32 XPredict_Write_tree_31_Bytes(XPredict *InstancePtr, int offset, char *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length) > (XPREDICT_TREE_ADDR_TREE_31_HIGH - XPREDICT_TREE_ADDR_TREE_31_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(char *)(InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_31_BASE + offset + i) = *(data + i);
    }
    return length;
}

u32 XPredict_Read_tree_31_Bytes(XPredict *InstancePtr, int offset, char *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length) > (XPREDICT_TREE_ADDR_TREE_31_HIGH - XPREDICT_TREE_ADDR_TREE_31_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(data + i) = *(char *)(InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_31_BASE + offset + i);
    }
    return length;
}

u32 XPredict_Get_tree_32_BaseAddress(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_32_BASE);
}

u32 XPredict_Get_tree_32_HighAddress(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_32_HIGH);
}

u32 XPredict_Get_tree_32_TotalBytes(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (XPREDICT_TREE_ADDR_TREE_32_HIGH - XPREDICT_TREE_ADDR_TREE_32_BASE + 1);
}

u32 XPredict_Get_tree_32_BitWidth(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XPREDICT_TREE_WIDTH_TREE_32;
}

u32 XPredict_Get_tree_32_Depth(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XPREDICT_TREE_DEPTH_TREE_32;
}

u32 XPredict_Write_tree_32_Words(XPredict *InstancePtr, int offset, word_type *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length)*4 > (XPREDICT_TREE_ADDR_TREE_32_HIGH - XPREDICT_TREE_ADDR_TREE_32_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(int *)(InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_32_BASE + (offset + i)*4) = *(data + i);
    }
    return length;
}

u32 XPredict_Read_tree_32_Words(XPredict *InstancePtr, int offset, word_type *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length)*4 > (XPREDICT_TREE_ADDR_TREE_32_HIGH - XPREDICT_TREE_ADDR_TREE_32_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(data + i) = *(int *)(InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_32_BASE + (offset + i)*4);
    }
    return length;
}

u32 XPredict_Write_tree_32_Bytes(XPredict *InstancePtr, int offset, char *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length) > (XPREDICT_TREE_ADDR_TREE_32_HIGH - XPREDICT_TREE_ADDR_TREE_32_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(char *)(InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_32_BASE + offset + i) = *(data + i);
    }
    return length;
}

u32 XPredict_Read_tree_32_Bytes(XPredict *InstancePtr, int offset, char *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length) > (XPREDICT_TREE_ADDR_TREE_32_HIGH - XPREDICT_TREE_ADDR_TREE_32_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(data + i) = *(char *)(InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_32_BASE + offset + i);
    }
    return length;
}

u32 XPredict_Get_tree_33_BaseAddress(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_33_BASE);
}

u32 XPredict_Get_tree_33_HighAddress(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_33_HIGH);
}

u32 XPredict_Get_tree_33_TotalBytes(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (XPREDICT_TREE_ADDR_TREE_33_HIGH - XPREDICT_TREE_ADDR_TREE_33_BASE + 1);
}

u32 XPredict_Get_tree_33_BitWidth(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XPREDICT_TREE_WIDTH_TREE_33;
}

u32 XPredict_Get_tree_33_Depth(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XPREDICT_TREE_DEPTH_TREE_33;
}

u32 XPredict_Write_tree_33_Words(XPredict *InstancePtr, int offset, word_type *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length)*4 > (XPREDICT_TREE_ADDR_TREE_33_HIGH - XPREDICT_TREE_ADDR_TREE_33_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(int *)(InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_33_BASE + (offset + i)*4) = *(data + i);
    }
    return length;
}

u32 XPredict_Read_tree_33_Words(XPredict *InstancePtr, int offset, word_type *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length)*4 > (XPREDICT_TREE_ADDR_TREE_33_HIGH - XPREDICT_TREE_ADDR_TREE_33_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(data + i) = *(int *)(InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_33_BASE + (offset + i)*4);
    }
    return length;
}

u32 XPredict_Write_tree_33_Bytes(XPredict *InstancePtr, int offset, char *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length) > (XPREDICT_TREE_ADDR_TREE_33_HIGH - XPREDICT_TREE_ADDR_TREE_33_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(char *)(InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_33_BASE + offset + i) = *(data + i);
    }
    return length;
}

u32 XPredict_Read_tree_33_Bytes(XPredict *InstancePtr, int offset, char *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length) > (XPREDICT_TREE_ADDR_TREE_33_HIGH - XPREDICT_TREE_ADDR_TREE_33_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(data + i) = *(char *)(InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_33_BASE + offset + i);
    }
    return length;
}

u32 XPredict_Get_tree_34_BaseAddress(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_34_BASE);
}

u32 XPredict_Get_tree_34_HighAddress(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_34_HIGH);
}

u32 XPredict_Get_tree_34_TotalBytes(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (XPREDICT_TREE_ADDR_TREE_34_HIGH - XPREDICT_TREE_ADDR_TREE_34_BASE + 1);
}

u32 XPredict_Get_tree_34_BitWidth(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XPREDICT_TREE_WIDTH_TREE_34;
}

u32 XPredict_Get_tree_34_Depth(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XPREDICT_TREE_DEPTH_TREE_34;
}

u32 XPredict_Write_tree_34_Words(XPredict *InstancePtr, int offset, word_type *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length)*4 > (XPREDICT_TREE_ADDR_TREE_34_HIGH - XPREDICT_TREE_ADDR_TREE_34_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(int *)(InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_34_BASE + (offset + i)*4) = *(data + i);
    }
    return length;
}

u32 XPredict_Read_tree_34_Words(XPredict *InstancePtr, int offset, word_type *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length)*4 > (XPREDICT_TREE_ADDR_TREE_34_HIGH - XPREDICT_TREE_ADDR_TREE_34_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(data + i) = *(int *)(InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_34_BASE + (offset + i)*4);
    }
    return length;
}

u32 XPredict_Write_tree_34_Bytes(XPredict *InstancePtr, int offset, char *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length) > (XPREDICT_TREE_ADDR_TREE_34_HIGH - XPREDICT_TREE_ADDR_TREE_34_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(char *)(InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_34_BASE + offset + i) = *(data + i);
    }
    return length;
}

u32 XPredict_Read_tree_34_Bytes(XPredict *InstancePtr, int offset, char *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length) > (XPREDICT_TREE_ADDR_TREE_34_HIGH - XPREDICT_TREE_ADDR_TREE_34_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(data + i) = *(char *)(InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_34_BASE + offset + i);
    }
    return length;
}

u32 XPredict_Get_tree_35_BaseAddress(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_35_BASE);
}

u32 XPredict_Get_tree_35_HighAddress(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_35_HIGH);
}

u32 XPredict_Get_tree_35_TotalBytes(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (XPREDICT_TREE_ADDR_TREE_35_HIGH - XPREDICT_TREE_ADDR_TREE_35_BASE + 1);
}

u32 XPredict_Get_tree_35_BitWidth(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XPREDICT_TREE_WIDTH_TREE_35;
}

u32 XPredict_Get_tree_35_Depth(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XPREDICT_TREE_DEPTH_TREE_35;
}

u32 XPredict_Write_tree_35_Words(XPredict *InstancePtr, int offset, word_type *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length)*4 > (XPREDICT_TREE_ADDR_TREE_35_HIGH - XPREDICT_TREE_ADDR_TREE_35_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(int *)(InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_35_BASE + (offset + i)*4) = *(data + i);
    }
    return length;
}

u32 XPredict_Read_tree_35_Words(XPredict *InstancePtr, int offset, word_type *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length)*4 > (XPREDICT_TREE_ADDR_TREE_35_HIGH - XPREDICT_TREE_ADDR_TREE_35_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(data + i) = *(int *)(InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_35_BASE + (offset + i)*4);
    }
    return length;
}

u32 XPredict_Write_tree_35_Bytes(XPredict *InstancePtr, int offset, char *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length) > (XPREDICT_TREE_ADDR_TREE_35_HIGH - XPREDICT_TREE_ADDR_TREE_35_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(char *)(InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_35_BASE + offset + i) = *(data + i);
    }
    return length;
}

u32 XPredict_Read_tree_35_Bytes(XPredict *InstancePtr, int offset, char *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length) > (XPREDICT_TREE_ADDR_TREE_35_HIGH - XPREDICT_TREE_ADDR_TREE_35_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(data + i) = *(char *)(InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_35_BASE + offset + i);
    }
    return length;
}

u32 XPredict_Get_tree_36_BaseAddress(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_36_BASE);
}

u32 XPredict_Get_tree_36_HighAddress(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_36_HIGH);
}

u32 XPredict_Get_tree_36_TotalBytes(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (XPREDICT_TREE_ADDR_TREE_36_HIGH - XPREDICT_TREE_ADDR_TREE_36_BASE + 1);
}

u32 XPredict_Get_tree_36_BitWidth(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XPREDICT_TREE_WIDTH_TREE_36;
}

u32 XPredict_Get_tree_36_Depth(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XPREDICT_TREE_DEPTH_TREE_36;
}

u32 XPredict_Write_tree_36_Words(XPredict *InstancePtr, int offset, word_type *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length)*4 > (XPREDICT_TREE_ADDR_TREE_36_HIGH - XPREDICT_TREE_ADDR_TREE_36_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(int *)(InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_36_BASE + (offset + i)*4) = *(data + i);
    }
    return length;
}

u32 XPredict_Read_tree_36_Words(XPredict *InstancePtr, int offset, word_type *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length)*4 > (XPREDICT_TREE_ADDR_TREE_36_HIGH - XPREDICT_TREE_ADDR_TREE_36_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(data + i) = *(int *)(InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_36_BASE + (offset + i)*4);
    }
    return length;
}

u32 XPredict_Write_tree_36_Bytes(XPredict *InstancePtr, int offset, char *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length) > (XPREDICT_TREE_ADDR_TREE_36_HIGH - XPREDICT_TREE_ADDR_TREE_36_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(char *)(InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_36_BASE + offset + i) = *(data + i);
    }
    return length;
}

u32 XPredict_Read_tree_36_Bytes(XPredict *InstancePtr, int offset, char *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length) > (XPREDICT_TREE_ADDR_TREE_36_HIGH - XPREDICT_TREE_ADDR_TREE_36_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(data + i) = *(char *)(InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_36_BASE + offset + i);
    }
    return length;
}

u32 XPredict_Get_tree_37_BaseAddress(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_37_BASE);
}

u32 XPredict_Get_tree_37_HighAddress(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_37_HIGH);
}

u32 XPredict_Get_tree_37_TotalBytes(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (XPREDICT_TREE_ADDR_TREE_37_HIGH - XPREDICT_TREE_ADDR_TREE_37_BASE + 1);
}

u32 XPredict_Get_tree_37_BitWidth(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XPREDICT_TREE_WIDTH_TREE_37;
}

u32 XPredict_Get_tree_37_Depth(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XPREDICT_TREE_DEPTH_TREE_37;
}

u32 XPredict_Write_tree_37_Words(XPredict *InstancePtr, int offset, word_type *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length)*4 > (XPREDICT_TREE_ADDR_TREE_37_HIGH - XPREDICT_TREE_ADDR_TREE_37_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(int *)(InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_37_BASE + (offset + i)*4) = *(data + i);
    }
    return length;
}

u32 XPredict_Read_tree_37_Words(XPredict *InstancePtr, int offset, word_type *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length)*4 > (XPREDICT_TREE_ADDR_TREE_37_HIGH - XPREDICT_TREE_ADDR_TREE_37_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(data + i) = *(int *)(InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_37_BASE + (offset + i)*4);
    }
    return length;
}

u32 XPredict_Write_tree_37_Bytes(XPredict *InstancePtr, int offset, char *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length) > (XPREDICT_TREE_ADDR_TREE_37_HIGH - XPREDICT_TREE_ADDR_TREE_37_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(char *)(InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_37_BASE + offset + i) = *(data + i);
    }
    return length;
}

u32 XPredict_Read_tree_37_Bytes(XPredict *InstancePtr, int offset, char *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length) > (XPREDICT_TREE_ADDR_TREE_37_HIGH - XPREDICT_TREE_ADDR_TREE_37_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(data + i) = *(char *)(InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_37_BASE + offset + i);
    }
    return length;
}

u32 XPredict_Get_tree_38_BaseAddress(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_38_BASE);
}

u32 XPredict_Get_tree_38_HighAddress(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_38_HIGH);
}

u32 XPredict_Get_tree_38_TotalBytes(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (XPREDICT_TREE_ADDR_TREE_38_HIGH - XPREDICT_TREE_ADDR_TREE_38_BASE + 1);
}

u32 XPredict_Get_tree_38_BitWidth(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XPREDICT_TREE_WIDTH_TREE_38;
}

u32 XPredict_Get_tree_38_Depth(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XPREDICT_TREE_DEPTH_TREE_38;
}

u32 XPredict_Write_tree_38_Words(XPredict *InstancePtr, int offset, word_type *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length)*4 > (XPREDICT_TREE_ADDR_TREE_38_HIGH - XPREDICT_TREE_ADDR_TREE_38_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(int *)(InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_38_BASE + (offset + i)*4) = *(data + i);
    }
    return length;
}

u32 XPredict_Read_tree_38_Words(XPredict *InstancePtr, int offset, word_type *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length)*4 > (XPREDICT_TREE_ADDR_TREE_38_HIGH - XPREDICT_TREE_ADDR_TREE_38_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(data + i) = *(int *)(InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_38_BASE + (offset + i)*4);
    }
    return length;
}

u32 XPredict_Write_tree_38_Bytes(XPredict *InstancePtr, int offset, char *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length) > (XPREDICT_TREE_ADDR_TREE_38_HIGH - XPREDICT_TREE_ADDR_TREE_38_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(char *)(InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_38_BASE + offset + i) = *(data + i);
    }
    return length;
}

u32 XPredict_Read_tree_38_Bytes(XPredict *InstancePtr, int offset, char *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length) > (XPREDICT_TREE_ADDR_TREE_38_HIGH - XPREDICT_TREE_ADDR_TREE_38_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(data + i) = *(char *)(InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_38_BASE + offset + i);
    }
    return length;
}

u32 XPredict_Get_tree_39_BaseAddress(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_39_BASE);
}

u32 XPredict_Get_tree_39_HighAddress(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_39_HIGH);
}

u32 XPredict_Get_tree_39_TotalBytes(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (XPREDICT_TREE_ADDR_TREE_39_HIGH - XPREDICT_TREE_ADDR_TREE_39_BASE + 1);
}

u32 XPredict_Get_tree_39_BitWidth(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XPREDICT_TREE_WIDTH_TREE_39;
}

u32 XPredict_Get_tree_39_Depth(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XPREDICT_TREE_DEPTH_TREE_39;
}

u32 XPredict_Write_tree_39_Words(XPredict *InstancePtr, int offset, word_type *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length)*4 > (XPREDICT_TREE_ADDR_TREE_39_HIGH - XPREDICT_TREE_ADDR_TREE_39_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(int *)(InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_39_BASE + (offset + i)*4) = *(data + i);
    }
    return length;
}

u32 XPredict_Read_tree_39_Words(XPredict *InstancePtr, int offset, word_type *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length)*4 > (XPREDICT_TREE_ADDR_TREE_39_HIGH - XPREDICT_TREE_ADDR_TREE_39_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(data + i) = *(int *)(InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_39_BASE + (offset + i)*4);
    }
    return length;
}

u32 XPredict_Write_tree_39_Bytes(XPredict *InstancePtr, int offset, char *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length) > (XPREDICT_TREE_ADDR_TREE_39_HIGH - XPREDICT_TREE_ADDR_TREE_39_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(char *)(InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_39_BASE + offset + i) = *(data + i);
    }
    return length;
}

u32 XPredict_Read_tree_39_Bytes(XPredict *InstancePtr, int offset, char *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length) > (XPREDICT_TREE_ADDR_TREE_39_HIGH - XPREDICT_TREE_ADDR_TREE_39_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(data + i) = *(char *)(InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_39_BASE + offset + i);
    }
    return length;
}

u32 XPredict_Get_tree_40_BaseAddress(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_40_BASE);
}

u32 XPredict_Get_tree_40_HighAddress(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_40_HIGH);
}

u32 XPredict_Get_tree_40_TotalBytes(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (XPREDICT_TREE_ADDR_TREE_40_HIGH - XPREDICT_TREE_ADDR_TREE_40_BASE + 1);
}

u32 XPredict_Get_tree_40_BitWidth(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XPREDICT_TREE_WIDTH_TREE_40;
}

u32 XPredict_Get_tree_40_Depth(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XPREDICT_TREE_DEPTH_TREE_40;
}

u32 XPredict_Write_tree_40_Words(XPredict *InstancePtr, int offset, word_type *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length)*4 > (XPREDICT_TREE_ADDR_TREE_40_HIGH - XPREDICT_TREE_ADDR_TREE_40_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(int *)(InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_40_BASE + (offset + i)*4) = *(data + i);
    }
    return length;
}

u32 XPredict_Read_tree_40_Words(XPredict *InstancePtr, int offset, word_type *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length)*4 > (XPREDICT_TREE_ADDR_TREE_40_HIGH - XPREDICT_TREE_ADDR_TREE_40_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(data + i) = *(int *)(InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_40_BASE + (offset + i)*4);
    }
    return length;
}

u32 XPredict_Write_tree_40_Bytes(XPredict *InstancePtr, int offset, char *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length) > (XPREDICT_TREE_ADDR_TREE_40_HIGH - XPREDICT_TREE_ADDR_TREE_40_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(char *)(InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_40_BASE + offset + i) = *(data + i);
    }
    return length;
}

u32 XPredict_Read_tree_40_Bytes(XPredict *InstancePtr, int offset, char *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length) > (XPREDICT_TREE_ADDR_TREE_40_HIGH - XPREDICT_TREE_ADDR_TREE_40_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(data + i) = *(char *)(InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_40_BASE + offset + i);
    }
    return length;
}

u32 XPredict_Get_tree_41_BaseAddress(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_41_BASE);
}

u32 XPredict_Get_tree_41_HighAddress(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_41_HIGH);
}

u32 XPredict_Get_tree_41_TotalBytes(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (XPREDICT_TREE_ADDR_TREE_41_HIGH - XPREDICT_TREE_ADDR_TREE_41_BASE + 1);
}

u32 XPredict_Get_tree_41_BitWidth(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XPREDICT_TREE_WIDTH_TREE_41;
}

u32 XPredict_Get_tree_41_Depth(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XPREDICT_TREE_DEPTH_TREE_41;
}

u32 XPredict_Write_tree_41_Words(XPredict *InstancePtr, int offset, word_type *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length)*4 > (XPREDICT_TREE_ADDR_TREE_41_HIGH - XPREDICT_TREE_ADDR_TREE_41_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(int *)(InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_41_BASE + (offset + i)*4) = *(data + i);
    }
    return length;
}

u32 XPredict_Read_tree_41_Words(XPredict *InstancePtr, int offset, word_type *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length)*4 > (XPREDICT_TREE_ADDR_TREE_41_HIGH - XPREDICT_TREE_ADDR_TREE_41_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(data + i) = *(int *)(InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_41_BASE + (offset + i)*4);
    }
    return length;
}

u32 XPredict_Write_tree_41_Bytes(XPredict *InstancePtr, int offset, char *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length) > (XPREDICT_TREE_ADDR_TREE_41_HIGH - XPREDICT_TREE_ADDR_TREE_41_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(char *)(InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_41_BASE + offset + i) = *(data + i);
    }
    return length;
}

u32 XPredict_Read_tree_41_Bytes(XPredict *InstancePtr, int offset, char *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length) > (XPREDICT_TREE_ADDR_TREE_41_HIGH - XPREDICT_TREE_ADDR_TREE_41_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(data + i) = *(char *)(InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_41_BASE + offset + i);
    }
    return length;
}

u32 XPredict_Get_tree_42_BaseAddress(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_42_BASE);
}

u32 XPredict_Get_tree_42_HighAddress(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_42_HIGH);
}

u32 XPredict_Get_tree_42_TotalBytes(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (XPREDICT_TREE_ADDR_TREE_42_HIGH - XPREDICT_TREE_ADDR_TREE_42_BASE + 1);
}

u32 XPredict_Get_tree_42_BitWidth(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XPREDICT_TREE_WIDTH_TREE_42;
}

u32 XPredict_Get_tree_42_Depth(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XPREDICT_TREE_DEPTH_TREE_42;
}

u32 XPredict_Write_tree_42_Words(XPredict *InstancePtr, int offset, word_type *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length)*4 > (XPREDICT_TREE_ADDR_TREE_42_HIGH - XPREDICT_TREE_ADDR_TREE_42_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(int *)(InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_42_BASE + (offset + i)*4) = *(data + i);
    }
    return length;
}

u32 XPredict_Read_tree_42_Words(XPredict *InstancePtr, int offset, word_type *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length)*4 > (XPREDICT_TREE_ADDR_TREE_42_HIGH - XPREDICT_TREE_ADDR_TREE_42_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(data + i) = *(int *)(InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_42_BASE + (offset + i)*4);
    }
    return length;
}

u32 XPredict_Write_tree_42_Bytes(XPredict *InstancePtr, int offset, char *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length) > (XPREDICT_TREE_ADDR_TREE_42_HIGH - XPREDICT_TREE_ADDR_TREE_42_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(char *)(InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_42_BASE + offset + i) = *(data + i);
    }
    return length;
}

u32 XPredict_Read_tree_42_Bytes(XPredict *InstancePtr, int offset, char *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length) > (XPREDICT_TREE_ADDR_TREE_42_HIGH - XPREDICT_TREE_ADDR_TREE_42_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(data + i) = *(char *)(InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_42_BASE + offset + i);
    }
    return length;
}

u32 XPredict_Get_tree_43_BaseAddress(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_43_BASE);
}

u32 XPredict_Get_tree_43_HighAddress(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_43_HIGH);
}

u32 XPredict_Get_tree_43_TotalBytes(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (XPREDICT_TREE_ADDR_TREE_43_HIGH - XPREDICT_TREE_ADDR_TREE_43_BASE + 1);
}

u32 XPredict_Get_tree_43_BitWidth(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XPREDICT_TREE_WIDTH_TREE_43;
}

u32 XPredict_Get_tree_43_Depth(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XPREDICT_TREE_DEPTH_TREE_43;
}

u32 XPredict_Write_tree_43_Words(XPredict *InstancePtr, int offset, word_type *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length)*4 > (XPREDICT_TREE_ADDR_TREE_43_HIGH - XPREDICT_TREE_ADDR_TREE_43_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(int *)(InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_43_BASE + (offset + i)*4) = *(data + i);
    }
    return length;
}

u32 XPredict_Read_tree_43_Words(XPredict *InstancePtr, int offset, word_type *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length)*4 > (XPREDICT_TREE_ADDR_TREE_43_HIGH - XPREDICT_TREE_ADDR_TREE_43_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(data + i) = *(int *)(InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_43_BASE + (offset + i)*4);
    }
    return length;
}

u32 XPredict_Write_tree_43_Bytes(XPredict *InstancePtr, int offset, char *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length) > (XPREDICT_TREE_ADDR_TREE_43_HIGH - XPREDICT_TREE_ADDR_TREE_43_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(char *)(InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_43_BASE + offset + i) = *(data + i);
    }
    return length;
}

u32 XPredict_Read_tree_43_Bytes(XPredict *InstancePtr, int offset, char *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length) > (XPREDICT_TREE_ADDR_TREE_43_HIGH - XPREDICT_TREE_ADDR_TREE_43_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(data + i) = *(char *)(InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_43_BASE + offset + i);
    }
    return length;
}

u32 XPredict_Get_tree_44_BaseAddress(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_44_BASE);
}

u32 XPredict_Get_tree_44_HighAddress(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_44_HIGH);
}

u32 XPredict_Get_tree_44_TotalBytes(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (XPREDICT_TREE_ADDR_TREE_44_HIGH - XPREDICT_TREE_ADDR_TREE_44_BASE + 1);
}

u32 XPredict_Get_tree_44_BitWidth(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XPREDICT_TREE_WIDTH_TREE_44;
}

u32 XPredict_Get_tree_44_Depth(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XPREDICT_TREE_DEPTH_TREE_44;
}

u32 XPredict_Write_tree_44_Words(XPredict *InstancePtr, int offset, word_type *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length)*4 > (XPREDICT_TREE_ADDR_TREE_44_HIGH - XPREDICT_TREE_ADDR_TREE_44_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(int *)(InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_44_BASE + (offset + i)*4) = *(data + i);
    }
    return length;
}

u32 XPredict_Read_tree_44_Words(XPredict *InstancePtr, int offset, word_type *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length)*4 > (XPREDICT_TREE_ADDR_TREE_44_HIGH - XPREDICT_TREE_ADDR_TREE_44_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(data + i) = *(int *)(InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_44_BASE + (offset + i)*4);
    }
    return length;
}

u32 XPredict_Write_tree_44_Bytes(XPredict *InstancePtr, int offset, char *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length) > (XPREDICT_TREE_ADDR_TREE_44_HIGH - XPREDICT_TREE_ADDR_TREE_44_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(char *)(InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_44_BASE + offset + i) = *(data + i);
    }
    return length;
}

u32 XPredict_Read_tree_44_Bytes(XPredict *InstancePtr, int offset, char *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length) > (XPREDICT_TREE_ADDR_TREE_44_HIGH - XPREDICT_TREE_ADDR_TREE_44_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(data + i) = *(char *)(InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_44_BASE + offset + i);
    }
    return length;
}

u32 XPredict_Get_tree_45_BaseAddress(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_45_BASE);
}

u32 XPredict_Get_tree_45_HighAddress(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_45_HIGH);
}

u32 XPredict_Get_tree_45_TotalBytes(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (XPREDICT_TREE_ADDR_TREE_45_HIGH - XPREDICT_TREE_ADDR_TREE_45_BASE + 1);
}

u32 XPredict_Get_tree_45_BitWidth(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XPREDICT_TREE_WIDTH_TREE_45;
}

u32 XPredict_Get_tree_45_Depth(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XPREDICT_TREE_DEPTH_TREE_45;
}

u32 XPredict_Write_tree_45_Words(XPredict *InstancePtr, int offset, word_type *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length)*4 > (XPREDICT_TREE_ADDR_TREE_45_HIGH - XPREDICT_TREE_ADDR_TREE_45_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(int *)(InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_45_BASE + (offset + i)*4) = *(data + i);
    }
    return length;
}

u32 XPredict_Read_tree_45_Words(XPredict *InstancePtr, int offset, word_type *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length)*4 > (XPREDICT_TREE_ADDR_TREE_45_HIGH - XPREDICT_TREE_ADDR_TREE_45_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(data + i) = *(int *)(InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_45_BASE + (offset + i)*4);
    }
    return length;
}

u32 XPredict_Write_tree_45_Bytes(XPredict *InstancePtr, int offset, char *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length) > (XPREDICT_TREE_ADDR_TREE_45_HIGH - XPREDICT_TREE_ADDR_TREE_45_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(char *)(InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_45_BASE + offset + i) = *(data + i);
    }
    return length;
}

u32 XPredict_Read_tree_45_Bytes(XPredict *InstancePtr, int offset, char *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length) > (XPREDICT_TREE_ADDR_TREE_45_HIGH - XPREDICT_TREE_ADDR_TREE_45_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(data + i) = *(char *)(InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_45_BASE + offset + i);
    }
    return length;
}

u32 XPredict_Get_tree_46_BaseAddress(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_46_BASE);
}

u32 XPredict_Get_tree_46_HighAddress(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_46_HIGH);
}

u32 XPredict_Get_tree_46_TotalBytes(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (XPREDICT_TREE_ADDR_TREE_46_HIGH - XPREDICT_TREE_ADDR_TREE_46_BASE + 1);
}

u32 XPredict_Get_tree_46_BitWidth(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XPREDICT_TREE_WIDTH_TREE_46;
}

u32 XPredict_Get_tree_46_Depth(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XPREDICT_TREE_DEPTH_TREE_46;
}

u32 XPredict_Write_tree_46_Words(XPredict *InstancePtr, int offset, word_type *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length)*4 > (XPREDICT_TREE_ADDR_TREE_46_HIGH - XPREDICT_TREE_ADDR_TREE_46_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(int *)(InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_46_BASE + (offset + i)*4) = *(data + i);
    }
    return length;
}

u32 XPredict_Read_tree_46_Words(XPredict *InstancePtr, int offset, word_type *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length)*4 > (XPREDICT_TREE_ADDR_TREE_46_HIGH - XPREDICT_TREE_ADDR_TREE_46_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(data + i) = *(int *)(InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_46_BASE + (offset + i)*4);
    }
    return length;
}

u32 XPredict_Write_tree_46_Bytes(XPredict *InstancePtr, int offset, char *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length) > (XPREDICT_TREE_ADDR_TREE_46_HIGH - XPREDICT_TREE_ADDR_TREE_46_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(char *)(InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_46_BASE + offset + i) = *(data + i);
    }
    return length;
}

u32 XPredict_Read_tree_46_Bytes(XPredict *InstancePtr, int offset, char *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length) > (XPREDICT_TREE_ADDR_TREE_46_HIGH - XPREDICT_TREE_ADDR_TREE_46_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(data + i) = *(char *)(InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_46_BASE + offset + i);
    }
    return length;
}

u32 XPredict_Get_tree_47_BaseAddress(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_47_BASE);
}

u32 XPredict_Get_tree_47_HighAddress(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_47_HIGH);
}

u32 XPredict_Get_tree_47_TotalBytes(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (XPREDICT_TREE_ADDR_TREE_47_HIGH - XPREDICT_TREE_ADDR_TREE_47_BASE + 1);
}

u32 XPredict_Get_tree_47_BitWidth(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XPREDICT_TREE_WIDTH_TREE_47;
}

u32 XPredict_Get_tree_47_Depth(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XPREDICT_TREE_DEPTH_TREE_47;
}

u32 XPredict_Write_tree_47_Words(XPredict *InstancePtr, int offset, word_type *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length)*4 > (XPREDICT_TREE_ADDR_TREE_47_HIGH - XPREDICT_TREE_ADDR_TREE_47_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(int *)(InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_47_BASE + (offset + i)*4) = *(data + i);
    }
    return length;
}

u32 XPredict_Read_tree_47_Words(XPredict *InstancePtr, int offset, word_type *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length)*4 > (XPREDICT_TREE_ADDR_TREE_47_HIGH - XPREDICT_TREE_ADDR_TREE_47_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(data + i) = *(int *)(InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_47_BASE + (offset + i)*4);
    }
    return length;
}

u32 XPredict_Write_tree_47_Bytes(XPredict *InstancePtr, int offset, char *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length) > (XPREDICT_TREE_ADDR_TREE_47_HIGH - XPREDICT_TREE_ADDR_TREE_47_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(char *)(InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_47_BASE + offset + i) = *(data + i);
    }
    return length;
}

u32 XPredict_Read_tree_47_Bytes(XPredict *InstancePtr, int offset, char *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length) > (XPREDICT_TREE_ADDR_TREE_47_HIGH - XPREDICT_TREE_ADDR_TREE_47_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(data + i) = *(char *)(InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_47_BASE + offset + i);
    }
    return length;
}

u32 XPredict_Get_tree_48_BaseAddress(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_48_BASE);
}

u32 XPredict_Get_tree_48_HighAddress(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_48_HIGH);
}

u32 XPredict_Get_tree_48_TotalBytes(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (XPREDICT_TREE_ADDR_TREE_48_HIGH - XPREDICT_TREE_ADDR_TREE_48_BASE + 1);
}

u32 XPredict_Get_tree_48_BitWidth(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XPREDICT_TREE_WIDTH_TREE_48;
}

u32 XPredict_Get_tree_48_Depth(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XPREDICT_TREE_DEPTH_TREE_48;
}

u32 XPredict_Write_tree_48_Words(XPredict *InstancePtr, int offset, word_type *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length)*4 > (XPREDICT_TREE_ADDR_TREE_48_HIGH - XPREDICT_TREE_ADDR_TREE_48_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(int *)(InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_48_BASE + (offset + i)*4) = *(data + i);
    }
    return length;
}

u32 XPredict_Read_tree_48_Words(XPredict *InstancePtr, int offset, word_type *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length)*4 > (XPREDICT_TREE_ADDR_TREE_48_HIGH - XPREDICT_TREE_ADDR_TREE_48_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(data + i) = *(int *)(InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_48_BASE + (offset + i)*4);
    }
    return length;
}

u32 XPredict_Write_tree_48_Bytes(XPredict *InstancePtr, int offset, char *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length) > (XPREDICT_TREE_ADDR_TREE_48_HIGH - XPREDICT_TREE_ADDR_TREE_48_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(char *)(InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_48_BASE + offset + i) = *(data + i);
    }
    return length;
}

u32 XPredict_Read_tree_48_Bytes(XPredict *InstancePtr, int offset, char *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length) > (XPREDICT_TREE_ADDR_TREE_48_HIGH - XPREDICT_TREE_ADDR_TREE_48_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(data + i) = *(char *)(InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_48_BASE + offset + i);
    }
    return length;
}

u32 XPredict_Get_tree_49_BaseAddress(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_49_BASE);
}

u32 XPredict_Get_tree_49_HighAddress(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_49_HIGH);
}

u32 XPredict_Get_tree_49_TotalBytes(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (XPREDICT_TREE_ADDR_TREE_49_HIGH - XPREDICT_TREE_ADDR_TREE_49_BASE + 1);
}

u32 XPredict_Get_tree_49_BitWidth(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XPREDICT_TREE_WIDTH_TREE_49;
}

u32 XPredict_Get_tree_49_Depth(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XPREDICT_TREE_DEPTH_TREE_49;
}

u32 XPredict_Write_tree_49_Words(XPredict *InstancePtr, int offset, word_type *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length)*4 > (XPREDICT_TREE_ADDR_TREE_49_HIGH - XPREDICT_TREE_ADDR_TREE_49_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(int *)(InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_49_BASE + (offset + i)*4) = *(data + i);
    }
    return length;
}

u32 XPredict_Read_tree_49_Words(XPredict *InstancePtr, int offset, word_type *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length)*4 > (XPREDICT_TREE_ADDR_TREE_49_HIGH - XPREDICT_TREE_ADDR_TREE_49_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(data + i) = *(int *)(InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_49_BASE + (offset + i)*4);
    }
    return length;
}

u32 XPredict_Write_tree_49_Bytes(XPredict *InstancePtr, int offset, char *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length) > (XPREDICT_TREE_ADDR_TREE_49_HIGH - XPREDICT_TREE_ADDR_TREE_49_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(char *)(InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_49_BASE + offset + i) = *(data + i);
    }
    return length;
}

u32 XPredict_Read_tree_49_Bytes(XPredict *InstancePtr, int offset, char *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length) > (XPREDICT_TREE_ADDR_TREE_49_HIGH - XPREDICT_TREE_ADDR_TREE_49_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(data + i) = *(char *)(InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_49_BASE + offset + i);
    }
    return length;
}

u32 XPredict_Get_tree_50_BaseAddress(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_50_BASE);
}

u32 XPredict_Get_tree_50_HighAddress(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_50_HIGH);
}

u32 XPredict_Get_tree_50_TotalBytes(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (XPREDICT_TREE_ADDR_TREE_50_HIGH - XPREDICT_TREE_ADDR_TREE_50_BASE + 1);
}

u32 XPredict_Get_tree_50_BitWidth(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XPREDICT_TREE_WIDTH_TREE_50;
}

u32 XPredict_Get_tree_50_Depth(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XPREDICT_TREE_DEPTH_TREE_50;
}

u32 XPredict_Write_tree_50_Words(XPredict *InstancePtr, int offset, word_type *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length)*4 > (XPREDICT_TREE_ADDR_TREE_50_HIGH - XPREDICT_TREE_ADDR_TREE_50_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(int *)(InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_50_BASE + (offset + i)*4) = *(data + i);
    }
    return length;
}

u32 XPredict_Read_tree_50_Words(XPredict *InstancePtr, int offset, word_type *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length)*4 > (XPREDICT_TREE_ADDR_TREE_50_HIGH - XPREDICT_TREE_ADDR_TREE_50_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(data + i) = *(int *)(InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_50_BASE + (offset + i)*4);
    }
    return length;
}

u32 XPredict_Write_tree_50_Bytes(XPredict *InstancePtr, int offset, char *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length) > (XPREDICT_TREE_ADDR_TREE_50_HIGH - XPREDICT_TREE_ADDR_TREE_50_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(char *)(InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_50_BASE + offset + i) = *(data + i);
    }
    return length;
}

u32 XPredict_Read_tree_50_Bytes(XPredict *InstancePtr, int offset, char *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length) > (XPREDICT_TREE_ADDR_TREE_50_HIGH - XPREDICT_TREE_ADDR_TREE_50_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(data + i) = *(char *)(InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_50_BASE + offset + i);
    }
    return length;
}

u32 XPredict_Get_tree_51_BaseAddress(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_51_BASE);
}

u32 XPredict_Get_tree_51_HighAddress(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_51_HIGH);
}

u32 XPredict_Get_tree_51_TotalBytes(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (XPREDICT_TREE_ADDR_TREE_51_HIGH - XPREDICT_TREE_ADDR_TREE_51_BASE + 1);
}

u32 XPredict_Get_tree_51_BitWidth(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XPREDICT_TREE_WIDTH_TREE_51;
}

u32 XPredict_Get_tree_51_Depth(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XPREDICT_TREE_DEPTH_TREE_51;
}

u32 XPredict_Write_tree_51_Words(XPredict *InstancePtr, int offset, word_type *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length)*4 > (XPREDICT_TREE_ADDR_TREE_51_HIGH - XPREDICT_TREE_ADDR_TREE_51_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(int *)(InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_51_BASE + (offset + i)*4) = *(data + i);
    }
    return length;
}

u32 XPredict_Read_tree_51_Words(XPredict *InstancePtr, int offset, word_type *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length)*4 > (XPREDICT_TREE_ADDR_TREE_51_HIGH - XPREDICT_TREE_ADDR_TREE_51_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(data + i) = *(int *)(InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_51_BASE + (offset + i)*4);
    }
    return length;
}

u32 XPredict_Write_tree_51_Bytes(XPredict *InstancePtr, int offset, char *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length) > (XPREDICT_TREE_ADDR_TREE_51_HIGH - XPREDICT_TREE_ADDR_TREE_51_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(char *)(InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_51_BASE + offset + i) = *(data + i);
    }
    return length;
}

u32 XPredict_Read_tree_51_Bytes(XPredict *InstancePtr, int offset, char *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length) > (XPREDICT_TREE_ADDR_TREE_51_HIGH - XPREDICT_TREE_ADDR_TREE_51_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(data + i) = *(char *)(InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_51_BASE + offset + i);
    }
    return length;
}

u32 XPredict_Get_tree_52_BaseAddress(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_52_BASE);
}

u32 XPredict_Get_tree_52_HighAddress(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_52_HIGH);
}

u32 XPredict_Get_tree_52_TotalBytes(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (XPREDICT_TREE_ADDR_TREE_52_HIGH - XPREDICT_TREE_ADDR_TREE_52_BASE + 1);
}

u32 XPredict_Get_tree_52_BitWidth(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XPREDICT_TREE_WIDTH_TREE_52;
}

u32 XPredict_Get_tree_52_Depth(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XPREDICT_TREE_DEPTH_TREE_52;
}

u32 XPredict_Write_tree_52_Words(XPredict *InstancePtr, int offset, word_type *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length)*4 > (XPREDICT_TREE_ADDR_TREE_52_HIGH - XPREDICT_TREE_ADDR_TREE_52_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(int *)(InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_52_BASE + (offset + i)*4) = *(data + i);
    }
    return length;
}

u32 XPredict_Read_tree_52_Words(XPredict *InstancePtr, int offset, word_type *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length)*4 > (XPREDICT_TREE_ADDR_TREE_52_HIGH - XPREDICT_TREE_ADDR_TREE_52_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(data + i) = *(int *)(InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_52_BASE + (offset + i)*4);
    }
    return length;
}

u32 XPredict_Write_tree_52_Bytes(XPredict *InstancePtr, int offset, char *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length) > (XPREDICT_TREE_ADDR_TREE_52_HIGH - XPREDICT_TREE_ADDR_TREE_52_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(char *)(InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_52_BASE + offset + i) = *(data + i);
    }
    return length;
}

u32 XPredict_Read_tree_52_Bytes(XPredict *InstancePtr, int offset, char *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length) > (XPREDICT_TREE_ADDR_TREE_52_HIGH - XPREDICT_TREE_ADDR_TREE_52_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(data + i) = *(char *)(InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_52_BASE + offset + i);
    }
    return length;
}

u32 XPredict_Get_tree_53_BaseAddress(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_53_BASE);
}

u32 XPredict_Get_tree_53_HighAddress(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_53_HIGH);
}

u32 XPredict_Get_tree_53_TotalBytes(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (XPREDICT_TREE_ADDR_TREE_53_HIGH - XPREDICT_TREE_ADDR_TREE_53_BASE + 1);
}

u32 XPredict_Get_tree_53_BitWidth(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XPREDICT_TREE_WIDTH_TREE_53;
}

u32 XPredict_Get_tree_53_Depth(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XPREDICT_TREE_DEPTH_TREE_53;
}

u32 XPredict_Write_tree_53_Words(XPredict *InstancePtr, int offset, word_type *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length)*4 > (XPREDICT_TREE_ADDR_TREE_53_HIGH - XPREDICT_TREE_ADDR_TREE_53_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(int *)(InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_53_BASE + (offset + i)*4) = *(data + i);
    }
    return length;
}

u32 XPredict_Read_tree_53_Words(XPredict *InstancePtr, int offset, word_type *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length)*4 > (XPREDICT_TREE_ADDR_TREE_53_HIGH - XPREDICT_TREE_ADDR_TREE_53_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(data + i) = *(int *)(InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_53_BASE + (offset + i)*4);
    }
    return length;
}

u32 XPredict_Write_tree_53_Bytes(XPredict *InstancePtr, int offset, char *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length) > (XPREDICT_TREE_ADDR_TREE_53_HIGH - XPREDICT_TREE_ADDR_TREE_53_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(char *)(InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_53_BASE + offset + i) = *(data + i);
    }
    return length;
}

u32 XPredict_Read_tree_53_Bytes(XPredict *InstancePtr, int offset, char *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length) > (XPREDICT_TREE_ADDR_TREE_53_HIGH - XPREDICT_TREE_ADDR_TREE_53_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(data + i) = *(char *)(InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_53_BASE + offset + i);
    }
    return length;
}

u32 XPredict_Get_tree_54_BaseAddress(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_54_BASE);
}

u32 XPredict_Get_tree_54_HighAddress(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_54_HIGH);
}

u32 XPredict_Get_tree_54_TotalBytes(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (XPREDICT_TREE_ADDR_TREE_54_HIGH - XPREDICT_TREE_ADDR_TREE_54_BASE + 1);
}

u32 XPredict_Get_tree_54_BitWidth(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XPREDICT_TREE_WIDTH_TREE_54;
}

u32 XPredict_Get_tree_54_Depth(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XPREDICT_TREE_DEPTH_TREE_54;
}

u32 XPredict_Write_tree_54_Words(XPredict *InstancePtr, int offset, word_type *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length)*4 > (XPREDICT_TREE_ADDR_TREE_54_HIGH - XPREDICT_TREE_ADDR_TREE_54_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(int *)(InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_54_BASE + (offset + i)*4) = *(data + i);
    }
    return length;
}

u32 XPredict_Read_tree_54_Words(XPredict *InstancePtr, int offset, word_type *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length)*4 > (XPREDICT_TREE_ADDR_TREE_54_HIGH - XPREDICT_TREE_ADDR_TREE_54_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(data + i) = *(int *)(InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_54_BASE + (offset + i)*4);
    }
    return length;
}

u32 XPredict_Write_tree_54_Bytes(XPredict *InstancePtr, int offset, char *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length) > (XPREDICT_TREE_ADDR_TREE_54_HIGH - XPREDICT_TREE_ADDR_TREE_54_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(char *)(InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_54_BASE + offset + i) = *(data + i);
    }
    return length;
}

u32 XPredict_Read_tree_54_Bytes(XPredict *InstancePtr, int offset, char *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length) > (XPREDICT_TREE_ADDR_TREE_54_HIGH - XPREDICT_TREE_ADDR_TREE_54_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(data + i) = *(char *)(InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_54_BASE + offset + i);
    }
    return length;
}

u32 XPredict_Get_tree_55_BaseAddress(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_55_BASE);
}

u32 XPredict_Get_tree_55_HighAddress(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_55_HIGH);
}

u32 XPredict_Get_tree_55_TotalBytes(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (XPREDICT_TREE_ADDR_TREE_55_HIGH - XPREDICT_TREE_ADDR_TREE_55_BASE + 1);
}

u32 XPredict_Get_tree_55_BitWidth(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XPREDICT_TREE_WIDTH_TREE_55;
}

u32 XPredict_Get_tree_55_Depth(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XPREDICT_TREE_DEPTH_TREE_55;
}

u32 XPredict_Write_tree_55_Words(XPredict *InstancePtr, int offset, word_type *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length)*4 > (XPREDICT_TREE_ADDR_TREE_55_HIGH - XPREDICT_TREE_ADDR_TREE_55_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(int *)(InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_55_BASE + (offset + i)*4) = *(data + i);
    }
    return length;
}

u32 XPredict_Read_tree_55_Words(XPredict *InstancePtr, int offset, word_type *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length)*4 > (XPREDICT_TREE_ADDR_TREE_55_HIGH - XPREDICT_TREE_ADDR_TREE_55_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(data + i) = *(int *)(InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_55_BASE + (offset + i)*4);
    }
    return length;
}

u32 XPredict_Write_tree_55_Bytes(XPredict *InstancePtr, int offset, char *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length) > (XPREDICT_TREE_ADDR_TREE_55_HIGH - XPREDICT_TREE_ADDR_TREE_55_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(char *)(InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_55_BASE + offset + i) = *(data + i);
    }
    return length;
}

u32 XPredict_Read_tree_55_Bytes(XPredict *InstancePtr, int offset, char *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length) > (XPREDICT_TREE_ADDR_TREE_55_HIGH - XPREDICT_TREE_ADDR_TREE_55_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(data + i) = *(char *)(InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_55_BASE + offset + i);
    }
    return length;
}

u32 XPredict_Get_tree_56_BaseAddress(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_56_BASE);
}

u32 XPredict_Get_tree_56_HighAddress(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_56_HIGH);
}

u32 XPredict_Get_tree_56_TotalBytes(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (XPREDICT_TREE_ADDR_TREE_56_HIGH - XPREDICT_TREE_ADDR_TREE_56_BASE + 1);
}

u32 XPredict_Get_tree_56_BitWidth(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XPREDICT_TREE_WIDTH_TREE_56;
}

u32 XPredict_Get_tree_56_Depth(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XPREDICT_TREE_DEPTH_TREE_56;
}

u32 XPredict_Write_tree_56_Words(XPredict *InstancePtr, int offset, word_type *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length)*4 > (XPREDICT_TREE_ADDR_TREE_56_HIGH - XPREDICT_TREE_ADDR_TREE_56_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(int *)(InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_56_BASE + (offset + i)*4) = *(data + i);
    }
    return length;
}

u32 XPredict_Read_tree_56_Words(XPredict *InstancePtr, int offset, word_type *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length)*4 > (XPREDICT_TREE_ADDR_TREE_56_HIGH - XPREDICT_TREE_ADDR_TREE_56_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(data + i) = *(int *)(InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_56_BASE + (offset + i)*4);
    }
    return length;
}

u32 XPredict_Write_tree_56_Bytes(XPredict *InstancePtr, int offset, char *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length) > (XPREDICT_TREE_ADDR_TREE_56_HIGH - XPREDICT_TREE_ADDR_TREE_56_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(char *)(InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_56_BASE + offset + i) = *(data + i);
    }
    return length;
}

u32 XPredict_Read_tree_56_Bytes(XPredict *InstancePtr, int offset, char *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length) > (XPREDICT_TREE_ADDR_TREE_56_HIGH - XPREDICT_TREE_ADDR_TREE_56_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(data + i) = *(char *)(InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_56_BASE + offset + i);
    }
    return length;
}

u32 XPredict_Get_tree_57_BaseAddress(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_57_BASE);
}

u32 XPredict_Get_tree_57_HighAddress(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_57_HIGH);
}

u32 XPredict_Get_tree_57_TotalBytes(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (XPREDICT_TREE_ADDR_TREE_57_HIGH - XPREDICT_TREE_ADDR_TREE_57_BASE + 1);
}

u32 XPredict_Get_tree_57_BitWidth(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XPREDICT_TREE_WIDTH_TREE_57;
}

u32 XPredict_Get_tree_57_Depth(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XPREDICT_TREE_DEPTH_TREE_57;
}

u32 XPredict_Write_tree_57_Words(XPredict *InstancePtr, int offset, word_type *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length)*4 > (XPREDICT_TREE_ADDR_TREE_57_HIGH - XPREDICT_TREE_ADDR_TREE_57_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(int *)(InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_57_BASE + (offset + i)*4) = *(data + i);
    }
    return length;
}

u32 XPredict_Read_tree_57_Words(XPredict *InstancePtr, int offset, word_type *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length)*4 > (XPREDICT_TREE_ADDR_TREE_57_HIGH - XPREDICT_TREE_ADDR_TREE_57_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(data + i) = *(int *)(InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_57_BASE + (offset + i)*4);
    }
    return length;
}

u32 XPredict_Write_tree_57_Bytes(XPredict *InstancePtr, int offset, char *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length) > (XPREDICT_TREE_ADDR_TREE_57_HIGH - XPREDICT_TREE_ADDR_TREE_57_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(char *)(InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_57_BASE + offset + i) = *(data + i);
    }
    return length;
}

u32 XPredict_Read_tree_57_Bytes(XPredict *InstancePtr, int offset, char *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length) > (XPREDICT_TREE_ADDR_TREE_57_HIGH - XPREDICT_TREE_ADDR_TREE_57_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(data + i) = *(char *)(InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_57_BASE + offset + i);
    }
    return length;
}

u32 XPredict_Get_tree_58_BaseAddress(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_58_BASE);
}

u32 XPredict_Get_tree_58_HighAddress(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_58_HIGH);
}

u32 XPredict_Get_tree_58_TotalBytes(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (XPREDICT_TREE_ADDR_TREE_58_HIGH - XPREDICT_TREE_ADDR_TREE_58_BASE + 1);
}

u32 XPredict_Get_tree_58_BitWidth(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XPREDICT_TREE_WIDTH_TREE_58;
}

u32 XPredict_Get_tree_58_Depth(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XPREDICT_TREE_DEPTH_TREE_58;
}

u32 XPredict_Write_tree_58_Words(XPredict *InstancePtr, int offset, word_type *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length)*4 > (XPREDICT_TREE_ADDR_TREE_58_HIGH - XPREDICT_TREE_ADDR_TREE_58_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(int *)(InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_58_BASE + (offset + i)*4) = *(data + i);
    }
    return length;
}

u32 XPredict_Read_tree_58_Words(XPredict *InstancePtr, int offset, word_type *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length)*4 > (XPREDICT_TREE_ADDR_TREE_58_HIGH - XPREDICT_TREE_ADDR_TREE_58_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(data + i) = *(int *)(InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_58_BASE + (offset + i)*4);
    }
    return length;
}

u32 XPredict_Write_tree_58_Bytes(XPredict *InstancePtr, int offset, char *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length) > (XPREDICT_TREE_ADDR_TREE_58_HIGH - XPREDICT_TREE_ADDR_TREE_58_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(char *)(InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_58_BASE + offset + i) = *(data + i);
    }
    return length;
}

u32 XPredict_Read_tree_58_Bytes(XPredict *InstancePtr, int offset, char *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length) > (XPREDICT_TREE_ADDR_TREE_58_HIGH - XPREDICT_TREE_ADDR_TREE_58_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(data + i) = *(char *)(InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_58_BASE + offset + i);
    }
    return length;
}

u32 XPredict_Get_tree_59_BaseAddress(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_59_BASE);
}

u32 XPredict_Get_tree_59_HighAddress(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_59_HIGH);
}

u32 XPredict_Get_tree_59_TotalBytes(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (XPREDICT_TREE_ADDR_TREE_59_HIGH - XPREDICT_TREE_ADDR_TREE_59_BASE + 1);
}

u32 XPredict_Get_tree_59_BitWidth(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XPREDICT_TREE_WIDTH_TREE_59;
}

u32 XPredict_Get_tree_59_Depth(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XPREDICT_TREE_DEPTH_TREE_59;
}

u32 XPredict_Write_tree_59_Words(XPredict *InstancePtr, int offset, word_type *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length)*4 > (XPREDICT_TREE_ADDR_TREE_59_HIGH - XPREDICT_TREE_ADDR_TREE_59_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(int *)(InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_59_BASE + (offset + i)*4) = *(data + i);
    }
    return length;
}

u32 XPredict_Read_tree_59_Words(XPredict *InstancePtr, int offset, word_type *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length)*4 > (XPREDICT_TREE_ADDR_TREE_59_HIGH - XPREDICT_TREE_ADDR_TREE_59_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(data + i) = *(int *)(InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_59_BASE + (offset + i)*4);
    }
    return length;
}

u32 XPredict_Write_tree_59_Bytes(XPredict *InstancePtr, int offset, char *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length) > (XPREDICT_TREE_ADDR_TREE_59_HIGH - XPREDICT_TREE_ADDR_TREE_59_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(char *)(InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_59_BASE + offset + i) = *(data + i);
    }
    return length;
}

u32 XPredict_Read_tree_59_Bytes(XPredict *InstancePtr, int offset, char *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length) > (XPREDICT_TREE_ADDR_TREE_59_HIGH - XPREDICT_TREE_ADDR_TREE_59_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(data + i) = *(char *)(InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_59_BASE + offset + i);
    }
    return length;
}

u32 XPredict_Get_tree_60_BaseAddress(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_60_BASE);
}

u32 XPredict_Get_tree_60_HighAddress(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_60_HIGH);
}

u32 XPredict_Get_tree_60_TotalBytes(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (XPREDICT_TREE_ADDR_TREE_60_HIGH - XPREDICT_TREE_ADDR_TREE_60_BASE + 1);
}

u32 XPredict_Get_tree_60_BitWidth(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XPREDICT_TREE_WIDTH_TREE_60;
}

u32 XPredict_Get_tree_60_Depth(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XPREDICT_TREE_DEPTH_TREE_60;
}

u32 XPredict_Write_tree_60_Words(XPredict *InstancePtr, int offset, word_type *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length)*4 > (XPREDICT_TREE_ADDR_TREE_60_HIGH - XPREDICT_TREE_ADDR_TREE_60_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(int *)(InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_60_BASE + (offset + i)*4) = *(data + i);
    }
    return length;
}

u32 XPredict_Read_tree_60_Words(XPredict *InstancePtr, int offset, word_type *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length)*4 > (XPREDICT_TREE_ADDR_TREE_60_HIGH - XPREDICT_TREE_ADDR_TREE_60_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(data + i) = *(int *)(InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_60_BASE + (offset + i)*4);
    }
    return length;
}

u32 XPredict_Write_tree_60_Bytes(XPredict *InstancePtr, int offset, char *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length) > (XPREDICT_TREE_ADDR_TREE_60_HIGH - XPREDICT_TREE_ADDR_TREE_60_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(char *)(InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_60_BASE + offset + i) = *(data + i);
    }
    return length;
}

u32 XPredict_Read_tree_60_Bytes(XPredict *InstancePtr, int offset, char *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length) > (XPREDICT_TREE_ADDR_TREE_60_HIGH - XPREDICT_TREE_ADDR_TREE_60_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(data + i) = *(char *)(InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_60_BASE + offset + i);
    }
    return length;
}

u32 XPredict_Get_tree_61_BaseAddress(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_61_BASE);
}

u32 XPredict_Get_tree_61_HighAddress(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_61_HIGH);
}

u32 XPredict_Get_tree_61_TotalBytes(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (XPREDICT_TREE_ADDR_TREE_61_HIGH - XPREDICT_TREE_ADDR_TREE_61_BASE + 1);
}

u32 XPredict_Get_tree_61_BitWidth(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XPREDICT_TREE_WIDTH_TREE_61;
}

u32 XPredict_Get_tree_61_Depth(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XPREDICT_TREE_DEPTH_TREE_61;
}

u32 XPredict_Write_tree_61_Words(XPredict *InstancePtr, int offset, word_type *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length)*4 > (XPREDICT_TREE_ADDR_TREE_61_HIGH - XPREDICT_TREE_ADDR_TREE_61_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(int *)(InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_61_BASE + (offset + i)*4) = *(data + i);
    }
    return length;
}

u32 XPredict_Read_tree_61_Words(XPredict *InstancePtr, int offset, word_type *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length)*4 > (XPREDICT_TREE_ADDR_TREE_61_HIGH - XPREDICT_TREE_ADDR_TREE_61_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(data + i) = *(int *)(InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_61_BASE + (offset + i)*4);
    }
    return length;
}

u32 XPredict_Write_tree_61_Bytes(XPredict *InstancePtr, int offset, char *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length) > (XPREDICT_TREE_ADDR_TREE_61_HIGH - XPREDICT_TREE_ADDR_TREE_61_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(char *)(InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_61_BASE + offset + i) = *(data + i);
    }
    return length;
}

u32 XPredict_Read_tree_61_Bytes(XPredict *InstancePtr, int offset, char *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length) > (XPREDICT_TREE_ADDR_TREE_61_HIGH - XPREDICT_TREE_ADDR_TREE_61_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(data + i) = *(char *)(InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_61_BASE + offset + i);
    }
    return length;
}

u32 XPredict_Get_tree_62_BaseAddress(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_62_BASE);
}

u32 XPredict_Get_tree_62_HighAddress(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_62_HIGH);
}

u32 XPredict_Get_tree_62_TotalBytes(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (XPREDICT_TREE_ADDR_TREE_62_HIGH - XPREDICT_TREE_ADDR_TREE_62_BASE + 1);
}

u32 XPredict_Get_tree_62_BitWidth(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XPREDICT_TREE_WIDTH_TREE_62;
}

u32 XPredict_Get_tree_62_Depth(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XPREDICT_TREE_DEPTH_TREE_62;
}

u32 XPredict_Write_tree_62_Words(XPredict *InstancePtr, int offset, word_type *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length)*4 > (XPREDICT_TREE_ADDR_TREE_62_HIGH - XPREDICT_TREE_ADDR_TREE_62_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(int *)(InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_62_BASE + (offset + i)*4) = *(data + i);
    }
    return length;
}

u32 XPredict_Read_tree_62_Words(XPredict *InstancePtr, int offset, word_type *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length)*4 > (XPREDICT_TREE_ADDR_TREE_62_HIGH - XPREDICT_TREE_ADDR_TREE_62_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(data + i) = *(int *)(InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_62_BASE + (offset + i)*4);
    }
    return length;
}

u32 XPredict_Write_tree_62_Bytes(XPredict *InstancePtr, int offset, char *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length) > (XPREDICT_TREE_ADDR_TREE_62_HIGH - XPREDICT_TREE_ADDR_TREE_62_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(char *)(InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_62_BASE + offset + i) = *(data + i);
    }
    return length;
}

u32 XPredict_Read_tree_62_Bytes(XPredict *InstancePtr, int offset, char *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length) > (XPREDICT_TREE_ADDR_TREE_62_HIGH - XPREDICT_TREE_ADDR_TREE_62_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(data + i) = *(char *)(InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_62_BASE + offset + i);
    }
    return length;
}

u32 XPredict_Get_tree_63_BaseAddress(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_63_BASE);
}

u32 XPredict_Get_tree_63_HighAddress(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_63_HIGH);
}

u32 XPredict_Get_tree_63_TotalBytes(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (XPREDICT_TREE_ADDR_TREE_63_HIGH - XPREDICT_TREE_ADDR_TREE_63_BASE + 1);
}

u32 XPredict_Get_tree_63_BitWidth(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XPREDICT_TREE_WIDTH_TREE_63;
}

u32 XPredict_Get_tree_63_Depth(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XPREDICT_TREE_DEPTH_TREE_63;
}

u32 XPredict_Write_tree_63_Words(XPredict *InstancePtr, int offset, word_type *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length)*4 > (XPREDICT_TREE_ADDR_TREE_63_HIGH - XPREDICT_TREE_ADDR_TREE_63_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(int *)(InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_63_BASE + (offset + i)*4) = *(data + i);
    }
    return length;
}

u32 XPredict_Read_tree_63_Words(XPredict *InstancePtr, int offset, word_type *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length)*4 > (XPREDICT_TREE_ADDR_TREE_63_HIGH - XPREDICT_TREE_ADDR_TREE_63_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(data + i) = *(int *)(InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_63_BASE + (offset + i)*4);
    }
    return length;
}

u32 XPredict_Write_tree_63_Bytes(XPredict *InstancePtr, int offset, char *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length) > (XPREDICT_TREE_ADDR_TREE_63_HIGH - XPREDICT_TREE_ADDR_TREE_63_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(char *)(InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_63_BASE + offset + i) = *(data + i);
    }
    return length;
}

u32 XPredict_Read_tree_63_Bytes(XPredict *InstancePtr, int offset, char *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length) > (XPREDICT_TREE_ADDR_TREE_63_HIGH - XPREDICT_TREE_ADDR_TREE_63_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(data + i) = *(char *)(InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_63_BASE + offset + i);
    }
    return length;
}

u32 XPredict_Get_tree_64_BaseAddress(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_64_BASE);
}

u32 XPredict_Get_tree_64_HighAddress(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_64_HIGH);
}

u32 XPredict_Get_tree_64_TotalBytes(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (XPREDICT_TREE_ADDR_TREE_64_HIGH - XPREDICT_TREE_ADDR_TREE_64_BASE + 1);
}

u32 XPredict_Get_tree_64_BitWidth(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XPREDICT_TREE_WIDTH_TREE_64;
}

u32 XPredict_Get_tree_64_Depth(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XPREDICT_TREE_DEPTH_TREE_64;
}

u32 XPredict_Write_tree_64_Words(XPredict *InstancePtr, int offset, word_type *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length)*4 > (XPREDICT_TREE_ADDR_TREE_64_HIGH - XPREDICT_TREE_ADDR_TREE_64_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(int *)(InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_64_BASE + (offset + i)*4) = *(data + i);
    }
    return length;
}

u32 XPredict_Read_tree_64_Words(XPredict *InstancePtr, int offset, word_type *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length)*4 > (XPREDICT_TREE_ADDR_TREE_64_HIGH - XPREDICT_TREE_ADDR_TREE_64_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(data + i) = *(int *)(InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_64_BASE + (offset + i)*4);
    }
    return length;
}

u32 XPredict_Write_tree_64_Bytes(XPredict *InstancePtr, int offset, char *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length) > (XPREDICT_TREE_ADDR_TREE_64_HIGH - XPREDICT_TREE_ADDR_TREE_64_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(char *)(InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_64_BASE + offset + i) = *(data + i);
    }
    return length;
}

u32 XPredict_Read_tree_64_Bytes(XPredict *InstancePtr, int offset, char *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length) > (XPREDICT_TREE_ADDR_TREE_64_HIGH - XPREDICT_TREE_ADDR_TREE_64_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(data + i) = *(char *)(InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_64_BASE + offset + i);
    }
    return length;
}

u32 XPredict_Get_tree_65_BaseAddress(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_65_BASE);
}

u32 XPredict_Get_tree_65_HighAddress(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_65_HIGH);
}

u32 XPredict_Get_tree_65_TotalBytes(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (XPREDICT_TREE_ADDR_TREE_65_HIGH - XPREDICT_TREE_ADDR_TREE_65_BASE + 1);
}

u32 XPredict_Get_tree_65_BitWidth(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XPREDICT_TREE_WIDTH_TREE_65;
}

u32 XPredict_Get_tree_65_Depth(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XPREDICT_TREE_DEPTH_TREE_65;
}

u32 XPredict_Write_tree_65_Words(XPredict *InstancePtr, int offset, word_type *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length)*4 > (XPREDICT_TREE_ADDR_TREE_65_HIGH - XPREDICT_TREE_ADDR_TREE_65_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(int *)(InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_65_BASE + (offset + i)*4) = *(data + i);
    }
    return length;
}

u32 XPredict_Read_tree_65_Words(XPredict *InstancePtr, int offset, word_type *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length)*4 > (XPREDICT_TREE_ADDR_TREE_65_HIGH - XPREDICT_TREE_ADDR_TREE_65_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(data + i) = *(int *)(InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_65_BASE + (offset + i)*4);
    }
    return length;
}

u32 XPredict_Write_tree_65_Bytes(XPredict *InstancePtr, int offset, char *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length) > (XPREDICT_TREE_ADDR_TREE_65_HIGH - XPREDICT_TREE_ADDR_TREE_65_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(char *)(InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_65_BASE + offset + i) = *(data + i);
    }
    return length;
}

u32 XPredict_Read_tree_65_Bytes(XPredict *InstancePtr, int offset, char *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length) > (XPREDICT_TREE_ADDR_TREE_65_HIGH - XPREDICT_TREE_ADDR_TREE_65_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(data + i) = *(char *)(InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_65_BASE + offset + i);
    }
    return length;
}

u32 XPredict_Get_tree_66_BaseAddress(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_66_BASE);
}

u32 XPredict_Get_tree_66_HighAddress(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_66_HIGH);
}

u32 XPredict_Get_tree_66_TotalBytes(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (XPREDICT_TREE_ADDR_TREE_66_HIGH - XPREDICT_TREE_ADDR_TREE_66_BASE + 1);
}

u32 XPredict_Get_tree_66_BitWidth(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XPREDICT_TREE_WIDTH_TREE_66;
}

u32 XPredict_Get_tree_66_Depth(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XPREDICT_TREE_DEPTH_TREE_66;
}

u32 XPredict_Write_tree_66_Words(XPredict *InstancePtr, int offset, word_type *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length)*4 > (XPREDICT_TREE_ADDR_TREE_66_HIGH - XPREDICT_TREE_ADDR_TREE_66_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(int *)(InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_66_BASE + (offset + i)*4) = *(data + i);
    }
    return length;
}

u32 XPredict_Read_tree_66_Words(XPredict *InstancePtr, int offset, word_type *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length)*4 > (XPREDICT_TREE_ADDR_TREE_66_HIGH - XPREDICT_TREE_ADDR_TREE_66_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(data + i) = *(int *)(InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_66_BASE + (offset + i)*4);
    }
    return length;
}

u32 XPredict_Write_tree_66_Bytes(XPredict *InstancePtr, int offset, char *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length) > (XPREDICT_TREE_ADDR_TREE_66_HIGH - XPREDICT_TREE_ADDR_TREE_66_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(char *)(InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_66_BASE + offset + i) = *(data + i);
    }
    return length;
}

u32 XPredict_Read_tree_66_Bytes(XPredict *InstancePtr, int offset, char *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length) > (XPREDICT_TREE_ADDR_TREE_66_HIGH - XPREDICT_TREE_ADDR_TREE_66_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(data + i) = *(char *)(InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_66_BASE + offset + i);
    }
    return length;
}

u32 XPredict_Get_tree_67_BaseAddress(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_67_BASE);
}

u32 XPredict_Get_tree_67_HighAddress(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_67_HIGH);
}

u32 XPredict_Get_tree_67_TotalBytes(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (XPREDICT_TREE_ADDR_TREE_67_HIGH - XPREDICT_TREE_ADDR_TREE_67_BASE + 1);
}

u32 XPredict_Get_tree_67_BitWidth(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XPREDICT_TREE_WIDTH_TREE_67;
}

u32 XPredict_Get_tree_67_Depth(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XPREDICT_TREE_DEPTH_TREE_67;
}

u32 XPredict_Write_tree_67_Words(XPredict *InstancePtr, int offset, word_type *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length)*4 > (XPREDICT_TREE_ADDR_TREE_67_HIGH - XPREDICT_TREE_ADDR_TREE_67_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(int *)(InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_67_BASE + (offset + i)*4) = *(data + i);
    }
    return length;
}

u32 XPredict_Read_tree_67_Words(XPredict *InstancePtr, int offset, word_type *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length)*4 > (XPREDICT_TREE_ADDR_TREE_67_HIGH - XPREDICT_TREE_ADDR_TREE_67_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(data + i) = *(int *)(InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_67_BASE + (offset + i)*4);
    }
    return length;
}

u32 XPredict_Write_tree_67_Bytes(XPredict *InstancePtr, int offset, char *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length) > (XPREDICT_TREE_ADDR_TREE_67_HIGH - XPREDICT_TREE_ADDR_TREE_67_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(char *)(InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_67_BASE + offset + i) = *(data + i);
    }
    return length;
}

u32 XPredict_Read_tree_67_Bytes(XPredict *InstancePtr, int offset, char *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length) > (XPREDICT_TREE_ADDR_TREE_67_HIGH - XPREDICT_TREE_ADDR_TREE_67_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(data + i) = *(char *)(InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_67_BASE + offset + i);
    }
    return length;
}

u32 XPredict_Get_tree_68_BaseAddress(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_68_BASE);
}

u32 XPredict_Get_tree_68_HighAddress(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_68_HIGH);
}

u32 XPredict_Get_tree_68_TotalBytes(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (XPREDICT_TREE_ADDR_TREE_68_HIGH - XPREDICT_TREE_ADDR_TREE_68_BASE + 1);
}

u32 XPredict_Get_tree_68_BitWidth(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XPREDICT_TREE_WIDTH_TREE_68;
}

u32 XPredict_Get_tree_68_Depth(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XPREDICT_TREE_DEPTH_TREE_68;
}

u32 XPredict_Write_tree_68_Words(XPredict *InstancePtr, int offset, word_type *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length)*4 > (XPREDICT_TREE_ADDR_TREE_68_HIGH - XPREDICT_TREE_ADDR_TREE_68_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(int *)(InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_68_BASE + (offset + i)*4) = *(data + i);
    }
    return length;
}

u32 XPredict_Read_tree_68_Words(XPredict *InstancePtr, int offset, word_type *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length)*4 > (XPREDICT_TREE_ADDR_TREE_68_HIGH - XPREDICT_TREE_ADDR_TREE_68_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(data + i) = *(int *)(InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_68_BASE + (offset + i)*4);
    }
    return length;
}

u32 XPredict_Write_tree_68_Bytes(XPredict *InstancePtr, int offset, char *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length) > (XPREDICT_TREE_ADDR_TREE_68_HIGH - XPREDICT_TREE_ADDR_TREE_68_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(char *)(InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_68_BASE + offset + i) = *(data + i);
    }
    return length;
}

u32 XPredict_Read_tree_68_Bytes(XPredict *InstancePtr, int offset, char *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length) > (XPREDICT_TREE_ADDR_TREE_68_HIGH - XPREDICT_TREE_ADDR_TREE_68_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(data + i) = *(char *)(InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_68_BASE + offset + i);
    }
    return length;
}

u32 XPredict_Get_tree_69_BaseAddress(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_69_BASE);
}

u32 XPredict_Get_tree_69_HighAddress(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_69_HIGH);
}

u32 XPredict_Get_tree_69_TotalBytes(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (XPREDICT_TREE_ADDR_TREE_69_HIGH - XPREDICT_TREE_ADDR_TREE_69_BASE + 1);
}

u32 XPredict_Get_tree_69_BitWidth(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XPREDICT_TREE_WIDTH_TREE_69;
}

u32 XPredict_Get_tree_69_Depth(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XPREDICT_TREE_DEPTH_TREE_69;
}

u32 XPredict_Write_tree_69_Words(XPredict *InstancePtr, int offset, word_type *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length)*4 > (XPREDICT_TREE_ADDR_TREE_69_HIGH - XPREDICT_TREE_ADDR_TREE_69_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(int *)(InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_69_BASE + (offset + i)*4) = *(data + i);
    }
    return length;
}

u32 XPredict_Read_tree_69_Words(XPredict *InstancePtr, int offset, word_type *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length)*4 > (XPREDICT_TREE_ADDR_TREE_69_HIGH - XPREDICT_TREE_ADDR_TREE_69_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(data + i) = *(int *)(InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_69_BASE + (offset + i)*4);
    }
    return length;
}

u32 XPredict_Write_tree_69_Bytes(XPredict *InstancePtr, int offset, char *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length) > (XPREDICT_TREE_ADDR_TREE_69_HIGH - XPREDICT_TREE_ADDR_TREE_69_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(char *)(InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_69_BASE + offset + i) = *(data + i);
    }
    return length;
}

u32 XPredict_Read_tree_69_Bytes(XPredict *InstancePtr, int offset, char *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length) > (XPREDICT_TREE_ADDR_TREE_69_HIGH - XPREDICT_TREE_ADDR_TREE_69_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(data + i) = *(char *)(InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_69_BASE + offset + i);
    }
    return length;
}

u32 XPredict_Get_tree_70_BaseAddress(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_70_BASE);
}

u32 XPredict_Get_tree_70_HighAddress(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_70_HIGH);
}

u32 XPredict_Get_tree_70_TotalBytes(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (XPREDICT_TREE_ADDR_TREE_70_HIGH - XPREDICT_TREE_ADDR_TREE_70_BASE + 1);
}

u32 XPredict_Get_tree_70_BitWidth(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XPREDICT_TREE_WIDTH_TREE_70;
}

u32 XPredict_Get_tree_70_Depth(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XPREDICT_TREE_DEPTH_TREE_70;
}

u32 XPredict_Write_tree_70_Words(XPredict *InstancePtr, int offset, word_type *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length)*4 > (XPREDICT_TREE_ADDR_TREE_70_HIGH - XPREDICT_TREE_ADDR_TREE_70_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(int *)(InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_70_BASE + (offset + i)*4) = *(data + i);
    }
    return length;
}

u32 XPredict_Read_tree_70_Words(XPredict *InstancePtr, int offset, word_type *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length)*4 > (XPREDICT_TREE_ADDR_TREE_70_HIGH - XPREDICT_TREE_ADDR_TREE_70_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(data + i) = *(int *)(InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_70_BASE + (offset + i)*4);
    }
    return length;
}

u32 XPredict_Write_tree_70_Bytes(XPredict *InstancePtr, int offset, char *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length) > (XPREDICT_TREE_ADDR_TREE_70_HIGH - XPREDICT_TREE_ADDR_TREE_70_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(char *)(InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_70_BASE + offset + i) = *(data + i);
    }
    return length;
}

u32 XPredict_Read_tree_70_Bytes(XPredict *InstancePtr, int offset, char *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length) > (XPREDICT_TREE_ADDR_TREE_70_HIGH - XPREDICT_TREE_ADDR_TREE_70_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(data + i) = *(char *)(InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_70_BASE + offset + i);
    }
    return length;
}

u32 XPredict_Get_tree_71_BaseAddress(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_71_BASE);
}

u32 XPredict_Get_tree_71_HighAddress(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_71_HIGH);
}

u32 XPredict_Get_tree_71_TotalBytes(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (XPREDICT_TREE_ADDR_TREE_71_HIGH - XPREDICT_TREE_ADDR_TREE_71_BASE + 1);
}

u32 XPredict_Get_tree_71_BitWidth(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XPREDICT_TREE_WIDTH_TREE_71;
}

u32 XPredict_Get_tree_71_Depth(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XPREDICT_TREE_DEPTH_TREE_71;
}

u32 XPredict_Write_tree_71_Words(XPredict *InstancePtr, int offset, word_type *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length)*4 > (XPREDICT_TREE_ADDR_TREE_71_HIGH - XPREDICT_TREE_ADDR_TREE_71_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(int *)(InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_71_BASE + (offset + i)*4) = *(data + i);
    }
    return length;
}

u32 XPredict_Read_tree_71_Words(XPredict *InstancePtr, int offset, word_type *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length)*4 > (XPREDICT_TREE_ADDR_TREE_71_HIGH - XPREDICT_TREE_ADDR_TREE_71_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(data + i) = *(int *)(InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_71_BASE + (offset + i)*4);
    }
    return length;
}

u32 XPredict_Write_tree_71_Bytes(XPredict *InstancePtr, int offset, char *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length) > (XPREDICT_TREE_ADDR_TREE_71_HIGH - XPREDICT_TREE_ADDR_TREE_71_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(char *)(InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_71_BASE + offset + i) = *(data + i);
    }
    return length;
}

u32 XPredict_Read_tree_71_Bytes(XPredict *InstancePtr, int offset, char *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length) > (XPREDICT_TREE_ADDR_TREE_71_HIGH - XPREDICT_TREE_ADDR_TREE_71_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(data + i) = *(char *)(InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_71_BASE + offset + i);
    }
    return length;
}

u32 XPredict_Get_tree_72_BaseAddress(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_72_BASE);
}

u32 XPredict_Get_tree_72_HighAddress(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_72_HIGH);
}

u32 XPredict_Get_tree_72_TotalBytes(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (XPREDICT_TREE_ADDR_TREE_72_HIGH - XPREDICT_TREE_ADDR_TREE_72_BASE + 1);
}

u32 XPredict_Get_tree_72_BitWidth(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XPREDICT_TREE_WIDTH_TREE_72;
}

u32 XPredict_Get_tree_72_Depth(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XPREDICT_TREE_DEPTH_TREE_72;
}

u32 XPredict_Write_tree_72_Words(XPredict *InstancePtr, int offset, word_type *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length)*4 > (XPREDICT_TREE_ADDR_TREE_72_HIGH - XPREDICT_TREE_ADDR_TREE_72_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(int *)(InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_72_BASE + (offset + i)*4) = *(data + i);
    }
    return length;
}

u32 XPredict_Read_tree_72_Words(XPredict *InstancePtr, int offset, word_type *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length)*4 > (XPREDICT_TREE_ADDR_TREE_72_HIGH - XPREDICT_TREE_ADDR_TREE_72_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(data + i) = *(int *)(InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_72_BASE + (offset + i)*4);
    }
    return length;
}

u32 XPredict_Write_tree_72_Bytes(XPredict *InstancePtr, int offset, char *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length) > (XPREDICT_TREE_ADDR_TREE_72_HIGH - XPREDICT_TREE_ADDR_TREE_72_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(char *)(InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_72_BASE + offset + i) = *(data + i);
    }
    return length;
}

u32 XPredict_Read_tree_72_Bytes(XPredict *InstancePtr, int offset, char *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length) > (XPREDICT_TREE_ADDR_TREE_72_HIGH - XPREDICT_TREE_ADDR_TREE_72_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(data + i) = *(char *)(InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_72_BASE + offset + i);
    }
    return length;
}

u32 XPredict_Get_tree_73_BaseAddress(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_73_BASE);
}

u32 XPredict_Get_tree_73_HighAddress(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_73_HIGH);
}

u32 XPredict_Get_tree_73_TotalBytes(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (XPREDICT_TREE_ADDR_TREE_73_HIGH - XPREDICT_TREE_ADDR_TREE_73_BASE + 1);
}

u32 XPredict_Get_tree_73_BitWidth(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XPREDICT_TREE_WIDTH_TREE_73;
}

u32 XPredict_Get_tree_73_Depth(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XPREDICT_TREE_DEPTH_TREE_73;
}

u32 XPredict_Write_tree_73_Words(XPredict *InstancePtr, int offset, word_type *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length)*4 > (XPREDICT_TREE_ADDR_TREE_73_HIGH - XPREDICT_TREE_ADDR_TREE_73_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(int *)(InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_73_BASE + (offset + i)*4) = *(data + i);
    }
    return length;
}

u32 XPredict_Read_tree_73_Words(XPredict *InstancePtr, int offset, word_type *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length)*4 > (XPREDICT_TREE_ADDR_TREE_73_HIGH - XPREDICT_TREE_ADDR_TREE_73_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(data + i) = *(int *)(InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_73_BASE + (offset + i)*4);
    }
    return length;
}

u32 XPredict_Write_tree_73_Bytes(XPredict *InstancePtr, int offset, char *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length) > (XPREDICT_TREE_ADDR_TREE_73_HIGH - XPREDICT_TREE_ADDR_TREE_73_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(char *)(InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_73_BASE + offset + i) = *(data + i);
    }
    return length;
}

u32 XPredict_Read_tree_73_Bytes(XPredict *InstancePtr, int offset, char *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length) > (XPREDICT_TREE_ADDR_TREE_73_HIGH - XPREDICT_TREE_ADDR_TREE_73_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(data + i) = *(char *)(InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_73_BASE + offset + i);
    }
    return length;
}

u32 XPredict_Get_tree_74_BaseAddress(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_74_BASE);
}

u32 XPredict_Get_tree_74_HighAddress(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_74_HIGH);
}

u32 XPredict_Get_tree_74_TotalBytes(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (XPREDICT_TREE_ADDR_TREE_74_HIGH - XPREDICT_TREE_ADDR_TREE_74_BASE + 1);
}

u32 XPredict_Get_tree_74_BitWidth(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XPREDICT_TREE_WIDTH_TREE_74;
}

u32 XPredict_Get_tree_74_Depth(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XPREDICT_TREE_DEPTH_TREE_74;
}

u32 XPredict_Write_tree_74_Words(XPredict *InstancePtr, int offset, word_type *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length)*4 > (XPREDICT_TREE_ADDR_TREE_74_HIGH - XPREDICT_TREE_ADDR_TREE_74_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(int *)(InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_74_BASE + (offset + i)*4) = *(data + i);
    }
    return length;
}

u32 XPredict_Read_tree_74_Words(XPredict *InstancePtr, int offset, word_type *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length)*4 > (XPREDICT_TREE_ADDR_TREE_74_HIGH - XPREDICT_TREE_ADDR_TREE_74_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(data + i) = *(int *)(InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_74_BASE + (offset + i)*4);
    }
    return length;
}

u32 XPredict_Write_tree_74_Bytes(XPredict *InstancePtr, int offset, char *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length) > (XPREDICT_TREE_ADDR_TREE_74_HIGH - XPREDICT_TREE_ADDR_TREE_74_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(char *)(InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_74_BASE + offset + i) = *(data + i);
    }
    return length;
}

u32 XPredict_Read_tree_74_Bytes(XPredict *InstancePtr, int offset, char *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length) > (XPREDICT_TREE_ADDR_TREE_74_HIGH - XPREDICT_TREE_ADDR_TREE_74_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(data + i) = *(char *)(InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_74_BASE + offset + i);
    }
    return length;
}

u32 XPredict_Get_tree_75_BaseAddress(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_75_BASE);
}

u32 XPredict_Get_tree_75_HighAddress(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_75_HIGH);
}

u32 XPredict_Get_tree_75_TotalBytes(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (XPREDICT_TREE_ADDR_TREE_75_HIGH - XPREDICT_TREE_ADDR_TREE_75_BASE + 1);
}

u32 XPredict_Get_tree_75_BitWidth(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XPREDICT_TREE_WIDTH_TREE_75;
}

u32 XPredict_Get_tree_75_Depth(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XPREDICT_TREE_DEPTH_TREE_75;
}

u32 XPredict_Write_tree_75_Words(XPredict *InstancePtr, int offset, word_type *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length)*4 > (XPREDICT_TREE_ADDR_TREE_75_HIGH - XPREDICT_TREE_ADDR_TREE_75_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(int *)(InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_75_BASE + (offset + i)*4) = *(data + i);
    }
    return length;
}

u32 XPredict_Read_tree_75_Words(XPredict *InstancePtr, int offset, word_type *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length)*4 > (XPREDICT_TREE_ADDR_TREE_75_HIGH - XPREDICT_TREE_ADDR_TREE_75_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(data + i) = *(int *)(InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_75_BASE + (offset + i)*4);
    }
    return length;
}

u32 XPredict_Write_tree_75_Bytes(XPredict *InstancePtr, int offset, char *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length) > (XPREDICT_TREE_ADDR_TREE_75_HIGH - XPREDICT_TREE_ADDR_TREE_75_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(char *)(InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_75_BASE + offset + i) = *(data + i);
    }
    return length;
}

u32 XPredict_Read_tree_75_Bytes(XPredict *InstancePtr, int offset, char *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length) > (XPREDICT_TREE_ADDR_TREE_75_HIGH - XPREDICT_TREE_ADDR_TREE_75_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(data + i) = *(char *)(InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_75_BASE + offset + i);
    }
    return length;
}

u32 XPredict_Get_tree_76_BaseAddress(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_76_BASE);
}

u32 XPredict_Get_tree_76_HighAddress(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_76_HIGH);
}

u32 XPredict_Get_tree_76_TotalBytes(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (XPREDICT_TREE_ADDR_TREE_76_HIGH - XPREDICT_TREE_ADDR_TREE_76_BASE + 1);
}

u32 XPredict_Get_tree_76_BitWidth(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XPREDICT_TREE_WIDTH_TREE_76;
}

u32 XPredict_Get_tree_76_Depth(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XPREDICT_TREE_DEPTH_TREE_76;
}

u32 XPredict_Write_tree_76_Words(XPredict *InstancePtr, int offset, word_type *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length)*4 > (XPREDICT_TREE_ADDR_TREE_76_HIGH - XPREDICT_TREE_ADDR_TREE_76_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(int *)(InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_76_BASE + (offset + i)*4) = *(data + i);
    }
    return length;
}

u32 XPredict_Read_tree_76_Words(XPredict *InstancePtr, int offset, word_type *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length)*4 > (XPREDICT_TREE_ADDR_TREE_76_HIGH - XPREDICT_TREE_ADDR_TREE_76_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(data + i) = *(int *)(InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_76_BASE + (offset + i)*4);
    }
    return length;
}

u32 XPredict_Write_tree_76_Bytes(XPredict *InstancePtr, int offset, char *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length) > (XPREDICT_TREE_ADDR_TREE_76_HIGH - XPREDICT_TREE_ADDR_TREE_76_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(char *)(InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_76_BASE + offset + i) = *(data + i);
    }
    return length;
}

u32 XPredict_Read_tree_76_Bytes(XPredict *InstancePtr, int offset, char *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length) > (XPREDICT_TREE_ADDR_TREE_76_HIGH - XPREDICT_TREE_ADDR_TREE_76_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(data + i) = *(char *)(InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_76_BASE + offset + i);
    }
    return length;
}

u32 XPredict_Get_tree_77_BaseAddress(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_77_BASE);
}

u32 XPredict_Get_tree_77_HighAddress(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_77_HIGH);
}

u32 XPredict_Get_tree_77_TotalBytes(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (XPREDICT_TREE_ADDR_TREE_77_HIGH - XPREDICT_TREE_ADDR_TREE_77_BASE + 1);
}

u32 XPredict_Get_tree_77_BitWidth(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XPREDICT_TREE_WIDTH_TREE_77;
}

u32 XPredict_Get_tree_77_Depth(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XPREDICT_TREE_DEPTH_TREE_77;
}

u32 XPredict_Write_tree_77_Words(XPredict *InstancePtr, int offset, word_type *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length)*4 > (XPREDICT_TREE_ADDR_TREE_77_HIGH - XPREDICT_TREE_ADDR_TREE_77_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(int *)(InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_77_BASE + (offset + i)*4) = *(data + i);
    }
    return length;
}

u32 XPredict_Read_tree_77_Words(XPredict *InstancePtr, int offset, word_type *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length)*4 > (XPREDICT_TREE_ADDR_TREE_77_HIGH - XPREDICT_TREE_ADDR_TREE_77_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(data + i) = *(int *)(InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_77_BASE + (offset + i)*4);
    }
    return length;
}

u32 XPredict_Write_tree_77_Bytes(XPredict *InstancePtr, int offset, char *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length) > (XPREDICT_TREE_ADDR_TREE_77_HIGH - XPREDICT_TREE_ADDR_TREE_77_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(char *)(InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_77_BASE + offset + i) = *(data + i);
    }
    return length;
}

u32 XPredict_Read_tree_77_Bytes(XPredict *InstancePtr, int offset, char *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length) > (XPREDICT_TREE_ADDR_TREE_77_HIGH - XPREDICT_TREE_ADDR_TREE_77_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(data + i) = *(char *)(InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_77_BASE + offset + i);
    }
    return length;
}

u32 XPredict_Get_tree_78_BaseAddress(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_78_BASE);
}

u32 XPredict_Get_tree_78_HighAddress(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_78_HIGH);
}

u32 XPredict_Get_tree_78_TotalBytes(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (XPREDICT_TREE_ADDR_TREE_78_HIGH - XPREDICT_TREE_ADDR_TREE_78_BASE + 1);
}

u32 XPredict_Get_tree_78_BitWidth(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XPREDICT_TREE_WIDTH_TREE_78;
}

u32 XPredict_Get_tree_78_Depth(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XPREDICT_TREE_DEPTH_TREE_78;
}

u32 XPredict_Write_tree_78_Words(XPredict *InstancePtr, int offset, word_type *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length)*4 > (XPREDICT_TREE_ADDR_TREE_78_HIGH - XPREDICT_TREE_ADDR_TREE_78_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(int *)(InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_78_BASE + (offset + i)*4) = *(data + i);
    }
    return length;
}

u32 XPredict_Read_tree_78_Words(XPredict *InstancePtr, int offset, word_type *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length)*4 > (XPREDICT_TREE_ADDR_TREE_78_HIGH - XPREDICT_TREE_ADDR_TREE_78_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(data + i) = *(int *)(InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_78_BASE + (offset + i)*4);
    }
    return length;
}

u32 XPredict_Write_tree_78_Bytes(XPredict *InstancePtr, int offset, char *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length) > (XPREDICT_TREE_ADDR_TREE_78_HIGH - XPREDICT_TREE_ADDR_TREE_78_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(char *)(InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_78_BASE + offset + i) = *(data + i);
    }
    return length;
}

u32 XPredict_Read_tree_78_Bytes(XPredict *InstancePtr, int offset, char *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length) > (XPREDICT_TREE_ADDR_TREE_78_HIGH - XPREDICT_TREE_ADDR_TREE_78_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(data + i) = *(char *)(InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_78_BASE + offset + i);
    }
    return length;
}

u32 XPredict_Get_tree_79_BaseAddress(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_79_BASE);
}

u32 XPredict_Get_tree_79_HighAddress(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_79_HIGH);
}

u32 XPredict_Get_tree_79_TotalBytes(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (XPREDICT_TREE_ADDR_TREE_79_HIGH - XPREDICT_TREE_ADDR_TREE_79_BASE + 1);
}

u32 XPredict_Get_tree_79_BitWidth(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XPREDICT_TREE_WIDTH_TREE_79;
}

u32 XPredict_Get_tree_79_Depth(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XPREDICT_TREE_DEPTH_TREE_79;
}

u32 XPredict_Write_tree_79_Words(XPredict *InstancePtr, int offset, word_type *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length)*4 > (XPREDICT_TREE_ADDR_TREE_79_HIGH - XPREDICT_TREE_ADDR_TREE_79_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(int *)(InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_79_BASE + (offset + i)*4) = *(data + i);
    }
    return length;
}

u32 XPredict_Read_tree_79_Words(XPredict *InstancePtr, int offset, word_type *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length)*4 > (XPREDICT_TREE_ADDR_TREE_79_HIGH - XPREDICT_TREE_ADDR_TREE_79_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(data + i) = *(int *)(InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_79_BASE + (offset + i)*4);
    }
    return length;
}

u32 XPredict_Write_tree_79_Bytes(XPredict *InstancePtr, int offset, char *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length) > (XPREDICT_TREE_ADDR_TREE_79_HIGH - XPREDICT_TREE_ADDR_TREE_79_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(char *)(InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_79_BASE + offset + i) = *(data + i);
    }
    return length;
}

u32 XPredict_Read_tree_79_Bytes(XPredict *InstancePtr, int offset, char *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length) > (XPREDICT_TREE_ADDR_TREE_79_HIGH - XPREDICT_TREE_ADDR_TREE_79_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(data + i) = *(char *)(InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_79_BASE + offset + i);
    }
    return length;
}

u32 XPredict_Get_tree_80_BaseAddress(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_80_BASE);
}

u32 XPredict_Get_tree_80_HighAddress(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_80_HIGH);
}

u32 XPredict_Get_tree_80_TotalBytes(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (XPREDICT_TREE_ADDR_TREE_80_HIGH - XPREDICT_TREE_ADDR_TREE_80_BASE + 1);
}

u32 XPredict_Get_tree_80_BitWidth(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XPREDICT_TREE_WIDTH_TREE_80;
}

u32 XPredict_Get_tree_80_Depth(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XPREDICT_TREE_DEPTH_TREE_80;
}

u32 XPredict_Write_tree_80_Words(XPredict *InstancePtr, int offset, word_type *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length)*4 > (XPREDICT_TREE_ADDR_TREE_80_HIGH - XPREDICT_TREE_ADDR_TREE_80_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(int *)(InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_80_BASE + (offset + i)*4) = *(data + i);
    }
    return length;
}

u32 XPredict_Read_tree_80_Words(XPredict *InstancePtr, int offset, word_type *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length)*4 > (XPREDICT_TREE_ADDR_TREE_80_HIGH - XPREDICT_TREE_ADDR_TREE_80_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(data + i) = *(int *)(InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_80_BASE + (offset + i)*4);
    }
    return length;
}

u32 XPredict_Write_tree_80_Bytes(XPredict *InstancePtr, int offset, char *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length) > (XPREDICT_TREE_ADDR_TREE_80_HIGH - XPREDICT_TREE_ADDR_TREE_80_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(char *)(InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_80_BASE + offset + i) = *(data + i);
    }
    return length;
}

u32 XPredict_Read_tree_80_Bytes(XPredict *InstancePtr, int offset, char *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length) > (XPREDICT_TREE_ADDR_TREE_80_HIGH - XPREDICT_TREE_ADDR_TREE_80_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(data + i) = *(char *)(InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_80_BASE + offset + i);
    }
    return length;
}

u32 XPredict_Get_tree_81_BaseAddress(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_81_BASE);
}

u32 XPredict_Get_tree_81_HighAddress(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_81_HIGH);
}

u32 XPredict_Get_tree_81_TotalBytes(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (XPREDICT_TREE_ADDR_TREE_81_HIGH - XPREDICT_TREE_ADDR_TREE_81_BASE + 1);
}

u32 XPredict_Get_tree_81_BitWidth(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XPREDICT_TREE_WIDTH_TREE_81;
}

u32 XPredict_Get_tree_81_Depth(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XPREDICT_TREE_DEPTH_TREE_81;
}

u32 XPredict_Write_tree_81_Words(XPredict *InstancePtr, int offset, word_type *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length)*4 > (XPREDICT_TREE_ADDR_TREE_81_HIGH - XPREDICT_TREE_ADDR_TREE_81_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(int *)(InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_81_BASE + (offset + i)*4) = *(data + i);
    }
    return length;
}

u32 XPredict_Read_tree_81_Words(XPredict *InstancePtr, int offset, word_type *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length)*4 > (XPREDICT_TREE_ADDR_TREE_81_HIGH - XPREDICT_TREE_ADDR_TREE_81_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(data + i) = *(int *)(InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_81_BASE + (offset + i)*4);
    }
    return length;
}

u32 XPredict_Write_tree_81_Bytes(XPredict *InstancePtr, int offset, char *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length) > (XPREDICT_TREE_ADDR_TREE_81_HIGH - XPREDICT_TREE_ADDR_TREE_81_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(char *)(InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_81_BASE + offset + i) = *(data + i);
    }
    return length;
}

u32 XPredict_Read_tree_81_Bytes(XPredict *InstancePtr, int offset, char *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length) > (XPREDICT_TREE_ADDR_TREE_81_HIGH - XPREDICT_TREE_ADDR_TREE_81_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(data + i) = *(char *)(InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_81_BASE + offset + i);
    }
    return length;
}

u32 XPredict_Get_tree_82_BaseAddress(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_82_BASE);
}

u32 XPredict_Get_tree_82_HighAddress(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_82_HIGH);
}

u32 XPredict_Get_tree_82_TotalBytes(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (XPREDICT_TREE_ADDR_TREE_82_HIGH - XPREDICT_TREE_ADDR_TREE_82_BASE + 1);
}

u32 XPredict_Get_tree_82_BitWidth(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XPREDICT_TREE_WIDTH_TREE_82;
}

u32 XPredict_Get_tree_82_Depth(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XPREDICT_TREE_DEPTH_TREE_82;
}

u32 XPredict_Write_tree_82_Words(XPredict *InstancePtr, int offset, word_type *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length)*4 > (XPREDICT_TREE_ADDR_TREE_82_HIGH - XPREDICT_TREE_ADDR_TREE_82_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(int *)(InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_82_BASE + (offset + i)*4) = *(data + i);
    }
    return length;
}

u32 XPredict_Read_tree_82_Words(XPredict *InstancePtr, int offset, word_type *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length)*4 > (XPREDICT_TREE_ADDR_TREE_82_HIGH - XPREDICT_TREE_ADDR_TREE_82_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(data + i) = *(int *)(InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_82_BASE + (offset + i)*4);
    }
    return length;
}

u32 XPredict_Write_tree_82_Bytes(XPredict *InstancePtr, int offset, char *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length) > (XPREDICT_TREE_ADDR_TREE_82_HIGH - XPREDICT_TREE_ADDR_TREE_82_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(char *)(InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_82_BASE + offset + i) = *(data + i);
    }
    return length;
}

u32 XPredict_Read_tree_82_Bytes(XPredict *InstancePtr, int offset, char *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length) > (XPREDICT_TREE_ADDR_TREE_82_HIGH - XPREDICT_TREE_ADDR_TREE_82_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(data + i) = *(char *)(InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_82_BASE + offset + i);
    }
    return length;
}

u32 XPredict_Get_tree_83_BaseAddress(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_83_BASE);
}

u32 XPredict_Get_tree_83_HighAddress(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_83_HIGH);
}

u32 XPredict_Get_tree_83_TotalBytes(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (XPREDICT_TREE_ADDR_TREE_83_HIGH - XPREDICT_TREE_ADDR_TREE_83_BASE + 1);
}

u32 XPredict_Get_tree_83_BitWidth(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XPREDICT_TREE_WIDTH_TREE_83;
}

u32 XPredict_Get_tree_83_Depth(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XPREDICT_TREE_DEPTH_TREE_83;
}

u32 XPredict_Write_tree_83_Words(XPredict *InstancePtr, int offset, word_type *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length)*4 > (XPREDICT_TREE_ADDR_TREE_83_HIGH - XPREDICT_TREE_ADDR_TREE_83_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(int *)(InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_83_BASE + (offset + i)*4) = *(data + i);
    }
    return length;
}

u32 XPredict_Read_tree_83_Words(XPredict *InstancePtr, int offset, word_type *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length)*4 > (XPREDICT_TREE_ADDR_TREE_83_HIGH - XPREDICT_TREE_ADDR_TREE_83_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(data + i) = *(int *)(InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_83_BASE + (offset + i)*4);
    }
    return length;
}

u32 XPredict_Write_tree_83_Bytes(XPredict *InstancePtr, int offset, char *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length) > (XPREDICT_TREE_ADDR_TREE_83_HIGH - XPREDICT_TREE_ADDR_TREE_83_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(char *)(InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_83_BASE + offset + i) = *(data + i);
    }
    return length;
}

u32 XPredict_Read_tree_83_Bytes(XPredict *InstancePtr, int offset, char *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length) > (XPREDICT_TREE_ADDR_TREE_83_HIGH - XPREDICT_TREE_ADDR_TREE_83_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(data + i) = *(char *)(InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_83_BASE + offset + i);
    }
    return length;
}

u32 XPredict_Get_tree_84_BaseAddress(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_84_BASE);
}

u32 XPredict_Get_tree_84_HighAddress(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_84_HIGH);
}

u32 XPredict_Get_tree_84_TotalBytes(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (XPREDICT_TREE_ADDR_TREE_84_HIGH - XPREDICT_TREE_ADDR_TREE_84_BASE + 1);
}

u32 XPredict_Get_tree_84_BitWidth(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XPREDICT_TREE_WIDTH_TREE_84;
}

u32 XPredict_Get_tree_84_Depth(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XPREDICT_TREE_DEPTH_TREE_84;
}

u32 XPredict_Write_tree_84_Words(XPredict *InstancePtr, int offset, word_type *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length)*4 > (XPREDICT_TREE_ADDR_TREE_84_HIGH - XPREDICT_TREE_ADDR_TREE_84_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(int *)(InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_84_BASE + (offset + i)*4) = *(data + i);
    }
    return length;
}

u32 XPredict_Read_tree_84_Words(XPredict *InstancePtr, int offset, word_type *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length)*4 > (XPREDICT_TREE_ADDR_TREE_84_HIGH - XPREDICT_TREE_ADDR_TREE_84_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(data + i) = *(int *)(InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_84_BASE + (offset + i)*4);
    }
    return length;
}

u32 XPredict_Write_tree_84_Bytes(XPredict *InstancePtr, int offset, char *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length) > (XPREDICT_TREE_ADDR_TREE_84_HIGH - XPREDICT_TREE_ADDR_TREE_84_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(char *)(InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_84_BASE + offset + i) = *(data + i);
    }
    return length;
}

u32 XPredict_Read_tree_84_Bytes(XPredict *InstancePtr, int offset, char *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length) > (XPREDICT_TREE_ADDR_TREE_84_HIGH - XPREDICT_TREE_ADDR_TREE_84_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(data + i) = *(char *)(InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_84_BASE + offset + i);
    }
    return length;
}

u32 XPredict_Get_tree_85_BaseAddress(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_85_BASE);
}

u32 XPredict_Get_tree_85_HighAddress(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_85_HIGH);
}

u32 XPredict_Get_tree_85_TotalBytes(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (XPREDICT_TREE_ADDR_TREE_85_HIGH - XPREDICT_TREE_ADDR_TREE_85_BASE + 1);
}

u32 XPredict_Get_tree_85_BitWidth(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XPREDICT_TREE_WIDTH_TREE_85;
}

u32 XPredict_Get_tree_85_Depth(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XPREDICT_TREE_DEPTH_TREE_85;
}

u32 XPredict_Write_tree_85_Words(XPredict *InstancePtr, int offset, word_type *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length)*4 > (XPREDICT_TREE_ADDR_TREE_85_HIGH - XPREDICT_TREE_ADDR_TREE_85_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(int *)(InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_85_BASE + (offset + i)*4) = *(data + i);
    }
    return length;
}

u32 XPredict_Read_tree_85_Words(XPredict *InstancePtr, int offset, word_type *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length)*4 > (XPREDICT_TREE_ADDR_TREE_85_HIGH - XPREDICT_TREE_ADDR_TREE_85_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(data + i) = *(int *)(InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_85_BASE + (offset + i)*4);
    }
    return length;
}

u32 XPredict_Write_tree_85_Bytes(XPredict *InstancePtr, int offset, char *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length) > (XPREDICT_TREE_ADDR_TREE_85_HIGH - XPREDICT_TREE_ADDR_TREE_85_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(char *)(InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_85_BASE + offset + i) = *(data + i);
    }
    return length;
}

u32 XPredict_Read_tree_85_Bytes(XPredict *InstancePtr, int offset, char *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length) > (XPREDICT_TREE_ADDR_TREE_85_HIGH - XPREDICT_TREE_ADDR_TREE_85_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(data + i) = *(char *)(InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_85_BASE + offset + i);
    }
    return length;
}

u32 XPredict_Get_tree_86_BaseAddress(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_86_BASE);
}

u32 XPredict_Get_tree_86_HighAddress(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_86_HIGH);
}

u32 XPredict_Get_tree_86_TotalBytes(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (XPREDICT_TREE_ADDR_TREE_86_HIGH - XPREDICT_TREE_ADDR_TREE_86_BASE + 1);
}

u32 XPredict_Get_tree_86_BitWidth(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XPREDICT_TREE_WIDTH_TREE_86;
}

u32 XPredict_Get_tree_86_Depth(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XPREDICT_TREE_DEPTH_TREE_86;
}

u32 XPredict_Write_tree_86_Words(XPredict *InstancePtr, int offset, word_type *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length)*4 > (XPREDICT_TREE_ADDR_TREE_86_HIGH - XPREDICT_TREE_ADDR_TREE_86_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(int *)(InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_86_BASE + (offset + i)*4) = *(data + i);
    }
    return length;
}

u32 XPredict_Read_tree_86_Words(XPredict *InstancePtr, int offset, word_type *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length)*4 > (XPREDICT_TREE_ADDR_TREE_86_HIGH - XPREDICT_TREE_ADDR_TREE_86_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(data + i) = *(int *)(InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_86_BASE + (offset + i)*4);
    }
    return length;
}

u32 XPredict_Write_tree_86_Bytes(XPredict *InstancePtr, int offset, char *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length) > (XPREDICT_TREE_ADDR_TREE_86_HIGH - XPREDICT_TREE_ADDR_TREE_86_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(char *)(InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_86_BASE + offset + i) = *(data + i);
    }
    return length;
}

u32 XPredict_Read_tree_86_Bytes(XPredict *InstancePtr, int offset, char *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length) > (XPREDICT_TREE_ADDR_TREE_86_HIGH - XPREDICT_TREE_ADDR_TREE_86_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(data + i) = *(char *)(InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_86_BASE + offset + i);
    }
    return length;
}

u32 XPredict_Get_tree_87_BaseAddress(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_87_BASE);
}

u32 XPredict_Get_tree_87_HighAddress(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_87_HIGH);
}

u32 XPredict_Get_tree_87_TotalBytes(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (XPREDICT_TREE_ADDR_TREE_87_HIGH - XPREDICT_TREE_ADDR_TREE_87_BASE + 1);
}

u32 XPredict_Get_tree_87_BitWidth(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XPREDICT_TREE_WIDTH_TREE_87;
}

u32 XPredict_Get_tree_87_Depth(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XPREDICT_TREE_DEPTH_TREE_87;
}

u32 XPredict_Write_tree_87_Words(XPredict *InstancePtr, int offset, word_type *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length)*4 > (XPREDICT_TREE_ADDR_TREE_87_HIGH - XPREDICT_TREE_ADDR_TREE_87_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(int *)(InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_87_BASE + (offset + i)*4) = *(data + i);
    }
    return length;
}

u32 XPredict_Read_tree_87_Words(XPredict *InstancePtr, int offset, word_type *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length)*4 > (XPREDICT_TREE_ADDR_TREE_87_HIGH - XPREDICT_TREE_ADDR_TREE_87_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(data + i) = *(int *)(InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_87_BASE + (offset + i)*4);
    }
    return length;
}

u32 XPredict_Write_tree_87_Bytes(XPredict *InstancePtr, int offset, char *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length) > (XPREDICT_TREE_ADDR_TREE_87_HIGH - XPREDICT_TREE_ADDR_TREE_87_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(char *)(InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_87_BASE + offset + i) = *(data + i);
    }
    return length;
}

u32 XPredict_Read_tree_87_Bytes(XPredict *InstancePtr, int offset, char *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length) > (XPREDICT_TREE_ADDR_TREE_87_HIGH - XPREDICT_TREE_ADDR_TREE_87_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(data + i) = *(char *)(InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_87_BASE + offset + i);
    }
    return length;
}

u32 XPredict_Get_tree_88_BaseAddress(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_88_BASE);
}

u32 XPredict_Get_tree_88_HighAddress(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_88_HIGH);
}

u32 XPredict_Get_tree_88_TotalBytes(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (XPREDICT_TREE_ADDR_TREE_88_HIGH - XPREDICT_TREE_ADDR_TREE_88_BASE + 1);
}

u32 XPredict_Get_tree_88_BitWidth(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XPREDICT_TREE_WIDTH_TREE_88;
}

u32 XPredict_Get_tree_88_Depth(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XPREDICT_TREE_DEPTH_TREE_88;
}

u32 XPredict_Write_tree_88_Words(XPredict *InstancePtr, int offset, word_type *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length)*4 > (XPREDICT_TREE_ADDR_TREE_88_HIGH - XPREDICT_TREE_ADDR_TREE_88_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(int *)(InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_88_BASE + (offset + i)*4) = *(data + i);
    }
    return length;
}

u32 XPredict_Read_tree_88_Words(XPredict *InstancePtr, int offset, word_type *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length)*4 > (XPREDICT_TREE_ADDR_TREE_88_HIGH - XPREDICT_TREE_ADDR_TREE_88_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(data + i) = *(int *)(InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_88_BASE + (offset + i)*4);
    }
    return length;
}

u32 XPredict_Write_tree_88_Bytes(XPredict *InstancePtr, int offset, char *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length) > (XPREDICT_TREE_ADDR_TREE_88_HIGH - XPREDICT_TREE_ADDR_TREE_88_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(char *)(InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_88_BASE + offset + i) = *(data + i);
    }
    return length;
}

u32 XPredict_Read_tree_88_Bytes(XPredict *InstancePtr, int offset, char *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length) > (XPREDICT_TREE_ADDR_TREE_88_HIGH - XPREDICT_TREE_ADDR_TREE_88_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(data + i) = *(char *)(InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_88_BASE + offset + i);
    }
    return length;
}

u32 XPredict_Get_tree_89_BaseAddress(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_89_BASE);
}

u32 XPredict_Get_tree_89_HighAddress(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_89_HIGH);
}

u32 XPredict_Get_tree_89_TotalBytes(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (XPREDICT_TREE_ADDR_TREE_89_HIGH - XPREDICT_TREE_ADDR_TREE_89_BASE + 1);
}

u32 XPredict_Get_tree_89_BitWidth(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XPREDICT_TREE_WIDTH_TREE_89;
}

u32 XPredict_Get_tree_89_Depth(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XPREDICT_TREE_DEPTH_TREE_89;
}

u32 XPredict_Write_tree_89_Words(XPredict *InstancePtr, int offset, word_type *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length)*4 > (XPREDICT_TREE_ADDR_TREE_89_HIGH - XPREDICT_TREE_ADDR_TREE_89_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(int *)(InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_89_BASE + (offset + i)*4) = *(data + i);
    }
    return length;
}

u32 XPredict_Read_tree_89_Words(XPredict *InstancePtr, int offset, word_type *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length)*4 > (XPREDICT_TREE_ADDR_TREE_89_HIGH - XPREDICT_TREE_ADDR_TREE_89_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(data + i) = *(int *)(InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_89_BASE + (offset + i)*4);
    }
    return length;
}

u32 XPredict_Write_tree_89_Bytes(XPredict *InstancePtr, int offset, char *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length) > (XPREDICT_TREE_ADDR_TREE_89_HIGH - XPREDICT_TREE_ADDR_TREE_89_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(char *)(InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_89_BASE + offset + i) = *(data + i);
    }
    return length;
}

u32 XPredict_Read_tree_89_Bytes(XPredict *InstancePtr, int offset, char *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length) > (XPREDICT_TREE_ADDR_TREE_89_HIGH - XPREDICT_TREE_ADDR_TREE_89_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(data + i) = *(char *)(InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_89_BASE + offset + i);
    }
    return length;
}

u32 XPredict_Get_tree_90_BaseAddress(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_90_BASE);
}

u32 XPredict_Get_tree_90_HighAddress(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_90_HIGH);
}

u32 XPredict_Get_tree_90_TotalBytes(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (XPREDICT_TREE_ADDR_TREE_90_HIGH - XPREDICT_TREE_ADDR_TREE_90_BASE + 1);
}

u32 XPredict_Get_tree_90_BitWidth(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XPREDICT_TREE_WIDTH_TREE_90;
}

u32 XPredict_Get_tree_90_Depth(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XPREDICT_TREE_DEPTH_TREE_90;
}

u32 XPredict_Write_tree_90_Words(XPredict *InstancePtr, int offset, word_type *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length)*4 > (XPREDICT_TREE_ADDR_TREE_90_HIGH - XPREDICT_TREE_ADDR_TREE_90_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(int *)(InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_90_BASE + (offset + i)*4) = *(data + i);
    }
    return length;
}

u32 XPredict_Read_tree_90_Words(XPredict *InstancePtr, int offset, word_type *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length)*4 > (XPREDICT_TREE_ADDR_TREE_90_HIGH - XPREDICT_TREE_ADDR_TREE_90_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(data + i) = *(int *)(InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_90_BASE + (offset + i)*4);
    }
    return length;
}

u32 XPredict_Write_tree_90_Bytes(XPredict *InstancePtr, int offset, char *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length) > (XPREDICT_TREE_ADDR_TREE_90_HIGH - XPREDICT_TREE_ADDR_TREE_90_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(char *)(InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_90_BASE + offset + i) = *(data + i);
    }
    return length;
}

u32 XPredict_Read_tree_90_Bytes(XPredict *InstancePtr, int offset, char *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length) > (XPREDICT_TREE_ADDR_TREE_90_HIGH - XPREDICT_TREE_ADDR_TREE_90_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(data + i) = *(char *)(InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_90_BASE + offset + i);
    }
    return length;
}

u32 XPredict_Get_tree_91_BaseAddress(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_91_BASE);
}

u32 XPredict_Get_tree_91_HighAddress(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_91_HIGH);
}

u32 XPredict_Get_tree_91_TotalBytes(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (XPREDICT_TREE_ADDR_TREE_91_HIGH - XPREDICT_TREE_ADDR_TREE_91_BASE + 1);
}

u32 XPredict_Get_tree_91_BitWidth(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XPREDICT_TREE_WIDTH_TREE_91;
}

u32 XPredict_Get_tree_91_Depth(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XPREDICT_TREE_DEPTH_TREE_91;
}

u32 XPredict_Write_tree_91_Words(XPredict *InstancePtr, int offset, word_type *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length)*4 > (XPREDICT_TREE_ADDR_TREE_91_HIGH - XPREDICT_TREE_ADDR_TREE_91_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(int *)(InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_91_BASE + (offset + i)*4) = *(data + i);
    }
    return length;
}

u32 XPredict_Read_tree_91_Words(XPredict *InstancePtr, int offset, word_type *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length)*4 > (XPREDICT_TREE_ADDR_TREE_91_HIGH - XPREDICT_TREE_ADDR_TREE_91_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(data + i) = *(int *)(InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_91_BASE + (offset + i)*4);
    }
    return length;
}

u32 XPredict_Write_tree_91_Bytes(XPredict *InstancePtr, int offset, char *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length) > (XPREDICT_TREE_ADDR_TREE_91_HIGH - XPREDICT_TREE_ADDR_TREE_91_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(char *)(InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_91_BASE + offset + i) = *(data + i);
    }
    return length;
}

u32 XPredict_Read_tree_91_Bytes(XPredict *InstancePtr, int offset, char *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length) > (XPREDICT_TREE_ADDR_TREE_91_HIGH - XPREDICT_TREE_ADDR_TREE_91_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(data + i) = *(char *)(InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_91_BASE + offset + i);
    }
    return length;
}

u32 XPredict_Get_tree_92_BaseAddress(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_92_BASE);
}

u32 XPredict_Get_tree_92_HighAddress(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_92_HIGH);
}

u32 XPredict_Get_tree_92_TotalBytes(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (XPREDICT_TREE_ADDR_TREE_92_HIGH - XPREDICT_TREE_ADDR_TREE_92_BASE + 1);
}

u32 XPredict_Get_tree_92_BitWidth(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XPREDICT_TREE_WIDTH_TREE_92;
}

u32 XPredict_Get_tree_92_Depth(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XPREDICT_TREE_DEPTH_TREE_92;
}

u32 XPredict_Write_tree_92_Words(XPredict *InstancePtr, int offset, word_type *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length)*4 > (XPREDICT_TREE_ADDR_TREE_92_HIGH - XPREDICT_TREE_ADDR_TREE_92_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(int *)(InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_92_BASE + (offset + i)*4) = *(data + i);
    }
    return length;
}

u32 XPredict_Read_tree_92_Words(XPredict *InstancePtr, int offset, word_type *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length)*4 > (XPREDICT_TREE_ADDR_TREE_92_HIGH - XPREDICT_TREE_ADDR_TREE_92_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(data + i) = *(int *)(InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_92_BASE + (offset + i)*4);
    }
    return length;
}

u32 XPredict_Write_tree_92_Bytes(XPredict *InstancePtr, int offset, char *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length) > (XPREDICT_TREE_ADDR_TREE_92_HIGH - XPREDICT_TREE_ADDR_TREE_92_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(char *)(InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_92_BASE + offset + i) = *(data + i);
    }
    return length;
}

u32 XPredict_Read_tree_92_Bytes(XPredict *InstancePtr, int offset, char *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length) > (XPREDICT_TREE_ADDR_TREE_92_HIGH - XPREDICT_TREE_ADDR_TREE_92_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(data + i) = *(char *)(InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_92_BASE + offset + i);
    }
    return length;
}

u32 XPredict_Get_tree_93_BaseAddress(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_93_BASE);
}

u32 XPredict_Get_tree_93_HighAddress(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_93_HIGH);
}

u32 XPredict_Get_tree_93_TotalBytes(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (XPREDICT_TREE_ADDR_TREE_93_HIGH - XPREDICT_TREE_ADDR_TREE_93_BASE + 1);
}

u32 XPredict_Get_tree_93_BitWidth(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XPREDICT_TREE_WIDTH_TREE_93;
}

u32 XPredict_Get_tree_93_Depth(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XPREDICT_TREE_DEPTH_TREE_93;
}

u32 XPredict_Write_tree_93_Words(XPredict *InstancePtr, int offset, word_type *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length)*4 > (XPREDICT_TREE_ADDR_TREE_93_HIGH - XPREDICT_TREE_ADDR_TREE_93_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(int *)(InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_93_BASE + (offset + i)*4) = *(data + i);
    }
    return length;
}

u32 XPredict_Read_tree_93_Words(XPredict *InstancePtr, int offset, word_type *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length)*4 > (XPREDICT_TREE_ADDR_TREE_93_HIGH - XPREDICT_TREE_ADDR_TREE_93_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(data + i) = *(int *)(InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_93_BASE + (offset + i)*4);
    }
    return length;
}

u32 XPredict_Write_tree_93_Bytes(XPredict *InstancePtr, int offset, char *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length) > (XPREDICT_TREE_ADDR_TREE_93_HIGH - XPREDICT_TREE_ADDR_TREE_93_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(char *)(InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_93_BASE + offset + i) = *(data + i);
    }
    return length;
}

u32 XPredict_Read_tree_93_Bytes(XPredict *InstancePtr, int offset, char *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length) > (XPREDICT_TREE_ADDR_TREE_93_HIGH - XPREDICT_TREE_ADDR_TREE_93_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(data + i) = *(char *)(InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_93_BASE + offset + i);
    }
    return length;
}

u32 XPredict_Get_tree_94_BaseAddress(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_94_BASE);
}

u32 XPredict_Get_tree_94_HighAddress(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_94_HIGH);
}

u32 XPredict_Get_tree_94_TotalBytes(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (XPREDICT_TREE_ADDR_TREE_94_HIGH - XPREDICT_TREE_ADDR_TREE_94_BASE + 1);
}

u32 XPredict_Get_tree_94_BitWidth(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XPREDICT_TREE_WIDTH_TREE_94;
}

u32 XPredict_Get_tree_94_Depth(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XPREDICT_TREE_DEPTH_TREE_94;
}

u32 XPredict_Write_tree_94_Words(XPredict *InstancePtr, int offset, word_type *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length)*4 > (XPREDICT_TREE_ADDR_TREE_94_HIGH - XPREDICT_TREE_ADDR_TREE_94_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(int *)(InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_94_BASE + (offset + i)*4) = *(data + i);
    }
    return length;
}

u32 XPredict_Read_tree_94_Words(XPredict *InstancePtr, int offset, word_type *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length)*4 > (XPREDICT_TREE_ADDR_TREE_94_HIGH - XPREDICT_TREE_ADDR_TREE_94_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(data + i) = *(int *)(InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_94_BASE + (offset + i)*4);
    }
    return length;
}

u32 XPredict_Write_tree_94_Bytes(XPredict *InstancePtr, int offset, char *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length) > (XPREDICT_TREE_ADDR_TREE_94_HIGH - XPREDICT_TREE_ADDR_TREE_94_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(char *)(InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_94_BASE + offset + i) = *(data + i);
    }
    return length;
}

u32 XPredict_Read_tree_94_Bytes(XPredict *InstancePtr, int offset, char *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length) > (XPREDICT_TREE_ADDR_TREE_94_HIGH - XPREDICT_TREE_ADDR_TREE_94_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(data + i) = *(char *)(InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_94_BASE + offset + i);
    }
    return length;
}

u32 XPredict_Get_tree_95_BaseAddress(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_95_BASE);
}

u32 XPredict_Get_tree_95_HighAddress(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_95_HIGH);
}

u32 XPredict_Get_tree_95_TotalBytes(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (XPREDICT_TREE_ADDR_TREE_95_HIGH - XPREDICT_TREE_ADDR_TREE_95_BASE + 1);
}

u32 XPredict_Get_tree_95_BitWidth(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XPREDICT_TREE_WIDTH_TREE_95;
}

u32 XPredict_Get_tree_95_Depth(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XPREDICT_TREE_DEPTH_TREE_95;
}

u32 XPredict_Write_tree_95_Words(XPredict *InstancePtr, int offset, word_type *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length)*4 > (XPREDICT_TREE_ADDR_TREE_95_HIGH - XPREDICT_TREE_ADDR_TREE_95_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(int *)(InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_95_BASE + (offset + i)*4) = *(data + i);
    }
    return length;
}

u32 XPredict_Read_tree_95_Words(XPredict *InstancePtr, int offset, word_type *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length)*4 > (XPREDICT_TREE_ADDR_TREE_95_HIGH - XPREDICT_TREE_ADDR_TREE_95_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(data + i) = *(int *)(InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_95_BASE + (offset + i)*4);
    }
    return length;
}

u32 XPredict_Write_tree_95_Bytes(XPredict *InstancePtr, int offset, char *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length) > (XPREDICT_TREE_ADDR_TREE_95_HIGH - XPREDICT_TREE_ADDR_TREE_95_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(char *)(InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_95_BASE + offset + i) = *(data + i);
    }
    return length;
}

u32 XPredict_Read_tree_95_Bytes(XPredict *InstancePtr, int offset, char *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length) > (XPREDICT_TREE_ADDR_TREE_95_HIGH - XPREDICT_TREE_ADDR_TREE_95_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(data + i) = *(char *)(InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_95_BASE + offset + i);
    }
    return length;
}

u32 XPredict_Get_tree_96_BaseAddress(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_96_BASE);
}

u32 XPredict_Get_tree_96_HighAddress(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_96_HIGH);
}

u32 XPredict_Get_tree_96_TotalBytes(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (XPREDICT_TREE_ADDR_TREE_96_HIGH - XPREDICT_TREE_ADDR_TREE_96_BASE + 1);
}

u32 XPredict_Get_tree_96_BitWidth(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XPREDICT_TREE_WIDTH_TREE_96;
}

u32 XPredict_Get_tree_96_Depth(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XPREDICT_TREE_DEPTH_TREE_96;
}

u32 XPredict_Write_tree_96_Words(XPredict *InstancePtr, int offset, word_type *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length)*4 > (XPREDICT_TREE_ADDR_TREE_96_HIGH - XPREDICT_TREE_ADDR_TREE_96_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(int *)(InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_96_BASE + (offset + i)*4) = *(data + i);
    }
    return length;
}

u32 XPredict_Read_tree_96_Words(XPredict *InstancePtr, int offset, word_type *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length)*4 > (XPREDICT_TREE_ADDR_TREE_96_HIGH - XPREDICT_TREE_ADDR_TREE_96_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(data + i) = *(int *)(InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_96_BASE + (offset + i)*4);
    }
    return length;
}

u32 XPredict_Write_tree_96_Bytes(XPredict *InstancePtr, int offset, char *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length) > (XPREDICT_TREE_ADDR_TREE_96_HIGH - XPREDICT_TREE_ADDR_TREE_96_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(char *)(InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_96_BASE + offset + i) = *(data + i);
    }
    return length;
}

u32 XPredict_Read_tree_96_Bytes(XPredict *InstancePtr, int offset, char *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length) > (XPREDICT_TREE_ADDR_TREE_96_HIGH - XPREDICT_TREE_ADDR_TREE_96_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(data + i) = *(char *)(InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_96_BASE + offset + i);
    }
    return length;
}

u32 XPredict_Get_tree_97_BaseAddress(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_97_BASE);
}

u32 XPredict_Get_tree_97_HighAddress(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_97_HIGH);
}

u32 XPredict_Get_tree_97_TotalBytes(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (XPREDICT_TREE_ADDR_TREE_97_HIGH - XPREDICT_TREE_ADDR_TREE_97_BASE + 1);
}

u32 XPredict_Get_tree_97_BitWidth(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XPREDICT_TREE_WIDTH_TREE_97;
}

u32 XPredict_Get_tree_97_Depth(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XPREDICT_TREE_DEPTH_TREE_97;
}

u32 XPredict_Write_tree_97_Words(XPredict *InstancePtr, int offset, word_type *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length)*4 > (XPREDICT_TREE_ADDR_TREE_97_HIGH - XPREDICT_TREE_ADDR_TREE_97_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(int *)(InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_97_BASE + (offset + i)*4) = *(data + i);
    }
    return length;
}

u32 XPredict_Read_tree_97_Words(XPredict *InstancePtr, int offset, word_type *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length)*4 > (XPREDICT_TREE_ADDR_TREE_97_HIGH - XPREDICT_TREE_ADDR_TREE_97_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(data + i) = *(int *)(InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_97_BASE + (offset + i)*4);
    }
    return length;
}

u32 XPredict_Write_tree_97_Bytes(XPredict *InstancePtr, int offset, char *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length) > (XPREDICT_TREE_ADDR_TREE_97_HIGH - XPREDICT_TREE_ADDR_TREE_97_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(char *)(InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_97_BASE + offset + i) = *(data + i);
    }
    return length;
}

u32 XPredict_Read_tree_97_Bytes(XPredict *InstancePtr, int offset, char *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length) > (XPREDICT_TREE_ADDR_TREE_97_HIGH - XPREDICT_TREE_ADDR_TREE_97_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(data + i) = *(char *)(InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_97_BASE + offset + i);
    }
    return length;
}

u32 XPredict_Get_tree_98_BaseAddress(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_98_BASE);
}

u32 XPredict_Get_tree_98_HighAddress(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_98_HIGH);
}

u32 XPredict_Get_tree_98_TotalBytes(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (XPREDICT_TREE_ADDR_TREE_98_HIGH - XPREDICT_TREE_ADDR_TREE_98_BASE + 1);
}

u32 XPredict_Get_tree_98_BitWidth(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XPREDICT_TREE_WIDTH_TREE_98;
}

u32 XPredict_Get_tree_98_Depth(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XPREDICT_TREE_DEPTH_TREE_98;
}

u32 XPredict_Write_tree_98_Words(XPredict *InstancePtr, int offset, word_type *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length)*4 > (XPREDICT_TREE_ADDR_TREE_98_HIGH - XPREDICT_TREE_ADDR_TREE_98_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(int *)(InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_98_BASE + (offset + i)*4) = *(data + i);
    }
    return length;
}

u32 XPredict_Read_tree_98_Words(XPredict *InstancePtr, int offset, word_type *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length)*4 > (XPREDICT_TREE_ADDR_TREE_98_HIGH - XPREDICT_TREE_ADDR_TREE_98_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(data + i) = *(int *)(InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_98_BASE + (offset + i)*4);
    }
    return length;
}

u32 XPredict_Write_tree_98_Bytes(XPredict *InstancePtr, int offset, char *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length) > (XPREDICT_TREE_ADDR_TREE_98_HIGH - XPREDICT_TREE_ADDR_TREE_98_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(char *)(InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_98_BASE + offset + i) = *(data + i);
    }
    return length;
}

u32 XPredict_Read_tree_98_Bytes(XPredict *InstancePtr, int offset, char *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length) > (XPREDICT_TREE_ADDR_TREE_98_HIGH - XPREDICT_TREE_ADDR_TREE_98_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(data + i) = *(char *)(InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_98_BASE + offset + i);
    }
    return length;
}

u32 XPredict_Get_tree_99_BaseAddress(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_99_BASE);
}

u32 XPredict_Get_tree_99_HighAddress(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_99_HIGH);
}

u32 XPredict_Get_tree_99_TotalBytes(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (XPREDICT_TREE_ADDR_TREE_99_HIGH - XPREDICT_TREE_ADDR_TREE_99_BASE + 1);
}

u32 XPredict_Get_tree_99_BitWidth(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XPREDICT_TREE_WIDTH_TREE_99;
}

u32 XPredict_Get_tree_99_Depth(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XPREDICT_TREE_DEPTH_TREE_99;
}

u32 XPredict_Write_tree_99_Words(XPredict *InstancePtr, int offset, word_type *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length)*4 > (XPREDICT_TREE_ADDR_TREE_99_HIGH - XPREDICT_TREE_ADDR_TREE_99_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(int *)(InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_99_BASE + (offset + i)*4) = *(data + i);
    }
    return length;
}

u32 XPredict_Read_tree_99_Words(XPredict *InstancePtr, int offset, word_type *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length)*4 > (XPREDICT_TREE_ADDR_TREE_99_HIGH - XPREDICT_TREE_ADDR_TREE_99_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(data + i) = *(int *)(InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_99_BASE + (offset + i)*4);
    }
    return length;
}

u32 XPredict_Write_tree_99_Bytes(XPredict *InstancePtr, int offset, char *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length) > (XPREDICT_TREE_ADDR_TREE_99_HIGH - XPREDICT_TREE_ADDR_TREE_99_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(char *)(InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_99_BASE + offset + i) = *(data + i);
    }
    return length;
}

u32 XPredict_Read_tree_99_Bytes(XPredict *InstancePtr, int offset, char *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length) > (XPREDICT_TREE_ADDR_TREE_99_HIGH - XPREDICT_TREE_ADDR_TREE_99_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(data + i) = *(char *)(InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_99_BASE + offset + i);
    }
    return length;
}

u32 XPredict_Get_tree_100_BaseAddress(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_100_BASE);
}

u32 XPredict_Get_tree_100_HighAddress(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_100_HIGH);
}

u32 XPredict_Get_tree_100_TotalBytes(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (XPREDICT_TREE_ADDR_TREE_100_HIGH - XPREDICT_TREE_ADDR_TREE_100_BASE + 1);
}

u32 XPredict_Get_tree_100_BitWidth(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XPREDICT_TREE_WIDTH_TREE_100;
}

u32 XPredict_Get_tree_100_Depth(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XPREDICT_TREE_DEPTH_TREE_100;
}

u32 XPredict_Write_tree_100_Words(XPredict *InstancePtr, int offset, word_type *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length)*4 > (XPREDICT_TREE_ADDR_TREE_100_HIGH - XPREDICT_TREE_ADDR_TREE_100_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(int *)(InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_100_BASE + (offset + i)*4) = *(data + i);
    }
    return length;
}

u32 XPredict_Read_tree_100_Words(XPredict *InstancePtr, int offset, word_type *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length)*4 > (XPREDICT_TREE_ADDR_TREE_100_HIGH - XPREDICT_TREE_ADDR_TREE_100_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(data + i) = *(int *)(InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_100_BASE + (offset + i)*4);
    }
    return length;
}

u32 XPredict_Write_tree_100_Bytes(XPredict *InstancePtr, int offset, char *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length) > (XPREDICT_TREE_ADDR_TREE_100_HIGH - XPREDICT_TREE_ADDR_TREE_100_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(char *)(InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_100_BASE + offset + i) = *(data + i);
    }
    return length;
}

u32 XPredict_Read_tree_100_Bytes(XPredict *InstancePtr, int offset, char *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length) > (XPREDICT_TREE_ADDR_TREE_100_HIGH - XPREDICT_TREE_ADDR_TREE_100_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(data + i) = *(char *)(InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_100_BASE + offset + i);
    }
    return length;
}

u32 XPredict_Get_tree_101_BaseAddress(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_101_BASE);
}

u32 XPredict_Get_tree_101_HighAddress(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_101_HIGH);
}

u32 XPredict_Get_tree_101_TotalBytes(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (XPREDICT_TREE_ADDR_TREE_101_HIGH - XPREDICT_TREE_ADDR_TREE_101_BASE + 1);
}

u32 XPredict_Get_tree_101_BitWidth(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XPREDICT_TREE_WIDTH_TREE_101;
}

u32 XPredict_Get_tree_101_Depth(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XPREDICT_TREE_DEPTH_TREE_101;
}

u32 XPredict_Write_tree_101_Words(XPredict *InstancePtr, int offset, word_type *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length)*4 > (XPREDICT_TREE_ADDR_TREE_101_HIGH - XPREDICT_TREE_ADDR_TREE_101_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(int *)(InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_101_BASE + (offset + i)*4) = *(data + i);
    }
    return length;
}

u32 XPredict_Read_tree_101_Words(XPredict *InstancePtr, int offset, word_type *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length)*4 > (XPREDICT_TREE_ADDR_TREE_101_HIGH - XPREDICT_TREE_ADDR_TREE_101_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(data + i) = *(int *)(InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_101_BASE + (offset + i)*4);
    }
    return length;
}

u32 XPredict_Write_tree_101_Bytes(XPredict *InstancePtr, int offset, char *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length) > (XPREDICT_TREE_ADDR_TREE_101_HIGH - XPREDICT_TREE_ADDR_TREE_101_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(char *)(InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_101_BASE + offset + i) = *(data + i);
    }
    return length;
}

u32 XPredict_Read_tree_101_Bytes(XPredict *InstancePtr, int offset, char *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length) > (XPREDICT_TREE_ADDR_TREE_101_HIGH - XPREDICT_TREE_ADDR_TREE_101_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(data + i) = *(char *)(InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_101_BASE + offset + i);
    }
    return length;
}

u32 XPredict_Get_tree_102_BaseAddress(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_102_BASE);
}

u32 XPredict_Get_tree_102_HighAddress(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_102_HIGH);
}

u32 XPredict_Get_tree_102_TotalBytes(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (XPREDICT_TREE_ADDR_TREE_102_HIGH - XPREDICT_TREE_ADDR_TREE_102_BASE + 1);
}

u32 XPredict_Get_tree_102_BitWidth(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XPREDICT_TREE_WIDTH_TREE_102;
}

u32 XPredict_Get_tree_102_Depth(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XPREDICT_TREE_DEPTH_TREE_102;
}

u32 XPredict_Write_tree_102_Words(XPredict *InstancePtr, int offset, word_type *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length)*4 > (XPREDICT_TREE_ADDR_TREE_102_HIGH - XPREDICT_TREE_ADDR_TREE_102_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(int *)(InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_102_BASE + (offset + i)*4) = *(data + i);
    }
    return length;
}

u32 XPredict_Read_tree_102_Words(XPredict *InstancePtr, int offset, word_type *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length)*4 > (XPREDICT_TREE_ADDR_TREE_102_HIGH - XPREDICT_TREE_ADDR_TREE_102_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(data + i) = *(int *)(InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_102_BASE + (offset + i)*4);
    }
    return length;
}

u32 XPredict_Write_tree_102_Bytes(XPredict *InstancePtr, int offset, char *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length) > (XPREDICT_TREE_ADDR_TREE_102_HIGH - XPREDICT_TREE_ADDR_TREE_102_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(char *)(InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_102_BASE + offset + i) = *(data + i);
    }
    return length;
}

u32 XPredict_Read_tree_102_Bytes(XPredict *InstancePtr, int offset, char *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length) > (XPREDICT_TREE_ADDR_TREE_102_HIGH - XPREDICT_TREE_ADDR_TREE_102_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(data + i) = *(char *)(InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_102_BASE + offset + i);
    }
    return length;
}

u32 XPredict_Get_tree_103_BaseAddress(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_103_BASE);
}

u32 XPredict_Get_tree_103_HighAddress(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_103_HIGH);
}

u32 XPredict_Get_tree_103_TotalBytes(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (XPREDICT_TREE_ADDR_TREE_103_HIGH - XPREDICT_TREE_ADDR_TREE_103_BASE + 1);
}

u32 XPredict_Get_tree_103_BitWidth(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XPREDICT_TREE_WIDTH_TREE_103;
}

u32 XPredict_Get_tree_103_Depth(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XPREDICT_TREE_DEPTH_TREE_103;
}

u32 XPredict_Write_tree_103_Words(XPredict *InstancePtr, int offset, word_type *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length)*4 > (XPREDICT_TREE_ADDR_TREE_103_HIGH - XPREDICT_TREE_ADDR_TREE_103_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(int *)(InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_103_BASE + (offset + i)*4) = *(data + i);
    }
    return length;
}

u32 XPredict_Read_tree_103_Words(XPredict *InstancePtr, int offset, word_type *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length)*4 > (XPREDICT_TREE_ADDR_TREE_103_HIGH - XPREDICT_TREE_ADDR_TREE_103_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(data + i) = *(int *)(InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_103_BASE + (offset + i)*4);
    }
    return length;
}

u32 XPredict_Write_tree_103_Bytes(XPredict *InstancePtr, int offset, char *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length) > (XPREDICT_TREE_ADDR_TREE_103_HIGH - XPREDICT_TREE_ADDR_TREE_103_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(char *)(InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_103_BASE + offset + i) = *(data + i);
    }
    return length;
}

u32 XPredict_Read_tree_103_Bytes(XPredict *InstancePtr, int offset, char *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length) > (XPREDICT_TREE_ADDR_TREE_103_HIGH - XPREDICT_TREE_ADDR_TREE_103_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(data + i) = *(char *)(InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_103_BASE + offset + i);
    }
    return length;
}

u32 XPredict_Get_tree_104_BaseAddress(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_104_BASE);
}

u32 XPredict_Get_tree_104_HighAddress(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_104_HIGH);
}

u32 XPredict_Get_tree_104_TotalBytes(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (XPREDICT_TREE_ADDR_TREE_104_HIGH - XPREDICT_TREE_ADDR_TREE_104_BASE + 1);
}

u32 XPredict_Get_tree_104_BitWidth(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XPREDICT_TREE_WIDTH_TREE_104;
}

u32 XPredict_Get_tree_104_Depth(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XPREDICT_TREE_DEPTH_TREE_104;
}

u32 XPredict_Write_tree_104_Words(XPredict *InstancePtr, int offset, word_type *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length)*4 > (XPREDICT_TREE_ADDR_TREE_104_HIGH - XPREDICT_TREE_ADDR_TREE_104_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(int *)(InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_104_BASE + (offset + i)*4) = *(data + i);
    }
    return length;
}

u32 XPredict_Read_tree_104_Words(XPredict *InstancePtr, int offset, word_type *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length)*4 > (XPREDICT_TREE_ADDR_TREE_104_HIGH - XPREDICT_TREE_ADDR_TREE_104_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(data + i) = *(int *)(InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_104_BASE + (offset + i)*4);
    }
    return length;
}

u32 XPredict_Write_tree_104_Bytes(XPredict *InstancePtr, int offset, char *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length) > (XPREDICT_TREE_ADDR_TREE_104_HIGH - XPREDICT_TREE_ADDR_TREE_104_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(char *)(InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_104_BASE + offset + i) = *(data + i);
    }
    return length;
}

u32 XPredict_Read_tree_104_Bytes(XPredict *InstancePtr, int offset, char *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length) > (XPREDICT_TREE_ADDR_TREE_104_HIGH - XPREDICT_TREE_ADDR_TREE_104_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(data + i) = *(char *)(InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_104_BASE + offset + i);
    }
    return length;
}

u32 XPredict_Get_tree_105_BaseAddress(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_105_BASE);
}

u32 XPredict_Get_tree_105_HighAddress(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_105_HIGH);
}

u32 XPredict_Get_tree_105_TotalBytes(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (XPREDICT_TREE_ADDR_TREE_105_HIGH - XPREDICT_TREE_ADDR_TREE_105_BASE + 1);
}

u32 XPredict_Get_tree_105_BitWidth(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XPREDICT_TREE_WIDTH_TREE_105;
}

u32 XPredict_Get_tree_105_Depth(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XPREDICT_TREE_DEPTH_TREE_105;
}

u32 XPredict_Write_tree_105_Words(XPredict *InstancePtr, int offset, word_type *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length)*4 > (XPREDICT_TREE_ADDR_TREE_105_HIGH - XPREDICT_TREE_ADDR_TREE_105_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(int *)(InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_105_BASE + (offset + i)*4) = *(data + i);
    }
    return length;
}

u32 XPredict_Read_tree_105_Words(XPredict *InstancePtr, int offset, word_type *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length)*4 > (XPREDICT_TREE_ADDR_TREE_105_HIGH - XPREDICT_TREE_ADDR_TREE_105_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(data + i) = *(int *)(InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_105_BASE + (offset + i)*4);
    }
    return length;
}

u32 XPredict_Write_tree_105_Bytes(XPredict *InstancePtr, int offset, char *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length) > (XPREDICT_TREE_ADDR_TREE_105_HIGH - XPREDICT_TREE_ADDR_TREE_105_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(char *)(InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_105_BASE + offset + i) = *(data + i);
    }
    return length;
}

u32 XPredict_Read_tree_105_Bytes(XPredict *InstancePtr, int offset, char *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length) > (XPREDICT_TREE_ADDR_TREE_105_HIGH - XPREDICT_TREE_ADDR_TREE_105_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(data + i) = *(char *)(InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_105_BASE + offset + i);
    }
    return length;
}

u32 XPredict_Get_tree_106_BaseAddress(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_106_BASE);
}

u32 XPredict_Get_tree_106_HighAddress(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_106_HIGH);
}

u32 XPredict_Get_tree_106_TotalBytes(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (XPREDICT_TREE_ADDR_TREE_106_HIGH - XPREDICT_TREE_ADDR_TREE_106_BASE + 1);
}

u32 XPredict_Get_tree_106_BitWidth(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XPREDICT_TREE_WIDTH_TREE_106;
}

u32 XPredict_Get_tree_106_Depth(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XPREDICT_TREE_DEPTH_TREE_106;
}

u32 XPredict_Write_tree_106_Words(XPredict *InstancePtr, int offset, word_type *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length)*4 > (XPREDICT_TREE_ADDR_TREE_106_HIGH - XPREDICT_TREE_ADDR_TREE_106_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(int *)(InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_106_BASE + (offset + i)*4) = *(data + i);
    }
    return length;
}

u32 XPredict_Read_tree_106_Words(XPredict *InstancePtr, int offset, word_type *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length)*4 > (XPREDICT_TREE_ADDR_TREE_106_HIGH - XPREDICT_TREE_ADDR_TREE_106_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(data + i) = *(int *)(InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_106_BASE + (offset + i)*4);
    }
    return length;
}

u32 XPredict_Write_tree_106_Bytes(XPredict *InstancePtr, int offset, char *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length) > (XPREDICT_TREE_ADDR_TREE_106_HIGH - XPREDICT_TREE_ADDR_TREE_106_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(char *)(InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_106_BASE + offset + i) = *(data + i);
    }
    return length;
}

u32 XPredict_Read_tree_106_Bytes(XPredict *InstancePtr, int offset, char *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length) > (XPREDICT_TREE_ADDR_TREE_106_HIGH - XPREDICT_TREE_ADDR_TREE_106_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(data + i) = *(char *)(InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_106_BASE + offset + i);
    }
    return length;
}

u32 XPredict_Get_tree_107_BaseAddress(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_107_BASE);
}

u32 XPredict_Get_tree_107_HighAddress(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_107_HIGH);
}

u32 XPredict_Get_tree_107_TotalBytes(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (XPREDICT_TREE_ADDR_TREE_107_HIGH - XPREDICT_TREE_ADDR_TREE_107_BASE + 1);
}

u32 XPredict_Get_tree_107_BitWidth(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XPREDICT_TREE_WIDTH_TREE_107;
}

u32 XPredict_Get_tree_107_Depth(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XPREDICT_TREE_DEPTH_TREE_107;
}

u32 XPredict_Write_tree_107_Words(XPredict *InstancePtr, int offset, word_type *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length)*4 > (XPREDICT_TREE_ADDR_TREE_107_HIGH - XPREDICT_TREE_ADDR_TREE_107_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(int *)(InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_107_BASE + (offset + i)*4) = *(data + i);
    }
    return length;
}

u32 XPredict_Read_tree_107_Words(XPredict *InstancePtr, int offset, word_type *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length)*4 > (XPREDICT_TREE_ADDR_TREE_107_HIGH - XPREDICT_TREE_ADDR_TREE_107_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(data + i) = *(int *)(InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_107_BASE + (offset + i)*4);
    }
    return length;
}

u32 XPredict_Write_tree_107_Bytes(XPredict *InstancePtr, int offset, char *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length) > (XPREDICT_TREE_ADDR_TREE_107_HIGH - XPREDICT_TREE_ADDR_TREE_107_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(char *)(InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_107_BASE + offset + i) = *(data + i);
    }
    return length;
}

u32 XPredict_Read_tree_107_Bytes(XPredict *InstancePtr, int offset, char *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length) > (XPREDICT_TREE_ADDR_TREE_107_HIGH - XPREDICT_TREE_ADDR_TREE_107_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(data + i) = *(char *)(InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_107_BASE + offset + i);
    }
    return length;
}

u32 XPredict_Get_tree_108_BaseAddress(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_108_BASE);
}

u32 XPredict_Get_tree_108_HighAddress(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_108_HIGH);
}

u32 XPredict_Get_tree_108_TotalBytes(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (XPREDICT_TREE_ADDR_TREE_108_HIGH - XPREDICT_TREE_ADDR_TREE_108_BASE + 1);
}

u32 XPredict_Get_tree_108_BitWidth(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XPREDICT_TREE_WIDTH_TREE_108;
}

u32 XPredict_Get_tree_108_Depth(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XPREDICT_TREE_DEPTH_TREE_108;
}

u32 XPredict_Write_tree_108_Words(XPredict *InstancePtr, int offset, word_type *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length)*4 > (XPREDICT_TREE_ADDR_TREE_108_HIGH - XPREDICT_TREE_ADDR_TREE_108_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(int *)(InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_108_BASE + (offset + i)*4) = *(data + i);
    }
    return length;
}

u32 XPredict_Read_tree_108_Words(XPredict *InstancePtr, int offset, word_type *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length)*4 > (XPREDICT_TREE_ADDR_TREE_108_HIGH - XPREDICT_TREE_ADDR_TREE_108_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(data + i) = *(int *)(InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_108_BASE + (offset + i)*4);
    }
    return length;
}

u32 XPredict_Write_tree_108_Bytes(XPredict *InstancePtr, int offset, char *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length) > (XPREDICT_TREE_ADDR_TREE_108_HIGH - XPREDICT_TREE_ADDR_TREE_108_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(char *)(InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_108_BASE + offset + i) = *(data + i);
    }
    return length;
}

u32 XPredict_Read_tree_108_Bytes(XPredict *InstancePtr, int offset, char *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length) > (XPREDICT_TREE_ADDR_TREE_108_HIGH - XPREDICT_TREE_ADDR_TREE_108_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(data + i) = *(char *)(InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_108_BASE + offset + i);
    }
    return length;
}

u32 XPredict_Get_tree_109_BaseAddress(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_109_BASE);
}

u32 XPredict_Get_tree_109_HighAddress(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_109_HIGH);
}

u32 XPredict_Get_tree_109_TotalBytes(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (XPREDICT_TREE_ADDR_TREE_109_HIGH - XPREDICT_TREE_ADDR_TREE_109_BASE + 1);
}

u32 XPredict_Get_tree_109_BitWidth(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XPREDICT_TREE_WIDTH_TREE_109;
}

u32 XPredict_Get_tree_109_Depth(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XPREDICT_TREE_DEPTH_TREE_109;
}

u32 XPredict_Write_tree_109_Words(XPredict *InstancePtr, int offset, word_type *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length)*4 > (XPREDICT_TREE_ADDR_TREE_109_HIGH - XPREDICT_TREE_ADDR_TREE_109_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(int *)(InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_109_BASE + (offset + i)*4) = *(data + i);
    }
    return length;
}

u32 XPredict_Read_tree_109_Words(XPredict *InstancePtr, int offset, word_type *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length)*4 > (XPREDICT_TREE_ADDR_TREE_109_HIGH - XPREDICT_TREE_ADDR_TREE_109_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(data + i) = *(int *)(InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_109_BASE + (offset + i)*4);
    }
    return length;
}

u32 XPredict_Write_tree_109_Bytes(XPredict *InstancePtr, int offset, char *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length) > (XPREDICT_TREE_ADDR_TREE_109_HIGH - XPREDICT_TREE_ADDR_TREE_109_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(char *)(InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_109_BASE + offset + i) = *(data + i);
    }
    return length;
}

u32 XPredict_Read_tree_109_Bytes(XPredict *InstancePtr, int offset, char *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length) > (XPREDICT_TREE_ADDR_TREE_109_HIGH - XPREDICT_TREE_ADDR_TREE_109_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(data + i) = *(char *)(InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_109_BASE + offset + i);
    }
    return length;
}

u32 XPredict_Get_tree_110_BaseAddress(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_110_BASE);
}

u32 XPredict_Get_tree_110_HighAddress(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_110_HIGH);
}

u32 XPredict_Get_tree_110_TotalBytes(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (XPREDICT_TREE_ADDR_TREE_110_HIGH - XPREDICT_TREE_ADDR_TREE_110_BASE + 1);
}

u32 XPredict_Get_tree_110_BitWidth(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XPREDICT_TREE_WIDTH_TREE_110;
}

u32 XPredict_Get_tree_110_Depth(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XPREDICT_TREE_DEPTH_TREE_110;
}

u32 XPredict_Write_tree_110_Words(XPredict *InstancePtr, int offset, word_type *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length)*4 > (XPREDICT_TREE_ADDR_TREE_110_HIGH - XPREDICT_TREE_ADDR_TREE_110_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(int *)(InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_110_BASE + (offset + i)*4) = *(data + i);
    }
    return length;
}

u32 XPredict_Read_tree_110_Words(XPredict *InstancePtr, int offset, word_type *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length)*4 > (XPREDICT_TREE_ADDR_TREE_110_HIGH - XPREDICT_TREE_ADDR_TREE_110_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(data + i) = *(int *)(InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_110_BASE + (offset + i)*4);
    }
    return length;
}

u32 XPredict_Write_tree_110_Bytes(XPredict *InstancePtr, int offset, char *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length) > (XPREDICT_TREE_ADDR_TREE_110_HIGH - XPREDICT_TREE_ADDR_TREE_110_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(char *)(InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_110_BASE + offset + i) = *(data + i);
    }
    return length;
}

u32 XPredict_Read_tree_110_Bytes(XPredict *InstancePtr, int offset, char *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length) > (XPREDICT_TREE_ADDR_TREE_110_HIGH - XPREDICT_TREE_ADDR_TREE_110_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(data + i) = *(char *)(InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_110_BASE + offset + i);
    }
    return length;
}

u32 XPredict_Get_tree_111_BaseAddress(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_111_BASE);
}

u32 XPredict_Get_tree_111_HighAddress(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_111_HIGH);
}

u32 XPredict_Get_tree_111_TotalBytes(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (XPREDICT_TREE_ADDR_TREE_111_HIGH - XPREDICT_TREE_ADDR_TREE_111_BASE + 1);
}

u32 XPredict_Get_tree_111_BitWidth(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XPREDICT_TREE_WIDTH_TREE_111;
}

u32 XPredict_Get_tree_111_Depth(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XPREDICT_TREE_DEPTH_TREE_111;
}

u32 XPredict_Write_tree_111_Words(XPredict *InstancePtr, int offset, word_type *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length)*4 > (XPREDICT_TREE_ADDR_TREE_111_HIGH - XPREDICT_TREE_ADDR_TREE_111_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(int *)(InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_111_BASE + (offset + i)*4) = *(data + i);
    }
    return length;
}

u32 XPredict_Read_tree_111_Words(XPredict *InstancePtr, int offset, word_type *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length)*4 > (XPREDICT_TREE_ADDR_TREE_111_HIGH - XPREDICT_TREE_ADDR_TREE_111_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(data + i) = *(int *)(InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_111_BASE + (offset + i)*4);
    }
    return length;
}

u32 XPredict_Write_tree_111_Bytes(XPredict *InstancePtr, int offset, char *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length) > (XPREDICT_TREE_ADDR_TREE_111_HIGH - XPREDICT_TREE_ADDR_TREE_111_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(char *)(InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_111_BASE + offset + i) = *(data + i);
    }
    return length;
}

u32 XPredict_Read_tree_111_Bytes(XPredict *InstancePtr, int offset, char *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length) > (XPREDICT_TREE_ADDR_TREE_111_HIGH - XPREDICT_TREE_ADDR_TREE_111_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(data + i) = *(char *)(InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_111_BASE + offset + i);
    }
    return length;
}

u32 XPredict_Get_tree_112_BaseAddress(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_112_BASE);
}

u32 XPredict_Get_tree_112_HighAddress(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_112_HIGH);
}

u32 XPredict_Get_tree_112_TotalBytes(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (XPREDICT_TREE_ADDR_TREE_112_HIGH - XPREDICT_TREE_ADDR_TREE_112_BASE + 1);
}

u32 XPredict_Get_tree_112_BitWidth(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XPREDICT_TREE_WIDTH_TREE_112;
}

u32 XPredict_Get_tree_112_Depth(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XPREDICT_TREE_DEPTH_TREE_112;
}

u32 XPredict_Write_tree_112_Words(XPredict *InstancePtr, int offset, word_type *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length)*4 > (XPREDICT_TREE_ADDR_TREE_112_HIGH - XPREDICT_TREE_ADDR_TREE_112_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(int *)(InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_112_BASE + (offset + i)*4) = *(data + i);
    }
    return length;
}

u32 XPredict_Read_tree_112_Words(XPredict *InstancePtr, int offset, word_type *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length)*4 > (XPREDICT_TREE_ADDR_TREE_112_HIGH - XPREDICT_TREE_ADDR_TREE_112_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(data + i) = *(int *)(InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_112_BASE + (offset + i)*4);
    }
    return length;
}

u32 XPredict_Write_tree_112_Bytes(XPredict *InstancePtr, int offset, char *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length) > (XPREDICT_TREE_ADDR_TREE_112_HIGH - XPREDICT_TREE_ADDR_TREE_112_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(char *)(InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_112_BASE + offset + i) = *(data + i);
    }
    return length;
}

u32 XPredict_Read_tree_112_Bytes(XPredict *InstancePtr, int offset, char *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length) > (XPREDICT_TREE_ADDR_TREE_112_HIGH - XPREDICT_TREE_ADDR_TREE_112_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(data + i) = *(char *)(InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_112_BASE + offset + i);
    }
    return length;
}

u32 XPredict_Get_tree_113_BaseAddress(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_113_BASE);
}

u32 XPredict_Get_tree_113_HighAddress(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_113_HIGH);
}

u32 XPredict_Get_tree_113_TotalBytes(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (XPREDICT_TREE_ADDR_TREE_113_HIGH - XPREDICT_TREE_ADDR_TREE_113_BASE + 1);
}

u32 XPredict_Get_tree_113_BitWidth(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XPREDICT_TREE_WIDTH_TREE_113;
}

u32 XPredict_Get_tree_113_Depth(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XPREDICT_TREE_DEPTH_TREE_113;
}

u32 XPredict_Write_tree_113_Words(XPredict *InstancePtr, int offset, word_type *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length)*4 > (XPREDICT_TREE_ADDR_TREE_113_HIGH - XPREDICT_TREE_ADDR_TREE_113_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(int *)(InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_113_BASE + (offset + i)*4) = *(data + i);
    }
    return length;
}

u32 XPredict_Read_tree_113_Words(XPredict *InstancePtr, int offset, word_type *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length)*4 > (XPREDICT_TREE_ADDR_TREE_113_HIGH - XPREDICT_TREE_ADDR_TREE_113_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(data + i) = *(int *)(InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_113_BASE + (offset + i)*4);
    }
    return length;
}

u32 XPredict_Write_tree_113_Bytes(XPredict *InstancePtr, int offset, char *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length) > (XPREDICT_TREE_ADDR_TREE_113_HIGH - XPREDICT_TREE_ADDR_TREE_113_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(char *)(InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_113_BASE + offset + i) = *(data + i);
    }
    return length;
}

u32 XPredict_Read_tree_113_Bytes(XPredict *InstancePtr, int offset, char *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length) > (XPREDICT_TREE_ADDR_TREE_113_HIGH - XPREDICT_TREE_ADDR_TREE_113_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(data + i) = *(char *)(InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_113_BASE + offset + i);
    }
    return length;
}

u32 XPredict_Get_tree_114_BaseAddress(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_114_BASE);
}

u32 XPredict_Get_tree_114_HighAddress(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_114_HIGH);
}

u32 XPredict_Get_tree_114_TotalBytes(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (XPREDICT_TREE_ADDR_TREE_114_HIGH - XPREDICT_TREE_ADDR_TREE_114_BASE + 1);
}

u32 XPredict_Get_tree_114_BitWidth(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XPREDICT_TREE_WIDTH_TREE_114;
}

u32 XPredict_Get_tree_114_Depth(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XPREDICT_TREE_DEPTH_TREE_114;
}

u32 XPredict_Write_tree_114_Words(XPredict *InstancePtr, int offset, word_type *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length)*4 > (XPREDICT_TREE_ADDR_TREE_114_HIGH - XPREDICT_TREE_ADDR_TREE_114_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(int *)(InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_114_BASE + (offset + i)*4) = *(data + i);
    }
    return length;
}

u32 XPredict_Read_tree_114_Words(XPredict *InstancePtr, int offset, word_type *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length)*4 > (XPREDICT_TREE_ADDR_TREE_114_HIGH - XPREDICT_TREE_ADDR_TREE_114_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(data + i) = *(int *)(InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_114_BASE + (offset + i)*4);
    }
    return length;
}

u32 XPredict_Write_tree_114_Bytes(XPredict *InstancePtr, int offset, char *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length) > (XPREDICT_TREE_ADDR_TREE_114_HIGH - XPREDICT_TREE_ADDR_TREE_114_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(char *)(InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_114_BASE + offset + i) = *(data + i);
    }
    return length;
}

u32 XPredict_Read_tree_114_Bytes(XPredict *InstancePtr, int offset, char *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length) > (XPREDICT_TREE_ADDR_TREE_114_HIGH - XPREDICT_TREE_ADDR_TREE_114_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(data + i) = *(char *)(InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_114_BASE + offset + i);
    }
    return length;
}

u32 XPredict_Get_tree_115_BaseAddress(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_115_BASE);
}

u32 XPredict_Get_tree_115_HighAddress(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_115_HIGH);
}

u32 XPredict_Get_tree_115_TotalBytes(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (XPREDICT_TREE_ADDR_TREE_115_HIGH - XPREDICT_TREE_ADDR_TREE_115_BASE + 1);
}

u32 XPredict_Get_tree_115_BitWidth(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XPREDICT_TREE_WIDTH_TREE_115;
}

u32 XPredict_Get_tree_115_Depth(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XPREDICT_TREE_DEPTH_TREE_115;
}

u32 XPredict_Write_tree_115_Words(XPredict *InstancePtr, int offset, word_type *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length)*4 > (XPREDICT_TREE_ADDR_TREE_115_HIGH - XPREDICT_TREE_ADDR_TREE_115_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(int *)(InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_115_BASE + (offset + i)*4) = *(data + i);
    }
    return length;
}

u32 XPredict_Read_tree_115_Words(XPredict *InstancePtr, int offset, word_type *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length)*4 > (XPREDICT_TREE_ADDR_TREE_115_HIGH - XPREDICT_TREE_ADDR_TREE_115_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(data + i) = *(int *)(InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_115_BASE + (offset + i)*4);
    }
    return length;
}

u32 XPredict_Write_tree_115_Bytes(XPredict *InstancePtr, int offset, char *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length) > (XPREDICT_TREE_ADDR_TREE_115_HIGH - XPREDICT_TREE_ADDR_TREE_115_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(char *)(InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_115_BASE + offset + i) = *(data + i);
    }
    return length;
}

u32 XPredict_Read_tree_115_Bytes(XPredict *InstancePtr, int offset, char *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length) > (XPREDICT_TREE_ADDR_TREE_115_HIGH - XPREDICT_TREE_ADDR_TREE_115_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(data + i) = *(char *)(InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_115_BASE + offset + i);
    }
    return length;
}

u32 XPredict_Get_tree_116_BaseAddress(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_116_BASE);
}

u32 XPredict_Get_tree_116_HighAddress(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_116_HIGH);
}

u32 XPredict_Get_tree_116_TotalBytes(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (XPREDICT_TREE_ADDR_TREE_116_HIGH - XPREDICT_TREE_ADDR_TREE_116_BASE + 1);
}

u32 XPredict_Get_tree_116_BitWidth(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XPREDICT_TREE_WIDTH_TREE_116;
}

u32 XPredict_Get_tree_116_Depth(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XPREDICT_TREE_DEPTH_TREE_116;
}

u32 XPredict_Write_tree_116_Words(XPredict *InstancePtr, int offset, word_type *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length)*4 > (XPREDICT_TREE_ADDR_TREE_116_HIGH - XPREDICT_TREE_ADDR_TREE_116_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(int *)(InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_116_BASE + (offset + i)*4) = *(data + i);
    }
    return length;
}

u32 XPredict_Read_tree_116_Words(XPredict *InstancePtr, int offset, word_type *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length)*4 > (XPREDICT_TREE_ADDR_TREE_116_HIGH - XPREDICT_TREE_ADDR_TREE_116_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(data + i) = *(int *)(InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_116_BASE + (offset + i)*4);
    }
    return length;
}

u32 XPredict_Write_tree_116_Bytes(XPredict *InstancePtr, int offset, char *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length) > (XPREDICT_TREE_ADDR_TREE_116_HIGH - XPREDICT_TREE_ADDR_TREE_116_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(char *)(InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_116_BASE + offset + i) = *(data + i);
    }
    return length;
}

u32 XPredict_Read_tree_116_Bytes(XPredict *InstancePtr, int offset, char *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length) > (XPREDICT_TREE_ADDR_TREE_116_HIGH - XPREDICT_TREE_ADDR_TREE_116_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(data + i) = *(char *)(InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_116_BASE + offset + i);
    }
    return length;
}

u32 XPredict_Get_tree_117_BaseAddress(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_117_BASE);
}

u32 XPredict_Get_tree_117_HighAddress(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_117_HIGH);
}

u32 XPredict_Get_tree_117_TotalBytes(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (XPREDICT_TREE_ADDR_TREE_117_HIGH - XPREDICT_TREE_ADDR_TREE_117_BASE + 1);
}

u32 XPredict_Get_tree_117_BitWidth(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XPREDICT_TREE_WIDTH_TREE_117;
}

u32 XPredict_Get_tree_117_Depth(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XPREDICT_TREE_DEPTH_TREE_117;
}

u32 XPredict_Write_tree_117_Words(XPredict *InstancePtr, int offset, word_type *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length)*4 > (XPREDICT_TREE_ADDR_TREE_117_HIGH - XPREDICT_TREE_ADDR_TREE_117_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(int *)(InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_117_BASE + (offset + i)*4) = *(data + i);
    }
    return length;
}

u32 XPredict_Read_tree_117_Words(XPredict *InstancePtr, int offset, word_type *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length)*4 > (XPREDICT_TREE_ADDR_TREE_117_HIGH - XPREDICT_TREE_ADDR_TREE_117_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(data + i) = *(int *)(InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_117_BASE + (offset + i)*4);
    }
    return length;
}

u32 XPredict_Write_tree_117_Bytes(XPredict *InstancePtr, int offset, char *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length) > (XPREDICT_TREE_ADDR_TREE_117_HIGH - XPREDICT_TREE_ADDR_TREE_117_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(char *)(InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_117_BASE + offset + i) = *(data + i);
    }
    return length;
}

u32 XPredict_Read_tree_117_Bytes(XPredict *InstancePtr, int offset, char *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length) > (XPREDICT_TREE_ADDR_TREE_117_HIGH - XPREDICT_TREE_ADDR_TREE_117_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(data + i) = *(char *)(InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_117_BASE + offset + i);
    }
    return length;
}

u32 XPredict_Get_tree_118_BaseAddress(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_118_BASE);
}

u32 XPredict_Get_tree_118_HighAddress(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_118_HIGH);
}

u32 XPredict_Get_tree_118_TotalBytes(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (XPREDICT_TREE_ADDR_TREE_118_HIGH - XPREDICT_TREE_ADDR_TREE_118_BASE + 1);
}

u32 XPredict_Get_tree_118_BitWidth(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XPREDICT_TREE_WIDTH_TREE_118;
}

u32 XPredict_Get_tree_118_Depth(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XPREDICT_TREE_DEPTH_TREE_118;
}

u32 XPredict_Write_tree_118_Words(XPredict *InstancePtr, int offset, word_type *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length)*4 > (XPREDICT_TREE_ADDR_TREE_118_HIGH - XPREDICT_TREE_ADDR_TREE_118_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(int *)(InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_118_BASE + (offset + i)*4) = *(data + i);
    }
    return length;
}

u32 XPredict_Read_tree_118_Words(XPredict *InstancePtr, int offset, word_type *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length)*4 > (XPREDICT_TREE_ADDR_TREE_118_HIGH - XPREDICT_TREE_ADDR_TREE_118_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(data + i) = *(int *)(InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_118_BASE + (offset + i)*4);
    }
    return length;
}

u32 XPredict_Write_tree_118_Bytes(XPredict *InstancePtr, int offset, char *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length) > (XPREDICT_TREE_ADDR_TREE_118_HIGH - XPREDICT_TREE_ADDR_TREE_118_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(char *)(InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_118_BASE + offset + i) = *(data + i);
    }
    return length;
}

u32 XPredict_Read_tree_118_Bytes(XPredict *InstancePtr, int offset, char *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length) > (XPREDICT_TREE_ADDR_TREE_118_HIGH - XPREDICT_TREE_ADDR_TREE_118_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(data + i) = *(char *)(InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_118_BASE + offset + i);
    }
    return length;
}

u32 XPredict_Get_tree_119_BaseAddress(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_119_BASE);
}

u32 XPredict_Get_tree_119_HighAddress(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_119_HIGH);
}

u32 XPredict_Get_tree_119_TotalBytes(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (XPREDICT_TREE_ADDR_TREE_119_HIGH - XPREDICT_TREE_ADDR_TREE_119_BASE + 1);
}

u32 XPredict_Get_tree_119_BitWidth(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XPREDICT_TREE_WIDTH_TREE_119;
}

u32 XPredict_Get_tree_119_Depth(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XPREDICT_TREE_DEPTH_TREE_119;
}

u32 XPredict_Write_tree_119_Words(XPredict *InstancePtr, int offset, word_type *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length)*4 > (XPREDICT_TREE_ADDR_TREE_119_HIGH - XPREDICT_TREE_ADDR_TREE_119_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(int *)(InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_119_BASE + (offset + i)*4) = *(data + i);
    }
    return length;
}

u32 XPredict_Read_tree_119_Words(XPredict *InstancePtr, int offset, word_type *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length)*4 > (XPREDICT_TREE_ADDR_TREE_119_HIGH - XPREDICT_TREE_ADDR_TREE_119_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(data + i) = *(int *)(InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_119_BASE + (offset + i)*4);
    }
    return length;
}

u32 XPredict_Write_tree_119_Bytes(XPredict *InstancePtr, int offset, char *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length) > (XPREDICT_TREE_ADDR_TREE_119_HIGH - XPREDICT_TREE_ADDR_TREE_119_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(char *)(InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_119_BASE + offset + i) = *(data + i);
    }
    return length;
}

u32 XPredict_Read_tree_119_Bytes(XPredict *InstancePtr, int offset, char *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length) > (XPREDICT_TREE_ADDR_TREE_119_HIGH - XPREDICT_TREE_ADDR_TREE_119_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(data + i) = *(char *)(InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_119_BASE + offset + i);
    }
    return length;
}

u32 XPredict_Get_tree_120_BaseAddress(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_120_BASE);
}

u32 XPredict_Get_tree_120_HighAddress(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_120_HIGH);
}

u32 XPredict_Get_tree_120_TotalBytes(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (XPREDICT_TREE_ADDR_TREE_120_HIGH - XPREDICT_TREE_ADDR_TREE_120_BASE + 1);
}

u32 XPredict_Get_tree_120_BitWidth(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XPREDICT_TREE_WIDTH_TREE_120;
}

u32 XPredict_Get_tree_120_Depth(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XPREDICT_TREE_DEPTH_TREE_120;
}

u32 XPredict_Write_tree_120_Words(XPredict *InstancePtr, int offset, word_type *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length)*4 > (XPREDICT_TREE_ADDR_TREE_120_HIGH - XPREDICT_TREE_ADDR_TREE_120_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(int *)(InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_120_BASE + (offset + i)*4) = *(data + i);
    }
    return length;
}

u32 XPredict_Read_tree_120_Words(XPredict *InstancePtr, int offset, word_type *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length)*4 > (XPREDICT_TREE_ADDR_TREE_120_HIGH - XPREDICT_TREE_ADDR_TREE_120_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(data + i) = *(int *)(InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_120_BASE + (offset + i)*4);
    }
    return length;
}

u32 XPredict_Write_tree_120_Bytes(XPredict *InstancePtr, int offset, char *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length) > (XPREDICT_TREE_ADDR_TREE_120_HIGH - XPREDICT_TREE_ADDR_TREE_120_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(char *)(InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_120_BASE + offset + i) = *(data + i);
    }
    return length;
}

u32 XPredict_Read_tree_120_Bytes(XPredict *InstancePtr, int offset, char *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length) > (XPREDICT_TREE_ADDR_TREE_120_HIGH - XPREDICT_TREE_ADDR_TREE_120_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(data + i) = *(char *)(InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_120_BASE + offset + i);
    }
    return length;
}

u32 XPredict_Get_tree_121_BaseAddress(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_121_BASE);
}

u32 XPredict_Get_tree_121_HighAddress(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_121_HIGH);
}

u32 XPredict_Get_tree_121_TotalBytes(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (XPREDICT_TREE_ADDR_TREE_121_HIGH - XPREDICT_TREE_ADDR_TREE_121_BASE + 1);
}

u32 XPredict_Get_tree_121_BitWidth(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XPREDICT_TREE_WIDTH_TREE_121;
}

u32 XPredict_Get_tree_121_Depth(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XPREDICT_TREE_DEPTH_TREE_121;
}

u32 XPredict_Write_tree_121_Words(XPredict *InstancePtr, int offset, word_type *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length)*4 > (XPREDICT_TREE_ADDR_TREE_121_HIGH - XPREDICT_TREE_ADDR_TREE_121_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(int *)(InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_121_BASE + (offset + i)*4) = *(data + i);
    }
    return length;
}

u32 XPredict_Read_tree_121_Words(XPredict *InstancePtr, int offset, word_type *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length)*4 > (XPREDICT_TREE_ADDR_TREE_121_HIGH - XPREDICT_TREE_ADDR_TREE_121_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(data + i) = *(int *)(InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_121_BASE + (offset + i)*4);
    }
    return length;
}

u32 XPredict_Write_tree_121_Bytes(XPredict *InstancePtr, int offset, char *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length) > (XPREDICT_TREE_ADDR_TREE_121_HIGH - XPREDICT_TREE_ADDR_TREE_121_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(char *)(InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_121_BASE + offset + i) = *(data + i);
    }
    return length;
}

u32 XPredict_Read_tree_121_Bytes(XPredict *InstancePtr, int offset, char *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length) > (XPREDICT_TREE_ADDR_TREE_121_HIGH - XPREDICT_TREE_ADDR_TREE_121_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(data + i) = *(char *)(InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_121_BASE + offset + i);
    }
    return length;
}

u32 XPredict_Get_tree_122_BaseAddress(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_122_BASE);
}

u32 XPredict_Get_tree_122_HighAddress(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_122_HIGH);
}

u32 XPredict_Get_tree_122_TotalBytes(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (XPREDICT_TREE_ADDR_TREE_122_HIGH - XPREDICT_TREE_ADDR_TREE_122_BASE + 1);
}

u32 XPredict_Get_tree_122_BitWidth(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XPREDICT_TREE_WIDTH_TREE_122;
}

u32 XPredict_Get_tree_122_Depth(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XPREDICT_TREE_DEPTH_TREE_122;
}

u32 XPredict_Write_tree_122_Words(XPredict *InstancePtr, int offset, word_type *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length)*4 > (XPREDICT_TREE_ADDR_TREE_122_HIGH - XPREDICT_TREE_ADDR_TREE_122_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(int *)(InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_122_BASE + (offset + i)*4) = *(data + i);
    }
    return length;
}

u32 XPredict_Read_tree_122_Words(XPredict *InstancePtr, int offset, word_type *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length)*4 > (XPREDICT_TREE_ADDR_TREE_122_HIGH - XPREDICT_TREE_ADDR_TREE_122_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(data + i) = *(int *)(InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_122_BASE + (offset + i)*4);
    }
    return length;
}

u32 XPredict_Write_tree_122_Bytes(XPredict *InstancePtr, int offset, char *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length) > (XPREDICT_TREE_ADDR_TREE_122_HIGH - XPREDICT_TREE_ADDR_TREE_122_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(char *)(InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_122_BASE + offset + i) = *(data + i);
    }
    return length;
}

u32 XPredict_Read_tree_122_Bytes(XPredict *InstancePtr, int offset, char *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length) > (XPREDICT_TREE_ADDR_TREE_122_HIGH - XPREDICT_TREE_ADDR_TREE_122_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(data + i) = *(char *)(InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_122_BASE + offset + i);
    }
    return length;
}

u32 XPredict_Get_tree_123_BaseAddress(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_123_BASE);
}

u32 XPredict_Get_tree_123_HighAddress(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_123_HIGH);
}

u32 XPredict_Get_tree_123_TotalBytes(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (XPREDICT_TREE_ADDR_TREE_123_HIGH - XPREDICT_TREE_ADDR_TREE_123_BASE + 1);
}

u32 XPredict_Get_tree_123_BitWidth(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XPREDICT_TREE_WIDTH_TREE_123;
}

u32 XPredict_Get_tree_123_Depth(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XPREDICT_TREE_DEPTH_TREE_123;
}

u32 XPredict_Write_tree_123_Words(XPredict *InstancePtr, int offset, word_type *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length)*4 > (XPREDICT_TREE_ADDR_TREE_123_HIGH - XPREDICT_TREE_ADDR_TREE_123_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(int *)(InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_123_BASE + (offset + i)*4) = *(data + i);
    }
    return length;
}

u32 XPredict_Read_tree_123_Words(XPredict *InstancePtr, int offset, word_type *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length)*4 > (XPREDICT_TREE_ADDR_TREE_123_HIGH - XPREDICT_TREE_ADDR_TREE_123_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(data + i) = *(int *)(InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_123_BASE + (offset + i)*4);
    }
    return length;
}

u32 XPredict_Write_tree_123_Bytes(XPredict *InstancePtr, int offset, char *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length) > (XPREDICT_TREE_ADDR_TREE_123_HIGH - XPREDICT_TREE_ADDR_TREE_123_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(char *)(InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_123_BASE + offset + i) = *(data + i);
    }
    return length;
}

u32 XPredict_Read_tree_123_Bytes(XPredict *InstancePtr, int offset, char *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length) > (XPREDICT_TREE_ADDR_TREE_123_HIGH - XPREDICT_TREE_ADDR_TREE_123_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(data + i) = *(char *)(InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_123_BASE + offset + i);
    }
    return length;
}

u32 XPredict_Get_tree_124_BaseAddress(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_124_BASE);
}

u32 XPredict_Get_tree_124_HighAddress(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_124_HIGH);
}

u32 XPredict_Get_tree_124_TotalBytes(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (XPREDICT_TREE_ADDR_TREE_124_HIGH - XPREDICT_TREE_ADDR_TREE_124_BASE + 1);
}

u32 XPredict_Get_tree_124_BitWidth(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XPREDICT_TREE_WIDTH_TREE_124;
}

u32 XPredict_Get_tree_124_Depth(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XPREDICT_TREE_DEPTH_TREE_124;
}

u32 XPredict_Write_tree_124_Words(XPredict *InstancePtr, int offset, word_type *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length)*4 > (XPREDICT_TREE_ADDR_TREE_124_HIGH - XPREDICT_TREE_ADDR_TREE_124_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(int *)(InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_124_BASE + (offset + i)*4) = *(data + i);
    }
    return length;
}

u32 XPredict_Read_tree_124_Words(XPredict *InstancePtr, int offset, word_type *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length)*4 > (XPREDICT_TREE_ADDR_TREE_124_HIGH - XPREDICT_TREE_ADDR_TREE_124_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(data + i) = *(int *)(InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_124_BASE + (offset + i)*4);
    }
    return length;
}

u32 XPredict_Write_tree_124_Bytes(XPredict *InstancePtr, int offset, char *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length) > (XPREDICT_TREE_ADDR_TREE_124_HIGH - XPREDICT_TREE_ADDR_TREE_124_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(char *)(InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_124_BASE + offset + i) = *(data + i);
    }
    return length;
}

u32 XPredict_Read_tree_124_Bytes(XPredict *InstancePtr, int offset, char *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length) > (XPREDICT_TREE_ADDR_TREE_124_HIGH - XPREDICT_TREE_ADDR_TREE_124_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(data + i) = *(char *)(InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_124_BASE + offset + i);
    }
    return length;
}

u32 XPredict_Get_tree_125_BaseAddress(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_125_BASE);
}

u32 XPredict_Get_tree_125_HighAddress(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_125_HIGH);
}

u32 XPredict_Get_tree_125_TotalBytes(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (XPREDICT_TREE_ADDR_TREE_125_HIGH - XPREDICT_TREE_ADDR_TREE_125_BASE + 1);
}

u32 XPredict_Get_tree_125_BitWidth(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XPREDICT_TREE_WIDTH_TREE_125;
}

u32 XPredict_Get_tree_125_Depth(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XPREDICT_TREE_DEPTH_TREE_125;
}

u32 XPredict_Write_tree_125_Words(XPredict *InstancePtr, int offset, word_type *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length)*4 > (XPREDICT_TREE_ADDR_TREE_125_HIGH - XPREDICT_TREE_ADDR_TREE_125_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(int *)(InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_125_BASE + (offset + i)*4) = *(data + i);
    }
    return length;
}

u32 XPredict_Read_tree_125_Words(XPredict *InstancePtr, int offset, word_type *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length)*4 > (XPREDICT_TREE_ADDR_TREE_125_HIGH - XPREDICT_TREE_ADDR_TREE_125_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(data + i) = *(int *)(InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_125_BASE + (offset + i)*4);
    }
    return length;
}

u32 XPredict_Write_tree_125_Bytes(XPredict *InstancePtr, int offset, char *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length) > (XPREDICT_TREE_ADDR_TREE_125_HIGH - XPREDICT_TREE_ADDR_TREE_125_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(char *)(InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_125_BASE + offset + i) = *(data + i);
    }
    return length;
}

u32 XPredict_Read_tree_125_Bytes(XPredict *InstancePtr, int offset, char *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length) > (XPREDICT_TREE_ADDR_TREE_125_HIGH - XPREDICT_TREE_ADDR_TREE_125_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(data + i) = *(char *)(InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_125_BASE + offset + i);
    }
    return length;
}

u32 XPredict_Get_tree_126_BaseAddress(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_126_BASE);
}

u32 XPredict_Get_tree_126_HighAddress(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_126_HIGH);
}

u32 XPredict_Get_tree_126_TotalBytes(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (XPREDICT_TREE_ADDR_TREE_126_HIGH - XPREDICT_TREE_ADDR_TREE_126_BASE + 1);
}

u32 XPredict_Get_tree_126_BitWidth(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XPREDICT_TREE_WIDTH_TREE_126;
}

u32 XPredict_Get_tree_126_Depth(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XPREDICT_TREE_DEPTH_TREE_126;
}

u32 XPredict_Write_tree_126_Words(XPredict *InstancePtr, int offset, word_type *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length)*4 > (XPREDICT_TREE_ADDR_TREE_126_HIGH - XPREDICT_TREE_ADDR_TREE_126_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(int *)(InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_126_BASE + (offset + i)*4) = *(data + i);
    }
    return length;
}

u32 XPredict_Read_tree_126_Words(XPredict *InstancePtr, int offset, word_type *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length)*4 > (XPREDICT_TREE_ADDR_TREE_126_HIGH - XPREDICT_TREE_ADDR_TREE_126_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(data + i) = *(int *)(InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_126_BASE + (offset + i)*4);
    }
    return length;
}

u32 XPredict_Write_tree_126_Bytes(XPredict *InstancePtr, int offset, char *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length) > (XPREDICT_TREE_ADDR_TREE_126_HIGH - XPREDICT_TREE_ADDR_TREE_126_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(char *)(InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_126_BASE + offset + i) = *(data + i);
    }
    return length;
}

u32 XPredict_Read_tree_126_Bytes(XPredict *InstancePtr, int offset, char *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length) > (XPREDICT_TREE_ADDR_TREE_126_HIGH - XPREDICT_TREE_ADDR_TREE_126_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(data + i) = *(char *)(InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_126_BASE + offset + i);
    }
    return length;
}

u32 XPredict_Get_tree_127_BaseAddress(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_127_BASE);
}

u32 XPredict_Get_tree_127_HighAddress(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_127_HIGH);
}

u32 XPredict_Get_tree_127_TotalBytes(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (XPREDICT_TREE_ADDR_TREE_127_HIGH - XPREDICT_TREE_ADDR_TREE_127_BASE + 1);
}

u32 XPredict_Get_tree_127_BitWidth(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XPREDICT_TREE_WIDTH_TREE_127;
}

u32 XPredict_Get_tree_127_Depth(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XPREDICT_TREE_DEPTH_TREE_127;
}

u32 XPredict_Write_tree_127_Words(XPredict *InstancePtr, int offset, word_type *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length)*4 > (XPREDICT_TREE_ADDR_TREE_127_HIGH - XPREDICT_TREE_ADDR_TREE_127_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(int *)(InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_127_BASE + (offset + i)*4) = *(data + i);
    }
    return length;
}

u32 XPredict_Read_tree_127_Words(XPredict *InstancePtr, int offset, word_type *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length)*4 > (XPREDICT_TREE_ADDR_TREE_127_HIGH - XPREDICT_TREE_ADDR_TREE_127_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(data + i) = *(int *)(InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_127_BASE + (offset + i)*4);
    }
    return length;
}

u32 XPredict_Write_tree_127_Bytes(XPredict *InstancePtr, int offset, char *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length) > (XPREDICT_TREE_ADDR_TREE_127_HIGH - XPREDICT_TREE_ADDR_TREE_127_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(char *)(InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_127_BASE + offset + i) = *(data + i);
    }
    return length;
}

u32 XPredict_Read_tree_127_Bytes(XPredict *InstancePtr, int offset, char *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length) > (XPREDICT_TREE_ADDR_TREE_127_HIGH - XPREDICT_TREE_ADDR_TREE_127_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(data + i) = *(char *)(InstancePtr->Tree_BaseAddress + XPREDICT_TREE_ADDR_TREE_127_BASE + offset + i);
    }
    return length;
}

void XPredict_InterruptGlobalEnable(XPredict *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XPredict_WriteReg(InstancePtr->Control_BaseAddress, XPREDICT_CONTROL_ADDR_GIE, 1);
}

void XPredict_InterruptGlobalDisable(XPredict *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XPredict_WriteReg(InstancePtr->Control_BaseAddress, XPREDICT_CONTROL_ADDR_GIE, 0);
}

void XPredict_InterruptEnable(XPredict *InstancePtr, u32 Mask) {
    u32 Register;

    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Register =  XPredict_ReadReg(InstancePtr->Control_BaseAddress, XPREDICT_CONTROL_ADDR_IER);
    XPredict_WriteReg(InstancePtr->Control_BaseAddress, XPREDICT_CONTROL_ADDR_IER, Register | Mask);
}

void XPredict_InterruptDisable(XPredict *InstancePtr, u32 Mask) {
    u32 Register;

    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Register =  XPredict_ReadReg(InstancePtr->Control_BaseAddress, XPREDICT_CONTROL_ADDR_IER);
    XPredict_WriteReg(InstancePtr->Control_BaseAddress, XPREDICT_CONTROL_ADDR_IER, Register & (~Mask));
}

void XPredict_InterruptClear(XPredict *InstancePtr, u32 Mask) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XPredict_WriteReg(InstancePtr->Control_BaseAddress, XPREDICT_CONTROL_ADDR_ISR, Mask);
}

u32 XPredict_InterruptGetEnabled(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XPredict_ReadReg(InstancePtr->Control_BaseAddress, XPREDICT_CONTROL_ADDR_IER);
}

u32 XPredict_InterruptGetStatus(XPredict *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XPredict_ReadReg(InstancePtr->Control_BaseAddress, XPREDICT_CONTROL_ADDR_ISR);
}

