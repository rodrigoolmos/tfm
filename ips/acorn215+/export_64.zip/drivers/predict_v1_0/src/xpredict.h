// ==============================================================
// Vitis HLS - High-Level Synthesis from C, C++ and OpenCL v2023.1.1 (64-bit)
// Tool Version Limit: 2023.06
// Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
// Copyright 2022-2023 Advanced Micro Devices, Inc. All Rights Reserved.
// 
// ==============================================================
#ifndef XPREDICT_H
#define XPREDICT_H

#ifdef __cplusplus
extern "C" {
#endif

/***************************** Include Files *********************************/
#ifndef __linux__
#include "xil_types.h"
#include "xil_assert.h"
#include "xstatus.h"
#include "xil_io.h"
#else
#include <stdint.h>
#include <assert.h>
#include <dirent.h>
#include <fcntl.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/mman.h>
#include <unistd.h>
#include <stddef.h>
#endif
#include "xpredict_hw.h"

/**************************** Type Definitions ******************************/
#ifdef __linux__
typedef uint8_t u8;
typedef uint16_t u16;
typedef uint32_t u32;
typedef uint64_t u64;
#else
typedef struct {
    u16 DeviceId;
    u64 Control_BaseAddress;
    u64 Tree_BaseAddress;
} XPredict_Config;
#endif

typedef struct {
    u64 Control_BaseAddress;
    u64 Tree_BaseAddress;
    u32 IsReady;
} XPredict;

typedef u32 word_type;

/***************** Macros (Inline Functions) Definitions *********************/
#ifndef __linux__
#define XPredict_WriteReg(BaseAddress, RegOffset, Data) \
    Xil_Out32((BaseAddress) + (RegOffset), (u32)(Data))
#define XPredict_ReadReg(BaseAddress, RegOffset) \
    Xil_In32((BaseAddress) + (RegOffset))
#else
#define XPredict_WriteReg(BaseAddress, RegOffset, Data) \
    *(volatile u32*)((BaseAddress) + (RegOffset)) = (u32)(Data)
#define XPredict_ReadReg(BaseAddress, RegOffset) \
    *(volatile u32*)((BaseAddress) + (RegOffset))

#define Xil_AssertVoid(expr)    assert(expr)
#define Xil_AssertNonvoid(expr) assert(expr)

#define XST_SUCCESS             0
#define XST_DEVICE_NOT_FOUND    2
#define XST_OPEN_DEVICE_FAILED  3
#define XIL_COMPONENT_IS_READY  1
#endif

/************************** Function Prototypes *****************************/
#ifndef __linux__
int XPredict_Initialize(XPredict *InstancePtr, u16 DeviceId);
XPredict_Config* XPredict_LookupConfig(u16 DeviceId);
int XPredict_CfgInitialize(XPredict *InstancePtr, XPredict_Config *ConfigPtr);
#else
int XPredict_Initialize(XPredict *InstancePtr, const char* InstanceName);
int XPredict_Release(XPredict *InstancePtr);
#endif

void XPredict_Start(XPredict *InstancePtr);
u32 XPredict_IsDone(XPredict *InstancePtr);
u32 XPredict_IsIdle(XPredict *InstancePtr);
u32 XPredict_IsReady(XPredict *InstancePtr);
void XPredict_EnableAutoRestart(XPredict *InstancePtr);
void XPredict_DisableAutoRestart(XPredict *InstancePtr);

void XPredict_Set_features_burst_length(XPredict *InstancePtr, u32 Data);
u32 XPredict_Get_features_burst_length(XPredict *InstancePtr);
void XPredict_Set_ping_pong(XPredict *InstancePtr, u32 Data);
u32 XPredict_Get_ping_pong(XPredict *InstancePtr);
u32 XPredict_Get_tree_0_BaseAddress(XPredict *InstancePtr);
u32 XPredict_Get_tree_0_HighAddress(XPredict *InstancePtr);
u32 XPredict_Get_tree_0_TotalBytes(XPredict *InstancePtr);
u32 XPredict_Get_tree_0_BitWidth(XPredict *InstancePtr);
u32 XPredict_Get_tree_0_Depth(XPredict *InstancePtr);
u32 XPredict_Write_tree_0_Words(XPredict *InstancePtr, int offset, word_type *data, int length);
u32 XPredict_Read_tree_0_Words(XPredict *InstancePtr, int offset, word_type *data, int length);
u32 XPredict_Write_tree_0_Bytes(XPredict *InstancePtr, int offset, char *data, int length);
u32 XPredict_Read_tree_0_Bytes(XPredict *InstancePtr, int offset, char *data, int length);
u32 XPredict_Get_tree_1_BaseAddress(XPredict *InstancePtr);
u32 XPredict_Get_tree_1_HighAddress(XPredict *InstancePtr);
u32 XPredict_Get_tree_1_TotalBytes(XPredict *InstancePtr);
u32 XPredict_Get_tree_1_BitWidth(XPredict *InstancePtr);
u32 XPredict_Get_tree_1_Depth(XPredict *InstancePtr);
u32 XPredict_Write_tree_1_Words(XPredict *InstancePtr, int offset, word_type *data, int length);
u32 XPredict_Read_tree_1_Words(XPredict *InstancePtr, int offset, word_type *data, int length);
u32 XPredict_Write_tree_1_Bytes(XPredict *InstancePtr, int offset, char *data, int length);
u32 XPredict_Read_tree_1_Bytes(XPredict *InstancePtr, int offset, char *data, int length);
u32 XPredict_Get_tree_2_BaseAddress(XPredict *InstancePtr);
u32 XPredict_Get_tree_2_HighAddress(XPredict *InstancePtr);
u32 XPredict_Get_tree_2_TotalBytes(XPredict *InstancePtr);
u32 XPredict_Get_tree_2_BitWidth(XPredict *InstancePtr);
u32 XPredict_Get_tree_2_Depth(XPredict *InstancePtr);
u32 XPredict_Write_tree_2_Words(XPredict *InstancePtr, int offset, word_type *data, int length);
u32 XPredict_Read_tree_2_Words(XPredict *InstancePtr, int offset, word_type *data, int length);
u32 XPredict_Write_tree_2_Bytes(XPredict *InstancePtr, int offset, char *data, int length);
u32 XPredict_Read_tree_2_Bytes(XPredict *InstancePtr, int offset, char *data, int length);
u32 XPredict_Get_tree_3_BaseAddress(XPredict *InstancePtr);
u32 XPredict_Get_tree_3_HighAddress(XPredict *InstancePtr);
u32 XPredict_Get_tree_3_TotalBytes(XPredict *InstancePtr);
u32 XPredict_Get_tree_3_BitWidth(XPredict *InstancePtr);
u32 XPredict_Get_tree_3_Depth(XPredict *InstancePtr);
u32 XPredict_Write_tree_3_Words(XPredict *InstancePtr, int offset, word_type *data, int length);
u32 XPredict_Read_tree_3_Words(XPredict *InstancePtr, int offset, word_type *data, int length);
u32 XPredict_Write_tree_3_Bytes(XPredict *InstancePtr, int offset, char *data, int length);
u32 XPredict_Read_tree_3_Bytes(XPredict *InstancePtr, int offset, char *data, int length);
u32 XPredict_Get_tree_4_BaseAddress(XPredict *InstancePtr);
u32 XPredict_Get_tree_4_HighAddress(XPredict *InstancePtr);
u32 XPredict_Get_tree_4_TotalBytes(XPredict *InstancePtr);
u32 XPredict_Get_tree_4_BitWidth(XPredict *InstancePtr);
u32 XPredict_Get_tree_4_Depth(XPredict *InstancePtr);
u32 XPredict_Write_tree_4_Words(XPredict *InstancePtr, int offset, word_type *data, int length);
u32 XPredict_Read_tree_4_Words(XPredict *InstancePtr, int offset, word_type *data, int length);
u32 XPredict_Write_tree_4_Bytes(XPredict *InstancePtr, int offset, char *data, int length);
u32 XPredict_Read_tree_4_Bytes(XPredict *InstancePtr, int offset, char *data, int length);
u32 XPredict_Get_tree_5_BaseAddress(XPredict *InstancePtr);
u32 XPredict_Get_tree_5_HighAddress(XPredict *InstancePtr);
u32 XPredict_Get_tree_5_TotalBytes(XPredict *InstancePtr);
u32 XPredict_Get_tree_5_BitWidth(XPredict *InstancePtr);
u32 XPredict_Get_tree_5_Depth(XPredict *InstancePtr);
u32 XPredict_Write_tree_5_Words(XPredict *InstancePtr, int offset, word_type *data, int length);
u32 XPredict_Read_tree_5_Words(XPredict *InstancePtr, int offset, word_type *data, int length);
u32 XPredict_Write_tree_5_Bytes(XPredict *InstancePtr, int offset, char *data, int length);
u32 XPredict_Read_tree_5_Bytes(XPredict *InstancePtr, int offset, char *data, int length);
u32 XPredict_Get_tree_6_BaseAddress(XPredict *InstancePtr);
u32 XPredict_Get_tree_6_HighAddress(XPredict *InstancePtr);
u32 XPredict_Get_tree_6_TotalBytes(XPredict *InstancePtr);
u32 XPredict_Get_tree_6_BitWidth(XPredict *InstancePtr);
u32 XPredict_Get_tree_6_Depth(XPredict *InstancePtr);
u32 XPredict_Write_tree_6_Words(XPredict *InstancePtr, int offset, word_type *data, int length);
u32 XPredict_Read_tree_6_Words(XPredict *InstancePtr, int offset, word_type *data, int length);
u32 XPredict_Write_tree_6_Bytes(XPredict *InstancePtr, int offset, char *data, int length);
u32 XPredict_Read_tree_6_Bytes(XPredict *InstancePtr, int offset, char *data, int length);
u32 XPredict_Get_tree_7_BaseAddress(XPredict *InstancePtr);
u32 XPredict_Get_tree_7_HighAddress(XPredict *InstancePtr);
u32 XPredict_Get_tree_7_TotalBytes(XPredict *InstancePtr);
u32 XPredict_Get_tree_7_BitWidth(XPredict *InstancePtr);
u32 XPredict_Get_tree_7_Depth(XPredict *InstancePtr);
u32 XPredict_Write_tree_7_Words(XPredict *InstancePtr, int offset, word_type *data, int length);
u32 XPredict_Read_tree_7_Words(XPredict *InstancePtr, int offset, word_type *data, int length);
u32 XPredict_Write_tree_7_Bytes(XPredict *InstancePtr, int offset, char *data, int length);
u32 XPredict_Read_tree_7_Bytes(XPredict *InstancePtr, int offset, char *data, int length);
u32 XPredict_Get_tree_8_BaseAddress(XPredict *InstancePtr);
u32 XPredict_Get_tree_8_HighAddress(XPredict *InstancePtr);
u32 XPredict_Get_tree_8_TotalBytes(XPredict *InstancePtr);
u32 XPredict_Get_tree_8_BitWidth(XPredict *InstancePtr);
u32 XPredict_Get_tree_8_Depth(XPredict *InstancePtr);
u32 XPredict_Write_tree_8_Words(XPredict *InstancePtr, int offset, word_type *data, int length);
u32 XPredict_Read_tree_8_Words(XPredict *InstancePtr, int offset, word_type *data, int length);
u32 XPredict_Write_tree_8_Bytes(XPredict *InstancePtr, int offset, char *data, int length);
u32 XPredict_Read_tree_8_Bytes(XPredict *InstancePtr, int offset, char *data, int length);
u32 XPredict_Get_tree_9_BaseAddress(XPredict *InstancePtr);
u32 XPredict_Get_tree_9_HighAddress(XPredict *InstancePtr);
u32 XPredict_Get_tree_9_TotalBytes(XPredict *InstancePtr);
u32 XPredict_Get_tree_9_BitWidth(XPredict *InstancePtr);
u32 XPredict_Get_tree_9_Depth(XPredict *InstancePtr);
u32 XPredict_Write_tree_9_Words(XPredict *InstancePtr, int offset, word_type *data, int length);
u32 XPredict_Read_tree_9_Words(XPredict *InstancePtr, int offset, word_type *data, int length);
u32 XPredict_Write_tree_9_Bytes(XPredict *InstancePtr, int offset, char *data, int length);
u32 XPredict_Read_tree_9_Bytes(XPredict *InstancePtr, int offset, char *data, int length);
u32 XPredict_Get_tree_10_BaseAddress(XPredict *InstancePtr);
u32 XPredict_Get_tree_10_HighAddress(XPredict *InstancePtr);
u32 XPredict_Get_tree_10_TotalBytes(XPredict *InstancePtr);
u32 XPredict_Get_tree_10_BitWidth(XPredict *InstancePtr);
u32 XPredict_Get_tree_10_Depth(XPredict *InstancePtr);
u32 XPredict_Write_tree_10_Words(XPredict *InstancePtr, int offset, word_type *data, int length);
u32 XPredict_Read_tree_10_Words(XPredict *InstancePtr, int offset, word_type *data, int length);
u32 XPredict_Write_tree_10_Bytes(XPredict *InstancePtr, int offset, char *data, int length);
u32 XPredict_Read_tree_10_Bytes(XPredict *InstancePtr, int offset, char *data, int length);
u32 XPredict_Get_tree_11_BaseAddress(XPredict *InstancePtr);
u32 XPredict_Get_tree_11_HighAddress(XPredict *InstancePtr);
u32 XPredict_Get_tree_11_TotalBytes(XPredict *InstancePtr);
u32 XPredict_Get_tree_11_BitWidth(XPredict *InstancePtr);
u32 XPredict_Get_tree_11_Depth(XPredict *InstancePtr);
u32 XPredict_Write_tree_11_Words(XPredict *InstancePtr, int offset, word_type *data, int length);
u32 XPredict_Read_tree_11_Words(XPredict *InstancePtr, int offset, word_type *data, int length);
u32 XPredict_Write_tree_11_Bytes(XPredict *InstancePtr, int offset, char *data, int length);
u32 XPredict_Read_tree_11_Bytes(XPredict *InstancePtr, int offset, char *data, int length);
u32 XPredict_Get_tree_12_BaseAddress(XPredict *InstancePtr);
u32 XPredict_Get_tree_12_HighAddress(XPredict *InstancePtr);
u32 XPredict_Get_tree_12_TotalBytes(XPredict *InstancePtr);
u32 XPredict_Get_tree_12_BitWidth(XPredict *InstancePtr);
u32 XPredict_Get_tree_12_Depth(XPredict *InstancePtr);
u32 XPredict_Write_tree_12_Words(XPredict *InstancePtr, int offset, word_type *data, int length);
u32 XPredict_Read_tree_12_Words(XPredict *InstancePtr, int offset, word_type *data, int length);
u32 XPredict_Write_tree_12_Bytes(XPredict *InstancePtr, int offset, char *data, int length);
u32 XPredict_Read_tree_12_Bytes(XPredict *InstancePtr, int offset, char *data, int length);
u32 XPredict_Get_tree_13_BaseAddress(XPredict *InstancePtr);
u32 XPredict_Get_tree_13_HighAddress(XPredict *InstancePtr);
u32 XPredict_Get_tree_13_TotalBytes(XPredict *InstancePtr);
u32 XPredict_Get_tree_13_BitWidth(XPredict *InstancePtr);
u32 XPredict_Get_tree_13_Depth(XPredict *InstancePtr);
u32 XPredict_Write_tree_13_Words(XPredict *InstancePtr, int offset, word_type *data, int length);
u32 XPredict_Read_tree_13_Words(XPredict *InstancePtr, int offset, word_type *data, int length);
u32 XPredict_Write_tree_13_Bytes(XPredict *InstancePtr, int offset, char *data, int length);
u32 XPredict_Read_tree_13_Bytes(XPredict *InstancePtr, int offset, char *data, int length);
u32 XPredict_Get_tree_14_BaseAddress(XPredict *InstancePtr);
u32 XPredict_Get_tree_14_HighAddress(XPredict *InstancePtr);
u32 XPredict_Get_tree_14_TotalBytes(XPredict *InstancePtr);
u32 XPredict_Get_tree_14_BitWidth(XPredict *InstancePtr);
u32 XPredict_Get_tree_14_Depth(XPredict *InstancePtr);
u32 XPredict_Write_tree_14_Words(XPredict *InstancePtr, int offset, word_type *data, int length);
u32 XPredict_Read_tree_14_Words(XPredict *InstancePtr, int offset, word_type *data, int length);
u32 XPredict_Write_tree_14_Bytes(XPredict *InstancePtr, int offset, char *data, int length);
u32 XPredict_Read_tree_14_Bytes(XPredict *InstancePtr, int offset, char *data, int length);
u32 XPredict_Get_tree_15_BaseAddress(XPredict *InstancePtr);
u32 XPredict_Get_tree_15_HighAddress(XPredict *InstancePtr);
u32 XPredict_Get_tree_15_TotalBytes(XPredict *InstancePtr);
u32 XPredict_Get_tree_15_BitWidth(XPredict *InstancePtr);
u32 XPredict_Get_tree_15_Depth(XPredict *InstancePtr);
u32 XPredict_Write_tree_15_Words(XPredict *InstancePtr, int offset, word_type *data, int length);
u32 XPredict_Read_tree_15_Words(XPredict *InstancePtr, int offset, word_type *data, int length);
u32 XPredict_Write_tree_15_Bytes(XPredict *InstancePtr, int offset, char *data, int length);
u32 XPredict_Read_tree_15_Bytes(XPredict *InstancePtr, int offset, char *data, int length);
u32 XPredict_Get_tree_16_BaseAddress(XPredict *InstancePtr);
u32 XPredict_Get_tree_16_HighAddress(XPredict *InstancePtr);
u32 XPredict_Get_tree_16_TotalBytes(XPredict *InstancePtr);
u32 XPredict_Get_tree_16_BitWidth(XPredict *InstancePtr);
u32 XPredict_Get_tree_16_Depth(XPredict *InstancePtr);
u32 XPredict_Write_tree_16_Words(XPredict *InstancePtr, int offset, word_type *data, int length);
u32 XPredict_Read_tree_16_Words(XPredict *InstancePtr, int offset, word_type *data, int length);
u32 XPredict_Write_tree_16_Bytes(XPredict *InstancePtr, int offset, char *data, int length);
u32 XPredict_Read_tree_16_Bytes(XPredict *InstancePtr, int offset, char *data, int length);
u32 XPredict_Get_tree_17_BaseAddress(XPredict *InstancePtr);
u32 XPredict_Get_tree_17_HighAddress(XPredict *InstancePtr);
u32 XPredict_Get_tree_17_TotalBytes(XPredict *InstancePtr);
u32 XPredict_Get_tree_17_BitWidth(XPredict *InstancePtr);
u32 XPredict_Get_tree_17_Depth(XPredict *InstancePtr);
u32 XPredict_Write_tree_17_Words(XPredict *InstancePtr, int offset, word_type *data, int length);
u32 XPredict_Read_tree_17_Words(XPredict *InstancePtr, int offset, word_type *data, int length);
u32 XPredict_Write_tree_17_Bytes(XPredict *InstancePtr, int offset, char *data, int length);
u32 XPredict_Read_tree_17_Bytes(XPredict *InstancePtr, int offset, char *data, int length);
u32 XPredict_Get_tree_18_BaseAddress(XPredict *InstancePtr);
u32 XPredict_Get_tree_18_HighAddress(XPredict *InstancePtr);
u32 XPredict_Get_tree_18_TotalBytes(XPredict *InstancePtr);
u32 XPredict_Get_tree_18_BitWidth(XPredict *InstancePtr);
u32 XPredict_Get_tree_18_Depth(XPredict *InstancePtr);
u32 XPredict_Write_tree_18_Words(XPredict *InstancePtr, int offset, word_type *data, int length);
u32 XPredict_Read_tree_18_Words(XPredict *InstancePtr, int offset, word_type *data, int length);
u32 XPredict_Write_tree_18_Bytes(XPredict *InstancePtr, int offset, char *data, int length);
u32 XPredict_Read_tree_18_Bytes(XPredict *InstancePtr, int offset, char *data, int length);
u32 XPredict_Get_tree_19_BaseAddress(XPredict *InstancePtr);
u32 XPredict_Get_tree_19_HighAddress(XPredict *InstancePtr);
u32 XPredict_Get_tree_19_TotalBytes(XPredict *InstancePtr);
u32 XPredict_Get_tree_19_BitWidth(XPredict *InstancePtr);
u32 XPredict_Get_tree_19_Depth(XPredict *InstancePtr);
u32 XPredict_Write_tree_19_Words(XPredict *InstancePtr, int offset, word_type *data, int length);
u32 XPredict_Read_tree_19_Words(XPredict *InstancePtr, int offset, word_type *data, int length);
u32 XPredict_Write_tree_19_Bytes(XPredict *InstancePtr, int offset, char *data, int length);
u32 XPredict_Read_tree_19_Bytes(XPredict *InstancePtr, int offset, char *data, int length);
u32 XPredict_Get_tree_20_BaseAddress(XPredict *InstancePtr);
u32 XPredict_Get_tree_20_HighAddress(XPredict *InstancePtr);
u32 XPredict_Get_tree_20_TotalBytes(XPredict *InstancePtr);
u32 XPredict_Get_tree_20_BitWidth(XPredict *InstancePtr);
u32 XPredict_Get_tree_20_Depth(XPredict *InstancePtr);
u32 XPredict_Write_tree_20_Words(XPredict *InstancePtr, int offset, word_type *data, int length);
u32 XPredict_Read_tree_20_Words(XPredict *InstancePtr, int offset, word_type *data, int length);
u32 XPredict_Write_tree_20_Bytes(XPredict *InstancePtr, int offset, char *data, int length);
u32 XPredict_Read_tree_20_Bytes(XPredict *InstancePtr, int offset, char *data, int length);
u32 XPredict_Get_tree_21_BaseAddress(XPredict *InstancePtr);
u32 XPredict_Get_tree_21_HighAddress(XPredict *InstancePtr);
u32 XPredict_Get_tree_21_TotalBytes(XPredict *InstancePtr);
u32 XPredict_Get_tree_21_BitWidth(XPredict *InstancePtr);
u32 XPredict_Get_tree_21_Depth(XPredict *InstancePtr);
u32 XPredict_Write_tree_21_Words(XPredict *InstancePtr, int offset, word_type *data, int length);
u32 XPredict_Read_tree_21_Words(XPredict *InstancePtr, int offset, word_type *data, int length);
u32 XPredict_Write_tree_21_Bytes(XPredict *InstancePtr, int offset, char *data, int length);
u32 XPredict_Read_tree_21_Bytes(XPredict *InstancePtr, int offset, char *data, int length);
u32 XPredict_Get_tree_22_BaseAddress(XPredict *InstancePtr);
u32 XPredict_Get_tree_22_HighAddress(XPredict *InstancePtr);
u32 XPredict_Get_tree_22_TotalBytes(XPredict *InstancePtr);
u32 XPredict_Get_tree_22_BitWidth(XPredict *InstancePtr);
u32 XPredict_Get_tree_22_Depth(XPredict *InstancePtr);
u32 XPredict_Write_tree_22_Words(XPredict *InstancePtr, int offset, word_type *data, int length);
u32 XPredict_Read_tree_22_Words(XPredict *InstancePtr, int offset, word_type *data, int length);
u32 XPredict_Write_tree_22_Bytes(XPredict *InstancePtr, int offset, char *data, int length);
u32 XPredict_Read_tree_22_Bytes(XPredict *InstancePtr, int offset, char *data, int length);
u32 XPredict_Get_tree_23_BaseAddress(XPredict *InstancePtr);
u32 XPredict_Get_tree_23_HighAddress(XPredict *InstancePtr);
u32 XPredict_Get_tree_23_TotalBytes(XPredict *InstancePtr);
u32 XPredict_Get_tree_23_BitWidth(XPredict *InstancePtr);
u32 XPredict_Get_tree_23_Depth(XPredict *InstancePtr);
u32 XPredict_Write_tree_23_Words(XPredict *InstancePtr, int offset, word_type *data, int length);
u32 XPredict_Read_tree_23_Words(XPredict *InstancePtr, int offset, word_type *data, int length);
u32 XPredict_Write_tree_23_Bytes(XPredict *InstancePtr, int offset, char *data, int length);
u32 XPredict_Read_tree_23_Bytes(XPredict *InstancePtr, int offset, char *data, int length);
u32 XPredict_Get_tree_24_BaseAddress(XPredict *InstancePtr);
u32 XPredict_Get_tree_24_HighAddress(XPredict *InstancePtr);
u32 XPredict_Get_tree_24_TotalBytes(XPredict *InstancePtr);
u32 XPredict_Get_tree_24_BitWidth(XPredict *InstancePtr);
u32 XPredict_Get_tree_24_Depth(XPredict *InstancePtr);
u32 XPredict_Write_tree_24_Words(XPredict *InstancePtr, int offset, word_type *data, int length);
u32 XPredict_Read_tree_24_Words(XPredict *InstancePtr, int offset, word_type *data, int length);
u32 XPredict_Write_tree_24_Bytes(XPredict *InstancePtr, int offset, char *data, int length);
u32 XPredict_Read_tree_24_Bytes(XPredict *InstancePtr, int offset, char *data, int length);
u32 XPredict_Get_tree_25_BaseAddress(XPredict *InstancePtr);
u32 XPredict_Get_tree_25_HighAddress(XPredict *InstancePtr);
u32 XPredict_Get_tree_25_TotalBytes(XPredict *InstancePtr);
u32 XPredict_Get_tree_25_BitWidth(XPredict *InstancePtr);
u32 XPredict_Get_tree_25_Depth(XPredict *InstancePtr);
u32 XPredict_Write_tree_25_Words(XPredict *InstancePtr, int offset, word_type *data, int length);
u32 XPredict_Read_tree_25_Words(XPredict *InstancePtr, int offset, word_type *data, int length);
u32 XPredict_Write_tree_25_Bytes(XPredict *InstancePtr, int offset, char *data, int length);
u32 XPredict_Read_tree_25_Bytes(XPredict *InstancePtr, int offset, char *data, int length);
u32 XPredict_Get_tree_26_BaseAddress(XPredict *InstancePtr);
u32 XPredict_Get_tree_26_HighAddress(XPredict *InstancePtr);
u32 XPredict_Get_tree_26_TotalBytes(XPredict *InstancePtr);
u32 XPredict_Get_tree_26_BitWidth(XPredict *InstancePtr);
u32 XPredict_Get_tree_26_Depth(XPredict *InstancePtr);
u32 XPredict_Write_tree_26_Words(XPredict *InstancePtr, int offset, word_type *data, int length);
u32 XPredict_Read_tree_26_Words(XPredict *InstancePtr, int offset, word_type *data, int length);
u32 XPredict_Write_tree_26_Bytes(XPredict *InstancePtr, int offset, char *data, int length);
u32 XPredict_Read_tree_26_Bytes(XPredict *InstancePtr, int offset, char *data, int length);
u32 XPredict_Get_tree_27_BaseAddress(XPredict *InstancePtr);
u32 XPredict_Get_tree_27_HighAddress(XPredict *InstancePtr);
u32 XPredict_Get_tree_27_TotalBytes(XPredict *InstancePtr);
u32 XPredict_Get_tree_27_BitWidth(XPredict *InstancePtr);
u32 XPredict_Get_tree_27_Depth(XPredict *InstancePtr);
u32 XPredict_Write_tree_27_Words(XPredict *InstancePtr, int offset, word_type *data, int length);
u32 XPredict_Read_tree_27_Words(XPredict *InstancePtr, int offset, word_type *data, int length);
u32 XPredict_Write_tree_27_Bytes(XPredict *InstancePtr, int offset, char *data, int length);
u32 XPredict_Read_tree_27_Bytes(XPredict *InstancePtr, int offset, char *data, int length);
u32 XPredict_Get_tree_28_BaseAddress(XPredict *InstancePtr);
u32 XPredict_Get_tree_28_HighAddress(XPredict *InstancePtr);
u32 XPredict_Get_tree_28_TotalBytes(XPredict *InstancePtr);
u32 XPredict_Get_tree_28_BitWidth(XPredict *InstancePtr);
u32 XPredict_Get_tree_28_Depth(XPredict *InstancePtr);
u32 XPredict_Write_tree_28_Words(XPredict *InstancePtr, int offset, word_type *data, int length);
u32 XPredict_Read_tree_28_Words(XPredict *InstancePtr, int offset, word_type *data, int length);
u32 XPredict_Write_tree_28_Bytes(XPredict *InstancePtr, int offset, char *data, int length);
u32 XPredict_Read_tree_28_Bytes(XPredict *InstancePtr, int offset, char *data, int length);
u32 XPredict_Get_tree_29_BaseAddress(XPredict *InstancePtr);
u32 XPredict_Get_tree_29_HighAddress(XPredict *InstancePtr);
u32 XPredict_Get_tree_29_TotalBytes(XPredict *InstancePtr);
u32 XPredict_Get_tree_29_BitWidth(XPredict *InstancePtr);
u32 XPredict_Get_tree_29_Depth(XPredict *InstancePtr);
u32 XPredict_Write_tree_29_Words(XPredict *InstancePtr, int offset, word_type *data, int length);
u32 XPredict_Read_tree_29_Words(XPredict *InstancePtr, int offset, word_type *data, int length);
u32 XPredict_Write_tree_29_Bytes(XPredict *InstancePtr, int offset, char *data, int length);
u32 XPredict_Read_tree_29_Bytes(XPredict *InstancePtr, int offset, char *data, int length);
u32 XPredict_Get_tree_30_BaseAddress(XPredict *InstancePtr);
u32 XPredict_Get_tree_30_HighAddress(XPredict *InstancePtr);
u32 XPredict_Get_tree_30_TotalBytes(XPredict *InstancePtr);
u32 XPredict_Get_tree_30_BitWidth(XPredict *InstancePtr);
u32 XPredict_Get_tree_30_Depth(XPredict *InstancePtr);
u32 XPredict_Write_tree_30_Words(XPredict *InstancePtr, int offset, word_type *data, int length);
u32 XPredict_Read_tree_30_Words(XPredict *InstancePtr, int offset, word_type *data, int length);
u32 XPredict_Write_tree_30_Bytes(XPredict *InstancePtr, int offset, char *data, int length);
u32 XPredict_Read_tree_30_Bytes(XPredict *InstancePtr, int offset, char *data, int length);
u32 XPredict_Get_tree_31_BaseAddress(XPredict *InstancePtr);
u32 XPredict_Get_tree_31_HighAddress(XPredict *InstancePtr);
u32 XPredict_Get_tree_31_TotalBytes(XPredict *InstancePtr);
u32 XPredict_Get_tree_31_BitWidth(XPredict *InstancePtr);
u32 XPredict_Get_tree_31_Depth(XPredict *InstancePtr);
u32 XPredict_Write_tree_31_Words(XPredict *InstancePtr, int offset, word_type *data, int length);
u32 XPredict_Read_tree_31_Words(XPredict *InstancePtr, int offset, word_type *data, int length);
u32 XPredict_Write_tree_31_Bytes(XPredict *InstancePtr, int offset, char *data, int length);
u32 XPredict_Read_tree_31_Bytes(XPredict *InstancePtr, int offset, char *data, int length);
u32 XPredict_Get_tree_32_BaseAddress(XPredict *InstancePtr);
u32 XPredict_Get_tree_32_HighAddress(XPredict *InstancePtr);
u32 XPredict_Get_tree_32_TotalBytes(XPredict *InstancePtr);
u32 XPredict_Get_tree_32_BitWidth(XPredict *InstancePtr);
u32 XPredict_Get_tree_32_Depth(XPredict *InstancePtr);
u32 XPredict_Write_tree_32_Words(XPredict *InstancePtr, int offset, word_type *data, int length);
u32 XPredict_Read_tree_32_Words(XPredict *InstancePtr, int offset, word_type *data, int length);
u32 XPredict_Write_tree_32_Bytes(XPredict *InstancePtr, int offset, char *data, int length);
u32 XPredict_Read_tree_32_Bytes(XPredict *InstancePtr, int offset, char *data, int length);
u32 XPredict_Get_tree_33_BaseAddress(XPredict *InstancePtr);
u32 XPredict_Get_tree_33_HighAddress(XPredict *InstancePtr);
u32 XPredict_Get_tree_33_TotalBytes(XPredict *InstancePtr);
u32 XPredict_Get_tree_33_BitWidth(XPredict *InstancePtr);
u32 XPredict_Get_tree_33_Depth(XPredict *InstancePtr);
u32 XPredict_Write_tree_33_Words(XPredict *InstancePtr, int offset, word_type *data, int length);
u32 XPredict_Read_tree_33_Words(XPredict *InstancePtr, int offset, word_type *data, int length);
u32 XPredict_Write_tree_33_Bytes(XPredict *InstancePtr, int offset, char *data, int length);
u32 XPredict_Read_tree_33_Bytes(XPredict *InstancePtr, int offset, char *data, int length);
u32 XPredict_Get_tree_34_BaseAddress(XPredict *InstancePtr);
u32 XPredict_Get_tree_34_HighAddress(XPredict *InstancePtr);
u32 XPredict_Get_tree_34_TotalBytes(XPredict *InstancePtr);
u32 XPredict_Get_tree_34_BitWidth(XPredict *InstancePtr);
u32 XPredict_Get_tree_34_Depth(XPredict *InstancePtr);
u32 XPredict_Write_tree_34_Words(XPredict *InstancePtr, int offset, word_type *data, int length);
u32 XPredict_Read_tree_34_Words(XPredict *InstancePtr, int offset, word_type *data, int length);
u32 XPredict_Write_tree_34_Bytes(XPredict *InstancePtr, int offset, char *data, int length);
u32 XPredict_Read_tree_34_Bytes(XPredict *InstancePtr, int offset, char *data, int length);
u32 XPredict_Get_tree_35_BaseAddress(XPredict *InstancePtr);
u32 XPredict_Get_tree_35_HighAddress(XPredict *InstancePtr);
u32 XPredict_Get_tree_35_TotalBytes(XPredict *InstancePtr);
u32 XPredict_Get_tree_35_BitWidth(XPredict *InstancePtr);
u32 XPredict_Get_tree_35_Depth(XPredict *InstancePtr);
u32 XPredict_Write_tree_35_Words(XPredict *InstancePtr, int offset, word_type *data, int length);
u32 XPredict_Read_tree_35_Words(XPredict *InstancePtr, int offset, word_type *data, int length);
u32 XPredict_Write_tree_35_Bytes(XPredict *InstancePtr, int offset, char *data, int length);
u32 XPredict_Read_tree_35_Bytes(XPredict *InstancePtr, int offset, char *data, int length);
u32 XPredict_Get_tree_36_BaseAddress(XPredict *InstancePtr);
u32 XPredict_Get_tree_36_HighAddress(XPredict *InstancePtr);
u32 XPredict_Get_tree_36_TotalBytes(XPredict *InstancePtr);
u32 XPredict_Get_tree_36_BitWidth(XPredict *InstancePtr);
u32 XPredict_Get_tree_36_Depth(XPredict *InstancePtr);
u32 XPredict_Write_tree_36_Words(XPredict *InstancePtr, int offset, word_type *data, int length);
u32 XPredict_Read_tree_36_Words(XPredict *InstancePtr, int offset, word_type *data, int length);
u32 XPredict_Write_tree_36_Bytes(XPredict *InstancePtr, int offset, char *data, int length);
u32 XPredict_Read_tree_36_Bytes(XPredict *InstancePtr, int offset, char *data, int length);
u32 XPredict_Get_tree_37_BaseAddress(XPredict *InstancePtr);
u32 XPredict_Get_tree_37_HighAddress(XPredict *InstancePtr);
u32 XPredict_Get_tree_37_TotalBytes(XPredict *InstancePtr);
u32 XPredict_Get_tree_37_BitWidth(XPredict *InstancePtr);
u32 XPredict_Get_tree_37_Depth(XPredict *InstancePtr);
u32 XPredict_Write_tree_37_Words(XPredict *InstancePtr, int offset, word_type *data, int length);
u32 XPredict_Read_tree_37_Words(XPredict *InstancePtr, int offset, word_type *data, int length);
u32 XPredict_Write_tree_37_Bytes(XPredict *InstancePtr, int offset, char *data, int length);
u32 XPredict_Read_tree_37_Bytes(XPredict *InstancePtr, int offset, char *data, int length);
u32 XPredict_Get_tree_38_BaseAddress(XPredict *InstancePtr);
u32 XPredict_Get_tree_38_HighAddress(XPredict *InstancePtr);
u32 XPredict_Get_tree_38_TotalBytes(XPredict *InstancePtr);
u32 XPredict_Get_tree_38_BitWidth(XPredict *InstancePtr);
u32 XPredict_Get_tree_38_Depth(XPredict *InstancePtr);
u32 XPredict_Write_tree_38_Words(XPredict *InstancePtr, int offset, word_type *data, int length);
u32 XPredict_Read_tree_38_Words(XPredict *InstancePtr, int offset, word_type *data, int length);
u32 XPredict_Write_tree_38_Bytes(XPredict *InstancePtr, int offset, char *data, int length);
u32 XPredict_Read_tree_38_Bytes(XPredict *InstancePtr, int offset, char *data, int length);
u32 XPredict_Get_tree_39_BaseAddress(XPredict *InstancePtr);
u32 XPredict_Get_tree_39_HighAddress(XPredict *InstancePtr);
u32 XPredict_Get_tree_39_TotalBytes(XPredict *InstancePtr);
u32 XPredict_Get_tree_39_BitWidth(XPredict *InstancePtr);
u32 XPredict_Get_tree_39_Depth(XPredict *InstancePtr);
u32 XPredict_Write_tree_39_Words(XPredict *InstancePtr, int offset, word_type *data, int length);
u32 XPredict_Read_tree_39_Words(XPredict *InstancePtr, int offset, word_type *data, int length);
u32 XPredict_Write_tree_39_Bytes(XPredict *InstancePtr, int offset, char *data, int length);
u32 XPredict_Read_tree_39_Bytes(XPredict *InstancePtr, int offset, char *data, int length);
u32 XPredict_Get_tree_40_BaseAddress(XPredict *InstancePtr);
u32 XPredict_Get_tree_40_HighAddress(XPredict *InstancePtr);
u32 XPredict_Get_tree_40_TotalBytes(XPredict *InstancePtr);
u32 XPredict_Get_tree_40_BitWidth(XPredict *InstancePtr);
u32 XPredict_Get_tree_40_Depth(XPredict *InstancePtr);
u32 XPredict_Write_tree_40_Words(XPredict *InstancePtr, int offset, word_type *data, int length);
u32 XPredict_Read_tree_40_Words(XPredict *InstancePtr, int offset, word_type *data, int length);
u32 XPredict_Write_tree_40_Bytes(XPredict *InstancePtr, int offset, char *data, int length);
u32 XPredict_Read_tree_40_Bytes(XPredict *InstancePtr, int offset, char *data, int length);
u32 XPredict_Get_tree_41_BaseAddress(XPredict *InstancePtr);
u32 XPredict_Get_tree_41_HighAddress(XPredict *InstancePtr);
u32 XPredict_Get_tree_41_TotalBytes(XPredict *InstancePtr);
u32 XPredict_Get_tree_41_BitWidth(XPredict *InstancePtr);
u32 XPredict_Get_tree_41_Depth(XPredict *InstancePtr);
u32 XPredict_Write_tree_41_Words(XPredict *InstancePtr, int offset, word_type *data, int length);
u32 XPredict_Read_tree_41_Words(XPredict *InstancePtr, int offset, word_type *data, int length);
u32 XPredict_Write_tree_41_Bytes(XPredict *InstancePtr, int offset, char *data, int length);
u32 XPredict_Read_tree_41_Bytes(XPredict *InstancePtr, int offset, char *data, int length);
u32 XPredict_Get_tree_42_BaseAddress(XPredict *InstancePtr);
u32 XPredict_Get_tree_42_HighAddress(XPredict *InstancePtr);
u32 XPredict_Get_tree_42_TotalBytes(XPredict *InstancePtr);
u32 XPredict_Get_tree_42_BitWidth(XPredict *InstancePtr);
u32 XPredict_Get_tree_42_Depth(XPredict *InstancePtr);
u32 XPredict_Write_tree_42_Words(XPredict *InstancePtr, int offset, word_type *data, int length);
u32 XPredict_Read_tree_42_Words(XPredict *InstancePtr, int offset, word_type *data, int length);
u32 XPredict_Write_tree_42_Bytes(XPredict *InstancePtr, int offset, char *data, int length);
u32 XPredict_Read_tree_42_Bytes(XPredict *InstancePtr, int offset, char *data, int length);
u32 XPredict_Get_tree_43_BaseAddress(XPredict *InstancePtr);
u32 XPredict_Get_tree_43_HighAddress(XPredict *InstancePtr);
u32 XPredict_Get_tree_43_TotalBytes(XPredict *InstancePtr);
u32 XPredict_Get_tree_43_BitWidth(XPredict *InstancePtr);
u32 XPredict_Get_tree_43_Depth(XPredict *InstancePtr);
u32 XPredict_Write_tree_43_Words(XPredict *InstancePtr, int offset, word_type *data, int length);
u32 XPredict_Read_tree_43_Words(XPredict *InstancePtr, int offset, word_type *data, int length);
u32 XPredict_Write_tree_43_Bytes(XPredict *InstancePtr, int offset, char *data, int length);
u32 XPredict_Read_tree_43_Bytes(XPredict *InstancePtr, int offset, char *data, int length);
u32 XPredict_Get_tree_44_BaseAddress(XPredict *InstancePtr);
u32 XPredict_Get_tree_44_HighAddress(XPredict *InstancePtr);
u32 XPredict_Get_tree_44_TotalBytes(XPredict *InstancePtr);
u32 XPredict_Get_tree_44_BitWidth(XPredict *InstancePtr);
u32 XPredict_Get_tree_44_Depth(XPredict *InstancePtr);
u32 XPredict_Write_tree_44_Words(XPredict *InstancePtr, int offset, word_type *data, int length);
u32 XPredict_Read_tree_44_Words(XPredict *InstancePtr, int offset, word_type *data, int length);
u32 XPredict_Write_tree_44_Bytes(XPredict *InstancePtr, int offset, char *data, int length);
u32 XPredict_Read_tree_44_Bytes(XPredict *InstancePtr, int offset, char *data, int length);
u32 XPredict_Get_tree_45_BaseAddress(XPredict *InstancePtr);
u32 XPredict_Get_tree_45_HighAddress(XPredict *InstancePtr);
u32 XPredict_Get_tree_45_TotalBytes(XPredict *InstancePtr);
u32 XPredict_Get_tree_45_BitWidth(XPredict *InstancePtr);
u32 XPredict_Get_tree_45_Depth(XPredict *InstancePtr);
u32 XPredict_Write_tree_45_Words(XPredict *InstancePtr, int offset, word_type *data, int length);
u32 XPredict_Read_tree_45_Words(XPredict *InstancePtr, int offset, word_type *data, int length);
u32 XPredict_Write_tree_45_Bytes(XPredict *InstancePtr, int offset, char *data, int length);
u32 XPredict_Read_tree_45_Bytes(XPredict *InstancePtr, int offset, char *data, int length);
u32 XPredict_Get_tree_46_BaseAddress(XPredict *InstancePtr);
u32 XPredict_Get_tree_46_HighAddress(XPredict *InstancePtr);
u32 XPredict_Get_tree_46_TotalBytes(XPredict *InstancePtr);
u32 XPredict_Get_tree_46_BitWidth(XPredict *InstancePtr);
u32 XPredict_Get_tree_46_Depth(XPredict *InstancePtr);
u32 XPredict_Write_tree_46_Words(XPredict *InstancePtr, int offset, word_type *data, int length);
u32 XPredict_Read_tree_46_Words(XPredict *InstancePtr, int offset, word_type *data, int length);
u32 XPredict_Write_tree_46_Bytes(XPredict *InstancePtr, int offset, char *data, int length);
u32 XPredict_Read_tree_46_Bytes(XPredict *InstancePtr, int offset, char *data, int length);
u32 XPredict_Get_tree_47_BaseAddress(XPredict *InstancePtr);
u32 XPredict_Get_tree_47_HighAddress(XPredict *InstancePtr);
u32 XPredict_Get_tree_47_TotalBytes(XPredict *InstancePtr);
u32 XPredict_Get_tree_47_BitWidth(XPredict *InstancePtr);
u32 XPredict_Get_tree_47_Depth(XPredict *InstancePtr);
u32 XPredict_Write_tree_47_Words(XPredict *InstancePtr, int offset, word_type *data, int length);
u32 XPredict_Read_tree_47_Words(XPredict *InstancePtr, int offset, word_type *data, int length);
u32 XPredict_Write_tree_47_Bytes(XPredict *InstancePtr, int offset, char *data, int length);
u32 XPredict_Read_tree_47_Bytes(XPredict *InstancePtr, int offset, char *data, int length);
u32 XPredict_Get_tree_48_BaseAddress(XPredict *InstancePtr);
u32 XPredict_Get_tree_48_HighAddress(XPredict *InstancePtr);
u32 XPredict_Get_tree_48_TotalBytes(XPredict *InstancePtr);
u32 XPredict_Get_tree_48_BitWidth(XPredict *InstancePtr);
u32 XPredict_Get_tree_48_Depth(XPredict *InstancePtr);
u32 XPredict_Write_tree_48_Words(XPredict *InstancePtr, int offset, word_type *data, int length);
u32 XPredict_Read_tree_48_Words(XPredict *InstancePtr, int offset, word_type *data, int length);
u32 XPredict_Write_tree_48_Bytes(XPredict *InstancePtr, int offset, char *data, int length);
u32 XPredict_Read_tree_48_Bytes(XPredict *InstancePtr, int offset, char *data, int length);
u32 XPredict_Get_tree_49_BaseAddress(XPredict *InstancePtr);
u32 XPredict_Get_tree_49_HighAddress(XPredict *InstancePtr);
u32 XPredict_Get_tree_49_TotalBytes(XPredict *InstancePtr);
u32 XPredict_Get_tree_49_BitWidth(XPredict *InstancePtr);
u32 XPredict_Get_tree_49_Depth(XPredict *InstancePtr);
u32 XPredict_Write_tree_49_Words(XPredict *InstancePtr, int offset, word_type *data, int length);
u32 XPredict_Read_tree_49_Words(XPredict *InstancePtr, int offset, word_type *data, int length);
u32 XPredict_Write_tree_49_Bytes(XPredict *InstancePtr, int offset, char *data, int length);
u32 XPredict_Read_tree_49_Bytes(XPredict *InstancePtr, int offset, char *data, int length);
u32 XPredict_Get_tree_50_BaseAddress(XPredict *InstancePtr);
u32 XPredict_Get_tree_50_HighAddress(XPredict *InstancePtr);
u32 XPredict_Get_tree_50_TotalBytes(XPredict *InstancePtr);
u32 XPredict_Get_tree_50_BitWidth(XPredict *InstancePtr);
u32 XPredict_Get_tree_50_Depth(XPredict *InstancePtr);
u32 XPredict_Write_tree_50_Words(XPredict *InstancePtr, int offset, word_type *data, int length);
u32 XPredict_Read_tree_50_Words(XPredict *InstancePtr, int offset, word_type *data, int length);
u32 XPredict_Write_tree_50_Bytes(XPredict *InstancePtr, int offset, char *data, int length);
u32 XPredict_Read_tree_50_Bytes(XPredict *InstancePtr, int offset, char *data, int length);
u32 XPredict_Get_tree_51_BaseAddress(XPredict *InstancePtr);
u32 XPredict_Get_tree_51_HighAddress(XPredict *InstancePtr);
u32 XPredict_Get_tree_51_TotalBytes(XPredict *InstancePtr);
u32 XPredict_Get_tree_51_BitWidth(XPredict *InstancePtr);
u32 XPredict_Get_tree_51_Depth(XPredict *InstancePtr);
u32 XPredict_Write_tree_51_Words(XPredict *InstancePtr, int offset, word_type *data, int length);
u32 XPredict_Read_tree_51_Words(XPredict *InstancePtr, int offset, word_type *data, int length);
u32 XPredict_Write_tree_51_Bytes(XPredict *InstancePtr, int offset, char *data, int length);
u32 XPredict_Read_tree_51_Bytes(XPredict *InstancePtr, int offset, char *data, int length);
u32 XPredict_Get_tree_52_BaseAddress(XPredict *InstancePtr);
u32 XPredict_Get_tree_52_HighAddress(XPredict *InstancePtr);
u32 XPredict_Get_tree_52_TotalBytes(XPredict *InstancePtr);
u32 XPredict_Get_tree_52_BitWidth(XPredict *InstancePtr);
u32 XPredict_Get_tree_52_Depth(XPredict *InstancePtr);
u32 XPredict_Write_tree_52_Words(XPredict *InstancePtr, int offset, word_type *data, int length);
u32 XPredict_Read_tree_52_Words(XPredict *InstancePtr, int offset, word_type *data, int length);
u32 XPredict_Write_tree_52_Bytes(XPredict *InstancePtr, int offset, char *data, int length);
u32 XPredict_Read_tree_52_Bytes(XPredict *InstancePtr, int offset, char *data, int length);
u32 XPredict_Get_tree_53_BaseAddress(XPredict *InstancePtr);
u32 XPredict_Get_tree_53_HighAddress(XPredict *InstancePtr);
u32 XPredict_Get_tree_53_TotalBytes(XPredict *InstancePtr);
u32 XPredict_Get_tree_53_BitWidth(XPredict *InstancePtr);
u32 XPredict_Get_tree_53_Depth(XPredict *InstancePtr);
u32 XPredict_Write_tree_53_Words(XPredict *InstancePtr, int offset, word_type *data, int length);
u32 XPredict_Read_tree_53_Words(XPredict *InstancePtr, int offset, word_type *data, int length);
u32 XPredict_Write_tree_53_Bytes(XPredict *InstancePtr, int offset, char *data, int length);
u32 XPredict_Read_tree_53_Bytes(XPredict *InstancePtr, int offset, char *data, int length);
u32 XPredict_Get_tree_54_BaseAddress(XPredict *InstancePtr);
u32 XPredict_Get_tree_54_HighAddress(XPredict *InstancePtr);
u32 XPredict_Get_tree_54_TotalBytes(XPredict *InstancePtr);
u32 XPredict_Get_tree_54_BitWidth(XPredict *InstancePtr);
u32 XPredict_Get_tree_54_Depth(XPredict *InstancePtr);
u32 XPredict_Write_tree_54_Words(XPredict *InstancePtr, int offset, word_type *data, int length);
u32 XPredict_Read_tree_54_Words(XPredict *InstancePtr, int offset, word_type *data, int length);
u32 XPredict_Write_tree_54_Bytes(XPredict *InstancePtr, int offset, char *data, int length);
u32 XPredict_Read_tree_54_Bytes(XPredict *InstancePtr, int offset, char *data, int length);
u32 XPredict_Get_tree_55_BaseAddress(XPredict *InstancePtr);
u32 XPredict_Get_tree_55_HighAddress(XPredict *InstancePtr);
u32 XPredict_Get_tree_55_TotalBytes(XPredict *InstancePtr);
u32 XPredict_Get_tree_55_BitWidth(XPredict *InstancePtr);
u32 XPredict_Get_tree_55_Depth(XPredict *InstancePtr);
u32 XPredict_Write_tree_55_Words(XPredict *InstancePtr, int offset, word_type *data, int length);
u32 XPredict_Read_tree_55_Words(XPredict *InstancePtr, int offset, word_type *data, int length);
u32 XPredict_Write_tree_55_Bytes(XPredict *InstancePtr, int offset, char *data, int length);
u32 XPredict_Read_tree_55_Bytes(XPredict *InstancePtr, int offset, char *data, int length);
u32 XPredict_Get_tree_56_BaseAddress(XPredict *InstancePtr);
u32 XPredict_Get_tree_56_HighAddress(XPredict *InstancePtr);
u32 XPredict_Get_tree_56_TotalBytes(XPredict *InstancePtr);
u32 XPredict_Get_tree_56_BitWidth(XPredict *InstancePtr);
u32 XPredict_Get_tree_56_Depth(XPredict *InstancePtr);
u32 XPredict_Write_tree_56_Words(XPredict *InstancePtr, int offset, word_type *data, int length);
u32 XPredict_Read_tree_56_Words(XPredict *InstancePtr, int offset, word_type *data, int length);
u32 XPredict_Write_tree_56_Bytes(XPredict *InstancePtr, int offset, char *data, int length);
u32 XPredict_Read_tree_56_Bytes(XPredict *InstancePtr, int offset, char *data, int length);
u32 XPredict_Get_tree_57_BaseAddress(XPredict *InstancePtr);
u32 XPredict_Get_tree_57_HighAddress(XPredict *InstancePtr);
u32 XPredict_Get_tree_57_TotalBytes(XPredict *InstancePtr);
u32 XPredict_Get_tree_57_BitWidth(XPredict *InstancePtr);
u32 XPredict_Get_tree_57_Depth(XPredict *InstancePtr);
u32 XPredict_Write_tree_57_Words(XPredict *InstancePtr, int offset, word_type *data, int length);
u32 XPredict_Read_tree_57_Words(XPredict *InstancePtr, int offset, word_type *data, int length);
u32 XPredict_Write_tree_57_Bytes(XPredict *InstancePtr, int offset, char *data, int length);
u32 XPredict_Read_tree_57_Bytes(XPredict *InstancePtr, int offset, char *data, int length);
u32 XPredict_Get_tree_58_BaseAddress(XPredict *InstancePtr);
u32 XPredict_Get_tree_58_HighAddress(XPredict *InstancePtr);
u32 XPredict_Get_tree_58_TotalBytes(XPredict *InstancePtr);
u32 XPredict_Get_tree_58_BitWidth(XPredict *InstancePtr);
u32 XPredict_Get_tree_58_Depth(XPredict *InstancePtr);
u32 XPredict_Write_tree_58_Words(XPredict *InstancePtr, int offset, word_type *data, int length);
u32 XPredict_Read_tree_58_Words(XPredict *InstancePtr, int offset, word_type *data, int length);
u32 XPredict_Write_tree_58_Bytes(XPredict *InstancePtr, int offset, char *data, int length);
u32 XPredict_Read_tree_58_Bytes(XPredict *InstancePtr, int offset, char *data, int length);
u32 XPredict_Get_tree_59_BaseAddress(XPredict *InstancePtr);
u32 XPredict_Get_tree_59_HighAddress(XPredict *InstancePtr);
u32 XPredict_Get_tree_59_TotalBytes(XPredict *InstancePtr);
u32 XPredict_Get_tree_59_BitWidth(XPredict *InstancePtr);
u32 XPredict_Get_tree_59_Depth(XPredict *InstancePtr);
u32 XPredict_Write_tree_59_Words(XPredict *InstancePtr, int offset, word_type *data, int length);
u32 XPredict_Read_tree_59_Words(XPredict *InstancePtr, int offset, word_type *data, int length);
u32 XPredict_Write_tree_59_Bytes(XPredict *InstancePtr, int offset, char *data, int length);
u32 XPredict_Read_tree_59_Bytes(XPredict *InstancePtr, int offset, char *data, int length);
u32 XPredict_Get_tree_60_BaseAddress(XPredict *InstancePtr);
u32 XPredict_Get_tree_60_HighAddress(XPredict *InstancePtr);
u32 XPredict_Get_tree_60_TotalBytes(XPredict *InstancePtr);
u32 XPredict_Get_tree_60_BitWidth(XPredict *InstancePtr);
u32 XPredict_Get_tree_60_Depth(XPredict *InstancePtr);
u32 XPredict_Write_tree_60_Words(XPredict *InstancePtr, int offset, word_type *data, int length);
u32 XPredict_Read_tree_60_Words(XPredict *InstancePtr, int offset, word_type *data, int length);
u32 XPredict_Write_tree_60_Bytes(XPredict *InstancePtr, int offset, char *data, int length);
u32 XPredict_Read_tree_60_Bytes(XPredict *InstancePtr, int offset, char *data, int length);
u32 XPredict_Get_tree_61_BaseAddress(XPredict *InstancePtr);
u32 XPredict_Get_tree_61_HighAddress(XPredict *InstancePtr);
u32 XPredict_Get_tree_61_TotalBytes(XPredict *InstancePtr);
u32 XPredict_Get_tree_61_BitWidth(XPredict *InstancePtr);
u32 XPredict_Get_tree_61_Depth(XPredict *InstancePtr);
u32 XPredict_Write_tree_61_Words(XPredict *InstancePtr, int offset, word_type *data, int length);
u32 XPredict_Read_tree_61_Words(XPredict *InstancePtr, int offset, word_type *data, int length);
u32 XPredict_Write_tree_61_Bytes(XPredict *InstancePtr, int offset, char *data, int length);
u32 XPredict_Read_tree_61_Bytes(XPredict *InstancePtr, int offset, char *data, int length);
u32 XPredict_Get_tree_62_BaseAddress(XPredict *InstancePtr);
u32 XPredict_Get_tree_62_HighAddress(XPredict *InstancePtr);
u32 XPredict_Get_tree_62_TotalBytes(XPredict *InstancePtr);
u32 XPredict_Get_tree_62_BitWidth(XPredict *InstancePtr);
u32 XPredict_Get_tree_62_Depth(XPredict *InstancePtr);
u32 XPredict_Write_tree_62_Words(XPredict *InstancePtr, int offset, word_type *data, int length);
u32 XPredict_Read_tree_62_Words(XPredict *InstancePtr, int offset, word_type *data, int length);
u32 XPredict_Write_tree_62_Bytes(XPredict *InstancePtr, int offset, char *data, int length);
u32 XPredict_Read_tree_62_Bytes(XPredict *InstancePtr, int offset, char *data, int length);
u32 XPredict_Get_tree_63_BaseAddress(XPredict *InstancePtr);
u32 XPredict_Get_tree_63_HighAddress(XPredict *InstancePtr);
u32 XPredict_Get_tree_63_TotalBytes(XPredict *InstancePtr);
u32 XPredict_Get_tree_63_BitWidth(XPredict *InstancePtr);
u32 XPredict_Get_tree_63_Depth(XPredict *InstancePtr);
u32 XPredict_Write_tree_63_Words(XPredict *InstancePtr, int offset, word_type *data, int length);
u32 XPredict_Read_tree_63_Words(XPredict *InstancePtr, int offset, word_type *data, int length);
u32 XPredict_Write_tree_63_Bytes(XPredict *InstancePtr, int offset, char *data, int length);
u32 XPredict_Read_tree_63_Bytes(XPredict *InstancePtr, int offset, char *data, int length);

void XPredict_InterruptGlobalEnable(XPredict *InstancePtr);
void XPredict_InterruptGlobalDisable(XPredict *InstancePtr);
void XPredict_InterruptEnable(XPredict *InstancePtr, u32 Mask);
void XPredict_InterruptDisable(XPredict *InstancePtr, u32 Mask);
void XPredict_InterruptClear(XPredict *InstancePtr, u32 Mask);
u32 XPredict_InterruptGetEnabled(XPredict *InstancePtr);
u32 XPredict_InterruptGetStatus(XPredict *InstancePtr);

#ifdef __cplusplus
}
#endif

#endif
