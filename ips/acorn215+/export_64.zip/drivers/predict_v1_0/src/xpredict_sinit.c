// ==============================================================
// Vitis HLS - High-Level Synthesis from C, C++ and OpenCL v2023.1.1 (64-bit)
// Tool Version Limit: 2023.06
// Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
// Copyright 2022-2023 Advanced Micro Devices, Inc. All Rights Reserved.
// 
// ==============================================================
#ifndef __linux__

#include "xstatus.h"
#include "xparameters.h"
#include "xpredict.h"

extern XPredict_Config XPredict_ConfigTable[];

XPredict_Config *XPredict_LookupConfig(u16 DeviceId) {
	XPredict_Config *ConfigPtr = NULL;

	int Index;

	for (Index = 0; Index < XPAR_XPREDICT_NUM_INSTANCES; Index++) {
		if (XPredict_ConfigTable[Index].DeviceId == DeviceId) {
			ConfigPtr = &XPredict_ConfigTable[Index];
			break;
		}
	}

	return ConfigPtr;
}

int XPredict_Initialize(XPredict *InstancePtr, u16 DeviceId) {
	XPredict_Config *ConfigPtr;

	Xil_AssertNonvoid(InstancePtr != NULL);

	ConfigPtr = XPredict_LookupConfig(DeviceId);
	if (ConfigPtr == NULL) {
		InstancePtr->IsReady = 0;
		return (XST_DEVICE_NOT_FOUND);
	}

	return XPredict_CfgInitialize(InstancePtr, ConfigPtr);
}

#endif

