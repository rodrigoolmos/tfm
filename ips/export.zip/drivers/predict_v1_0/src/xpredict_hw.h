// ==============================================================
// Vitis HLS - High-Level Synthesis from C, C++ and OpenCL v2023.1.1 (64-bit)
// Tool Version Limit: 2023.06
// Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
// Copyright 2022-2023 Advanced Micro Devices, Inc. All Rights Reserved.
// 
// ==============================================================
// control
// 0x0 : Control signals
//       bit 0  - ap_start (Read/Write/COH)
//       bit 1  - ap_done (Read/COR)
//       bit 2  - ap_idle (Read)
//       bit 3  - ap_ready (Read/COR)
//       bit 7  - auto_restart (Read/Write)
//       bit 9  - interrupt (Read)
//       others - reserved
// 0x4 : Global Interrupt Enable Register
//       bit 0  - Global Interrupt Enable (Read/Write)
//       others - reserved
// 0x8 : IP Interrupt Enable Register (Read/Write)
//       bit 0 - enable ap_done interrupt (Read/Write)
//       bit 1 - enable ap_ready interrupt (Read/Write)
//       others - reserved
// 0xc : IP Interrupt Status Register (Read/TOW)
//       bit 0 - ap_done (Read/TOW)
//       bit 1 - ap_ready (Read/TOW)
//       others - reserved
// (SC = Self Clear, COR = Clear on Read, TOW = Toggle on Write, COH = Clear on Handshake)

#define XPREDICT_CONTROL_ADDR_AP_CTRL 0x0
#define XPREDICT_CONTROL_ADDR_GIE     0x4
#define XPREDICT_CONTROL_ADDR_IER     0x8
#define XPREDICT_CONTROL_ADDR_ISR     0xc

// features
// 0x000 : reserved
// 0x004 : reserved
// 0x008 : reserved
// 0x00c : reserved
// 0x010 : Data signal of features_0
//         bit 31~0 - features_0[31:0] (Read/Write)
// 0x014 : reserved
// 0x018 : Data signal of features_1
//         bit 31~0 - features_1[31:0] (Read/Write)
// 0x01c : reserved
// 0x020 : Data signal of features_2
//         bit 31~0 - features_2[31:0] (Read/Write)
// 0x024 : reserved
// 0x028 : Data signal of features_3
//         bit 31~0 - features_3[31:0] (Read/Write)
// 0x02c : reserved
// 0x030 : Data signal of features_4
//         bit 31~0 - features_4[31:0] (Read/Write)
// 0x034 : reserved
// 0x038 : Data signal of features_5
//         bit 31~0 - features_5[31:0] (Read/Write)
// 0x03c : reserved
// 0x040 : Data signal of features_6
//         bit 31~0 - features_6[31:0] (Read/Write)
// 0x044 : reserved
// 0x048 : Data signal of features_7
//         bit 31~0 - features_7[31:0] (Read/Write)
// 0x04c : reserved
// 0x050 : Data signal of features_8
//         bit 31~0 - features_8[31:0] (Read/Write)
// 0x054 : reserved
// 0x058 : Data signal of features_9
//         bit 31~0 - features_9[31:0] (Read/Write)
// 0x05c : reserved
// 0x060 : Data signal of features_10
//         bit 31~0 - features_10[31:0] (Read/Write)
// 0x064 : reserved
// 0x068 : Data signal of features_11
//         bit 31~0 - features_11[31:0] (Read/Write)
// 0x06c : reserved
// 0x070 : Data signal of features_12
//         bit 31~0 - features_12[31:0] (Read/Write)
// 0x074 : reserved
// 0x078 : Data signal of features_13
//         bit 31~0 - features_13[31:0] (Read/Write)
// 0x07c : reserved
// 0x080 : Data signal of features_14
//         bit 31~0 - features_14[31:0] (Read/Write)
// 0x084 : reserved
// 0x088 : Data signal of features_15
//         bit 31~0 - features_15[31:0] (Read/Write)
// 0x08c : reserved
// 0x090 : Data signal of features_16
//         bit 31~0 - features_16[31:0] (Read/Write)
// 0x094 : reserved
// 0x098 : Data signal of features_17
//         bit 31~0 - features_17[31:0] (Read/Write)
// 0x09c : reserved
// 0x0a0 : Data signal of features_18
//         bit 31~0 - features_18[31:0] (Read/Write)
// 0x0a4 : reserved
// 0x0a8 : Data signal of features_19
//         bit 31~0 - features_19[31:0] (Read/Write)
// 0x0ac : reserved
// 0x0b0 : Data signal of features_20
//         bit 31~0 - features_20[31:0] (Read/Write)
// 0x0b4 : reserved
// 0x0b8 : Data signal of features_21
//         bit 31~0 - features_21[31:0] (Read/Write)
// 0x0bc : reserved
// 0x0c0 : Data signal of features_22
//         bit 31~0 - features_22[31:0] (Read/Write)
// 0x0c4 : reserved
// 0x0c8 : Data signal of features_23
//         bit 31~0 - features_23[31:0] (Read/Write)
// 0x0cc : reserved
// 0x0d0 : Data signal of features_24
//         bit 31~0 - features_24[31:0] (Read/Write)
// 0x0d4 : reserved
// 0x0d8 : Data signal of features_25
//         bit 31~0 - features_25[31:0] (Read/Write)
// 0x0dc : reserved
// 0x0e0 : Data signal of features_26
//         bit 31~0 - features_26[31:0] (Read/Write)
// 0x0e4 : reserved
// 0x0e8 : Data signal of features_27
//         bit 31~0 - features_27[31:0] (Read/Write)
// 0x0ec : reserved
// 0x0f0 : Data signal of features_28
//         bit 31~0 - features_28[31:0] (Read/Write)
// 0x0f4 : reserved
// 0x0f8 : Data signal of features_29
//         bit 31~0 - features_29[31:0] (Read/Write)
// 0x0fc : reserved
// 0x100 : Data signal of features_30
//         bit 31~0 - features_30[31:0] (Read/Write)
// 0x104 : reserved
// 0x108 : Data signal of features_31
//         bit 31~0 - features_31[31:0] (Read/Write)
// 0x10c : reserved
// (SC = Self Clear, COR = Clear on Read, TOW = Toggle on Write, COH = Clear on Handshake)

#define XPREDICT_FEATURES_ADDR_FEATURES_0_DATA  0x010
#define XPREDICT_FEATURES_BITS_FEATURES_0_DATA  32
#define XPREDICT_FEATURES_ADDR_FEATURES_1_DATA  0x018
#define XPREDICT_FEATURES_BITS_FEATURES_1_DATA  32
#define XPREDICT_FEATURES_ADDR_FEATURES_2_DATA  0x020
#define XPREDICT_FEATURES_BITS_FEATURES_2_DATA  32
#define XPREDICT_FEATURES_ADDR_FEATURES_3_DATA  0x028
#define XPREDICT_FEATURES_BITS_FEATURES_3_DATA  32
#define XPREDICT_FEATURES_ADDR_FEATURES_4_DATA  0x030
#define XPREDICT_FEATURES_BITS_FEATURES_4_DATA  32
#define XPREDICT_FEATURES_ADDR_FEATURES_5_DATA  0x038
#define XPREDICT_FEATURES_BITS_FEATURES_5_DATA  32
#define XPREDICT_FEATURES_ADDR_FEATURES_6_DATA  0x040
#define XPREDICT_FEATURES_BITS_FEATURES_6_DATA  32
#define XPREDICT_FEATURES_ADDR_FEATURES_7_DATA  0x048
#define XPREDICT_FEATURES_BITS_FEATURES_7_DATA  32
#define XPREDICT_FEATURES_ADDR_FEATURES_8_DATA  0x050
#define XPREDICT_FEATURES_BITS_FEATURES_8_DATA  32
#define XPREDICT_FEATURES_ADDR_FEATURES_9_DATA  0x058
#define XPREDICT_FEATURES_BITS_FEATURES_9_DATA  32
#define XPREDICT_FEATURES_ADDR_FEATURES_10_DATA 0x060
#define XPREDICT_FEATURES_BITS_FEATURES_10_DATA 32
#define XPREDICT_FEATURES_ADDR_FEATURES_11_DATA 0x068
#define XPREDICT_FEATURES_BITS_FEATURES_11_DATA 32
#define XPREDICT_FEATURES_ADDR_FEATURES_12_DATA 0x070
#define XPREDICT_FEATURES_BITS_FEATURES_12_DATA 32
#define XPREDICT_FEATURES_ADDR_FEATURES_13_DATA 0x078
#define XPREDICT_FEATURES_BITS_FEATURES_13_DATA 32
#define XPREDICT_FEATURES_ADDR_FEATURES_14_DATA 0x080
#define XPREDICT_FEATURES_BITS_FEATURES_14_DATA 32
#define XPREDICT_FEATURES_ADDR_FEATURES_15_DATA 0x088
#define XPREDICT_FEATURES_BITS_FEATURES_15_DATA 32
#define XPREDICT_FEATURES_ADDR_FEATURES_16_DATA 0x090
#define XPREDICT_FEATURES_BITS_FEATURES_16_DATA 32
#define XPREDICT_FEATURES_ADDR_FEATURES_17_DATA 0x098
#define XPREDICT_FEATURES_BITS_FEATURES_17_DATA 32
#define XPREDICT_FEATURES_ADDR_FEATURES_18_DATA 0x0a0
#define XPREDICT_FEATURES_BITS_FEATURES_18_DATA 32
#define XPREDICT_FEATURES_ADDR_FEATURES_19_DATA 0x0a8
#define XPREDICT_FEATURES_BITS_FEATURES_19_DATA 32
#define XPREDICT_FEATURES_ADDR_FEATURES_20_DATA 0x0b0
#define XPREDICT_FEATURES_BITS_FEATURES_20_DATA 32
#define XPREDICT_FEATURES_ADDR_FEATURES_21_DATA 0x0b8
#define XPREDICT_FEATURES_BITS_FEATURES_21_DATA 32
#define XPREDICT_FEATURES_ADDR_FEATURES_22_DATA 0x0c0
#define XPREDICT_FEATURES_BITS_FEATURES_22_DATA 32
#define XPREDICT_FEATURES_ADDR_FEATURES_23_DATA 0x0c8
#define XPREDICT_FEATURES_BITS_FEATURES_23_DATA 32
#define XPREDICT_FEATURES_ADDR_FEATURES_24_DATA 0x0d0
#define XPREDICT_FEATURES_BITS_FEATURES_24_DATA 32
#define XPREDICT_FEATURES_ADDR_FEATURES_25_DATA 0x0d8
#define XPREDICT_FEATURES_BITS_FEATURES_25_DATA 32
#define XPREDICT_FEATURES_ADDR_FEATURES_26_DATA 0x0e0
#define XPREDICT_FEATURES_BITS_FEATURES_26_DATA 32
#define XPREDICT_FEATURES_ADDR_FEATURES_27_DATA 0x0e8
#define XPREDICT_FEATURES_BITS_FEATURES_27_DATA 32
#define XPREDICT_FEATURES_ADDR_FEATURES_28_DATA 0x0f0
#define XPREDICT_FEATURES_BITS_FEATURES_28_DATA 32
#define XPREDICT_FEATURES_ADDR_FEATURES_29_DATA 0x0f8
#define XPREDICT_FEATURES_BITS_FEATURES_29_DATA 32
#define XPREDICT_FEATURES_ADDR_FEATURES_30_DATA 0x100
#define XPREDICT_FEATURES_BITS_FEATURES_30_DATA 32
#define XPREDICT_FEATURES_ADDR_FEATURES_31_DATA 0x108
#define XPREDICT_FEATURES_BITS_FEATURES_31_DATA 32

// prediction
// 0x00 : reserved
// 0x04 : reserved
// 0x08 : reserved
// 0x0c : reserved
// 0x10 : Data signal of prediction
//        bit 31~0 - prediction[31:0] (Read)
// 0x14 : Control signal of prediction
//        bit 0  - prediction_ap_vld (Read/COR)
//        others - reserved
// (SC = Self Clear, COR = Clear on Read, TOW = Toggle on Write, COH = Clear on Handshake)

#define XPREDICT_PREDICTION_ADDR_PREDICTION_DATA 0x10
#define XPREDICT_PREDICTION_BITS_PREDICTION_DATA 32
#define XPREDICT_PREDICTION_ADDR_PREDICTION_CTRL 0x14

// tree
// 0x01000 ~
// 0x01fff : Memory 'tree_0' (512 * 64b)
//           Word 2n   : bit [31:0] - tree_0[n][31: 0]
//           Word 2n+1 : bit [31:0] - tree_0[n][63:32]
// 0x02000 ~
// 0x02fff : Memory 'tree_1' (512 * 64b)
//           Word 2n   : bit [31:0] - tree_1[n][31: 0]
//           Word 2n+1 : bit [31:0] - tree_1[n][63:32]
// 0x03000 ~
// 0x03fff : Memory 'tree_2' (512 * 64b)
//           Word 2n   : bit [31:0] - tree_2[n][31: 0]
//           Word 2n+1 : bit [31:0] - tree_2[n][63:32]
// 0x04000 ~
// 0x04fff : Memory 'tree_3' (512 * 64b)
//           Word 2n   : bit [31:0] - tree_3[n][31: 0]
//           Word 2n+1 : bit [31:0] - tree_3[n][63:32]
// 0x05000 ~
// 0x05fff : Memory 'tree_4' (512 * 64b)
//           Word 2n   : bit [31:0] - tree_4[n][31: 0]
//           Word 2n+1 : bit [31:0] - tree_4[n][63:32]
// 0x06000 ~
// 0x06fff : Memory 'tree_5' (512 * 64b)
//           Word 2n   : bit [31:0] - tree_5[n][31: 0]
//           Word 2n+1 : bit [31:0] - tree_5[n][63:32]
// 0x07000 ~
// 0x07fff : Memory 'tree_6' (512 * 64b)
//           Word 2n   : bit [31:0] - tree_6[n][31: 0]
//           Word 2n+1 : bit [31:0] - tree_6[n][63:32]
// 0x08000 ~
// 0x08fff : Memory 'tree_7' (512 * 64b)
//           Word 2n   : bit [31:0] - tree_7[n][31: 0]
//           Word 2n+1 : bit [31:0] - tree_7[n][63:32]
// 0x09000 ~
// 0x09fff : Memory 'tree_8' (512 * 64b)
//           Word 2n   : bit [31:0] - tree_8[n][31: 0]
//           Word 2n+1 : bit [31:0] - tree_8[n][63:32]
// 0x0a000 ~
// 0x0afff : Memory 'tree_9' (512 * 64b)
//           Word 2n   : bit [31:0] - tree_9[n][31: 0]
//           Word 2n+1 : bit [31:0] - tree_9[n][63:32]
// 0x0b000 ~
// 0x0bfff : Memory 'tree_10' (512 * 64b)
//           Word 2n   : bit [31:0] - tree_10[n][31: 0]
//           Word 2n+1 : bit [31:0] - tree_10[n][63:32]
// 0x0c000 ~
// 0x0cfff : Memory 'tree_11' (512 * 64b)
//           Word 2n   : bit [31:0] - tree_11[n][31: 0]
//           Word 2n+1 : bit [31:0] - tree_11[n][63:32]
// 0x0d000 ~
// 0x0dfff : Memory 'tree_12' (512 * 64b)
//           Word 2n   : bit [31:0] - tree_12[n][31: 0]
//           Word 2n+1 : bit [31:0] - tree_12[n][63:32]
// 0x0e000 ~
// 0x0efff : Memory 'tree_13' (512 * 64b)
//           Word 2n   : bit [31:0] - tree_13[n][31: 0]
//           Word 2n+1 : bit [31:0] - tree_13[n][63:32]
// 0x0f000 ~
// 0x0ffff : Memory 'tree_14' (512 * 64b)
//           Word 2n   : bit [31:0] - tree_14[n][31: 0]
//           Word 2n+1 : bit [31:0] - tree_14[n][63:32]
// 0x10000 ~
// 0x10fff : Memory 'tree_15' (512 * 64b)
//           Word 2n   : bit [31:0] - tree_15[n][31: 0]
//           Word 2n+1 : bit [31:0] - tree_15[n][63:32]
// 0x11000 ~
// 0x11fff : Memory 'tree_16' (512 * 64b)
//           Word 2n   : bit [31:0] - tree_16[n][31: 0]
//           Word 2n+1 : bit [31:0] - tree_16[n][63:32]
// 0x12000 ~
// 0x12fff : Memory 'tree_17' (512 * 64b)
//           Word 2n   : bit [31:0] - tree_17[n][31: 0]
//           Word 2n+1 : bit [31:0] - tree_17[n][63:32]
// 0x13000 ~
// 0x13fff : Memory 'tree_18' (512 * 64b)
//           Word 2n   : bit [31:0] - tree_18[n][31: 0]
//           Word 2n+1 : bit [31:0] - tree_18[n][63:32]
// 0x14000 ~
// 0x14fff : Memory 'tree_19' (512 * 64b)
//           Word 2n   : bit [31:0] - tree_19[n][31: 0]
//           Word 2n+1 : bit [31:0] - tree_19[n][63:32]
// 0x15000 ~
// 0x15fff : Memory 'tree_20' (512 * 64b)
//           Word 2n   : bit [31:0] - tree_20[n][31: 0]
//           Word 2n+1 : bit [31:0] - tree_20[n][63:32]
// 0x16000 ~
// 0x16fff : Memory 'tree_21' (512 * 64b)
//           Word 2n   : bit [31:0] - tree_21[n][31: 0]
//           Word 2n+1 : bit [31:0] - tree_21[n][63:32]
// 0x17000 ~
// 0x17fff : Memory 'tree_22' (512 * 64b)
//           Word 2n   : bit [31:0] - tree_22[n][31: 0]
//           Word 2n+1 : bit [31:0] - tree_22[n][63:32]
// 0x18000 ~
// 0x18fff : Memory 'tree_23' (512 * 64b)
//           Word 2n   : bit [31:0] - tree_23[n][31: 0]
//           Word 2n+1 : bit [31:0] - tree_23[n][63:32]
// 0x19000 ~
// 0x19fff : Memory 'tree_24' (512 * 64b)
//           Word 2n   : bit [31:0] - tree_24[n][31: 0]
//           Word 2n+1 : bit [31:0] - tree_24[n][63:32]
// 0x1a000 ~
// 0x1afff : Memory 'tree_25' (512 * 64b)
//           Word 2n   : bit [31:0] - tree_25[n][31: 0]
//           Word 2n+1 : bit [31:0] - tree_25[n][63:32]
// 0x1b000 ~
// 0x1bfff : Memory 'tree_26' (512 * 64b)
//           Word 2n   : bit [31:0] - tree_26[n][31: 0]
//           Word 2n+1 : bit [31:0] - tree_26[n][63:32]
// 0x1c000 ~
// 0x1cfff : Memory 'tree_27' (512 * 64b)
//           Word 2n   : bit [31:0] - tree_27[n][31: 0]
//           Word 2n+1 : bit [31:0] - tree_27[n][63:32]
// 0x1d000 ~
// 0x1dfff : Memory 'tree_28' (512 * 64b)
//           Word 2n   : bit [31:0] - tree_28[n][31: 0]
//           Word 2n+1 : bit [31:0] - tree_28[n][63:32]
// 0x1e000 ~
// 0x1efff : Memory 'tree_29' (512 * 64b)
//           Word 2n   : bit [31:0] - tree_29[n][31: 0]
//           Word 2n+1 : bit [31:0] - tree_29[n][63:32]
// 0x1f000 ~
// 0x1ffff : Memory 'tree_30' (512 * 64b)
//           Word 2n   : bit [31:0] - tree_30[n][31: 0]
//           Word 2n+1 : bit [31:0] - tree_30[n][63:32]
// 0x20000 ~
// 0x20fff : Memory 'tree_31' (512 * 64b)
//           Word 2n   : bit [31:0] - tree_31[n][31: 0]
//           Word 2n+1 : bit [31:0] - tree_31[n][63:32]
// 0x21000 ~
// 0x21fff : Memory 'tree_32' (512 * 64b)
//           Word 2n   : bit [31:0] - tree_32[n][31: 0]
//           Word 2n+1 : bit [31:0] - tree_32[n][63:32]
// 0x22000 ~
// 0x22fff : Memory 'tree_33' (512 * 64b)
//           Word 2n   : bit [31:0] - tree_33[n][31: 0]
//           Word 2n+1 : bit [31:0] - tree_33[n][63:32]
// 0x23000 ~
// 0x23fff : Memory 'tree_34' (512 * 64b)
//           Word 2n   : bit [31:0] - tree_34[n][31: 0]
//           Word 2n+1 : bit [31:0] - tree_34[n][63:32]
// 0x24000 ~
// 0x24fff : Memory 'tree_35' (512 * 64b)
//           Word 2n   : bit [31:0] - tree_35[n][31: 0]
//           Word 2n+1 : bit [31:0] - tree_35[n][63:32]
// 0x25000 ~
// 0x25fff : Memory 'tree_36' (512 * 64b)
//           Word 2n   : bit [31:0] - tree_36[n][31: 0]
//           Word 2n+1 : bit [31:0] - tree_36[n][63:32]
// 0x26000 ~
// 0x26fff : Memory 'tree_37' (512 * 64b)
//           Word 2n   : bit [31:0] - tree_37[n][31: 0]
//           Word 2n+1 : bit [31:0] - tree_37[n][63:32]
// 0x27000 ~
// 0x27fff : Memory 'tree_38' (512 * 64b)
//           Word 2n   : bit [31:0] - tree_38[n][31: 0]
//           Word 2n+1 : bit [31:0] - tree_38[n][63:32]
// 0x28000 ~
// 0x28fff : Memory 'tree_39' (512 * 64b)
//           Word 2n   : bit [31:0] - tree_39[n][31: 0]
//           Word 2n+1 : bit [31:0] - tree_39[n][63:32]
// 0x29000 ~
// 0x29fff : Memory 'tree_40' (512 * 64b)
//           Word 2n   : bit [31:0] - tree_40[n][31: 0]
//           Word 2n+1 : bit [31:0] - tree_40[n][63:32]
// 0x2a000 ~
// 0x2afff : Memory 'tree_41' (512 * 64b)
//           Word 2n   : bit [31:0] - tree_41[n][31: 0]
//           Word 2n+1 : bit [31:0] - tree_41[n][63:32]
// 0x2b000 ~
// 0x2bfff : Memory 'tree_42' (512 * 64b)
//           Word 2n   : bit [31:0] - tree_42[n][31: 0]
//           Word 2n+1 : bit [31:0] - tree_42[n][63:32]
// 0x2c000 ~
// 0x2cfff : Memory 'tree_43' (512 * 64b)
//           Word 2n   : bit [31:0] - tree_43[n][31: 0]
//           Word 2n+1 : bit [31:0] - tree_43[n][63:32]
// 0x2d000 ~
// 0x2dfff : Memory 'tree_44' (512 * 64b)
//           Word 2n   : bit [31:0] - tree_44[n][31: 0]
//           Word 2n+1 : bit [31:0] - tree_44[n][63:32]
// 0x2e000 ~
// 0x2efff : Memory 'tree_45' (512 * 64b)
//           Word 2n   : bit [31:0] - tree_45[n][31: 0]
//           Word 2n+1 : bit [31:0] - tree_45[n][63:32]
// 0x2f000 ~
// 0x2ffff : Memory 'tree_46' (512 * 64b)
//           Word 2n   : bit [31:0] - tree_46[n][31: 0]
//           Word 2n+1 : bit [31:0] - tree_46[n][63:32]
// 0x30000 ~
// 0x30fff : Memory 'tree_47' (512 * 64b)
//           Word 2n   : bit [31:0] - tree_47[n][31: 0]
//           Word 2n+1 : bit [31:0] - tree_47[n][63:32]
// 0x31000 ~
// 0x31fff : Memory 'tree_48' (512 * 64b)
//           Word 2n   : bit [31:0] - tree_48[n][31: 0]
//           Word 2n+1 : bit [31:0] - tree_48[n][63:32]
// 0x32000 ~
// 0x32fff : Memory 'tree_49' (512 * 64b)
//           Word 2n   : bit [31:0] - tree_49[n][31: 0]
//           Word 2n+1 : bit [31:0] - tree_49[n][63:32]
// 0x33000 ~
// 0x33fff : Memory 'tree_50' (512 * 64b)
//           Word 2n   : bit [31:0] - tree_50[n][31: 0]
//           Word 2n+1 : bit [31:0] - tree_50[n][63:32]
// 0x34000 ~
// 0x34fff : Memory 'tree_51' (512 * 64b)
//           Word 2n   : bit [31:0] - tree_51[n][31: 0]
//           Word 2n+1 : bit [31:0] - tree_51[n][63:32]
// 0x35000 ~
// 0x35fff : Memory 'tree_52' (512 * 64b)
//           Word 2n   : bit [31:0] - tree_52[n][31: 0]
//           Word 2n+1 : bit [31:0] - tree_52[n][63:32]
// 0x36000 ~
// 0x36fff : Memory 'tree_53' (512 * 64b)
//           Word 2n   : bit [31:0] - tree_53[n][31: 0]
//           Word 2n+1 : bit [31:0] - tree_53[n][63:32]
// 0x37000 ~
// 0x37fff : Memory 'tree_54' (512 * 64b)
//           Word 2n   : bit [31:0] - tree_54[n][31: 0]
//           Word 2n+1 : bit [31:0] - tree_54[n][63:32]
// 0x38000 ~
// 0x38fff : Memory 'tree_55' (512 * 64b)
//           Word 2n   : bit [31:0] - tree_55[n][31: 0]
//           Word 2n+1 : bit [31:0] - tree_55[n][63:32]
// 0x39000 ~
// 0x39fff : Memory 'tree_56' (512 * 64b)
//           Word 2n   : bit [31:0] - tree_56[n][31: 0]
//           Word 2n+1 : bit [31:0] - tree_56[n][63:32]
// 0x3a000 ~
// 0x3afff : Memory 'tree_57' (512 * 64b)
//           Word 2n   : bit [31:0] - tree_57[n][31: 0]
//           Word 2n+1 : bit [31:0] - tree_57[n][63:32]
// 0x3b000 ~
// 0x3bfff : Memory 'tree_58' (512 * 64b)
//           Word 2n   : bit [31:0] - tree_58[n][31: 0]
//           Word 2n+1 : bit [31:0] - tree_58[n][63:32]
// 0x3c000 ~
// 0x3cfff : Memory 'tree_59' (512 * 64b)
//           Word 2n   : bit [31:0] - tree_59[n][31: 0]
//           Word 2n+1 : bit [31:0] - tree_59[n][63:32]
// 0x3d000 ~
// 0x3dfff : Memory 'tree_60' (512 * 64b)
//           Word 2n   : bit [31:0] - tree_60[n][31: 0]
//           Word 2n+1 : bit [31:0] - tree_60[n][63:32]
// 0x3e000 ~
// 0x3efff : Memory 'tree_61' (512 * 64b)
//           Word 2n   : bit [31:0] - tree_61[n][31: 0]
//           Word 2n+1 : bit [31:0] - tree_61[n][63:32]
// 0x3f000 ~
// 0x3ffff : Memory 'tree_62' (512 * 64b)
//           Word 2n   : bit [31:0] - tree_62[n][31: 0]
//           Word 2n+1 : bit [31:0] - tree_62[n][63:32]
// 0x40000 ~
// 0x40fff : Memory 'tree_63' (512 * 64b)
//           Word 2n   : bit [31:0] - tree_63[n][31: 0]
//           Word 2n+1 : bit [31:0] - tree_63[n][63:32]
// (SC = Self Clear, COR = Clear on Read, TOW = Toggle on Write, COH = Clear on Handshake)

#define XPREDICT_TREE_ADDR_TREE_0_BASE  0x01000
#define XPREDICT_TREE_ADDR_TREE_0_HIGH  0x01fff
#define XPREDICT_TREE_WIDTH_TREE_0      64
#define XPREDICT_TREE_DEPTH_TREE_0      512
#define XPREDICT_TREE_ADDR_TREE_1_BASE  0x02000
#define XPREDICT_TREE_ADDR_TREE_1_HIGH  0x02fff
#define XPREDICT_TREE_WIDTH_TREE_1      64
#define XPREDICT_TREE_DEPTH_TREE_1      512
#define XPREDICT_TREE_ADDR_TREE_2_BASE  0x03000
#define XPREDICT_TREE_ADDR_TREE_2_HIGH  0x03fff
#define XPREDICT_TREE_WIDTH_TREE_2      64
#define XPREDICT_TREE_DEPTH_TREE_2      512
#define XPREDICT_TREE_ADDR_TREE_3_BASE  0x04000
#define XPREDICT_TREE_ADDR_TREE_3_HIGH  0x04fff
#define XPREDICT_TREE_WIDTH_TREE_3      64
#define XPREDICT_TREE_DEPTH_TREE_3      512
#define XPREDICT_TREE_ADDR_TREE_4_BASE  0x05000
#define XPREDICT_TREE_ADDR_TREE_4_HIGH  0x05fff
#define XPREDICT_TREE_WIDTH_TREE_4      64
#define XPREDICT_TREE_DEPTH_TREE_4      512
#define XPREDICT_TREE_ADDR_TREE_5_BASE  0x06000
#define XPREDICT_TREE_ADDR_TREE_5_HIGH  0x06fff
#define XPREDICT_TREE_WIDTH_TREE_5      64
#define XPREDICT_TREE_DEPTH_TREE_5      512
#define XPREDICT_TREE_ADDR_TREE_6_BASE  0x07000
#define XPREDICT_TREE_ADDR_TREE_6_HIGH  0x07fff
#define XPREDICT_TREE_WIDTH_TREE_6      64
#define XPREDICT_TREE_DEPTH_TREE_6      512
#define XPREDICT_TREE_ADDR_TREE_7_BASE  0x08000
#define XPREDICT_TREE_ADDR_TREE_7_HIGH  0x08fff
#define XPREDICT_TREE_WIDTH_TREE_7      64
#define XPREDICT_TREE_DEPTH_TREE_7      512
#define XPREDICT_TREE_ADDR_TREE_8_BASE  0x09000
#define XPREDICT_TREE_ADDR_TREE_8_HIGH  0x09fff
#define XPREDICT_TREE_WIDTH_TREE_8      64
#define XPREDICT_TREE_DEPTH_TREE_8      512
#define XPREDICT_TREE_ADDR_TREE_9_BASE  0x0a000
#define XPREDICT_TREE_ADDR_TREE_9_HIGH  0x0afff
#define XPREDICT_TREE_WIDTH_TREE_9      64
#define XPREDICT_TREE_DEPTH_TREE_9      512
#define XPREDICT_TREE_ADDR_TREE_10_BASE 0x0b000
#define XPREDICT_TREE_ADDR_TREE_10_HIGH 0x0bfff
#define XPREDICT_TREE_WIDTH_TREE_10     64
#define XPREDICT_TREE_DEPTH_TREE_10     512
#define XPREDICT_TREE_ADDR_TREE_11_BASE 0x0c000
#define XPREDICT_TREE_ADDR_TREE_11_HIGH 0x0cfff
#define XPREDICT_TREE_WIDTH_TREE_11     64
#define XPREDICT_TREE_DEPTH_TREE_11     512
#define XPREDICT_TREE_ADDR_TREE_12_BASE 0x0d000
#define XPREDICT_TREE_ADDR_TREE_12_HIGH 0x0dfff
#define XPREDICT_TREE_WIDTH_TREE_12     64
#define XPREDICT_TREE_DEPTH_TREE_12     512
#define XPREDICT_TREE_ADDR_TREE_13_BASE 0x0e000
#define XPREDICT_TREE_ADDR_TREE_13_HIGH 0x0efff
#define XPREDICT_TREE_WIDTH_TREE_13     64
#define XPREDICT_TREE_DEPTH_TREE_13     512
#define XPREDICT_TREE_ADDR_TREE_14_BASE 0x0f000
#define XPREDICT_TREE_ADDR_TREE_14_HIGH 0x0ffff
#define XPREDICT_TREE_WIDTH_TREE_14     64
#define XPREDICT_TREE_DEPTH_TREE_14     512
#define XPREDICT_TREE_ADDR_TREE_15_BASE 0x10000
#define XPREDICT_TREE_ADDR_TREE_15_HIGH 0x10fff
#define XPREDICT_TREE_WIDTH_TREE_15     64
#define XPREDICT_TREE_DEPTH_TREE_15     512
#define XPREDICT_TREE_ADDR_TREE_16_BASE 0x11000
#define XPREDICT_TREE_ADDR_TREE_16_HIGH 0x11fff
#define XPREDICT_TREE_WIDTH_TREE_16     64
#define XPREDICT_TREE_DEPTH_TREE_16     512
#define XPREDICT_TREE_ADDR_TREE_17_BASE 0x12000
#define XPREDICT_TREE_ADDR_TREE_17_HIGH 0x12fff
#define XPREDICT_TREE_WIDTH_TREE_17     64
#define XPREDICT_TREE_DEPTH_TREE_17     512
#define XPREDICT_TREE_ADDR_TREE_18_BASE 0x13000
#define XPREDICT_TREE_ADDR_TREE_18_HIGH 0x13fff
#define XPREDICT_TREE_WIDTH_TREE_18     64
#define XPREDICT_TREE_DEPTH_TREE_18     512
#define XPREDICT_TREE_ADDR_TREE_19_BASE 0x14000
#define XPREDICT_TREE_ADDR_TREE_19_HIGH 0x14fff
#define XPREDICT_TREE_WIDTH_TREE_19     64
#define XPREDICT_TREE_DEPTH_TREE_19     512
#define XPREDICT_TREE_ADDR_TREE_20_BASE 0x15000
#define XPREDICT_TREE_ADDR_TREE_20_HIGH 0x15fff
#define XPREDICT_TREE_WIDTH_TREE_20     64
#define XPREDICT_TREE_DEPTH_TREE_20     512
#define XPREDICT_TREE_ADDR_TREE_21_BASE 0x16000
#define XPREDICT_TREE_ADDR_TREE_21_HIGH 0x16fff
#define XPREDICT_TREE_WIDTH_TREE_21     64
#define XPREDICT_TREE_DEPTH_TREE_21     512
#define XPREDICT_TREE_ADDR_TREE_22_BASE 0x17000
#define XPREDICT_TREE_ADDR_TREE_22_HIGH 0x17fff
#define XPREDICT_TREE_WIDTH_TREE_22     64
#define XPREDICT_TREE_DEPTH_TREE_22     512
#define XPREDICT_TREE_ADDR_TREE_23_BASE 0x18000
#define XPREDICT_TREE_ADDR_TREE_23_HIGH 0x18fff
#define XPREDICT_TREE_WIDTH_TREE_23     64
#define XPREDICT_TREE_DEPTH_TREE_23     512
#define XPREDICT_TREE_ADDR_TREE_24_BASE 0x19000
#define XPREDICT_TREE_ADDR_TREE_24_HIGH 0x19fff
#define XPREDICT_TREE_WIDTH_TREE_24     64
#define XPREDICT_TREE_DEPTH_TREE_24     512
#define XPREDICT_TREE_ADDR_TREE_25_BASE 0x1a000
#define XPREDICT_TREE_ADDR_TREE_25_HIGH 0x1afff
#define XPREDICT_TREE_WIDTH_TREE_25     64
#define XPREDICT_TREE_DEPTH_TREE_25     512
#define XPREDICT_TREE_ADDR_TREE_26_BASE 0x1b000
#define XPREDICT_TREE_ADDR_TREE_26_HIGH 0x1bfff
#define XPREDICT_TREE_WIDTH_TREE_26     64
#define XPREDICT_TREE_DEPTH_TREE_26     512
#define XPREDICT_TREE_ADDR_TREE_27_BASE 0x1c000
#define XPREDICT_TREE_ADDR_TREE_27_HIGH 0x1cfff
#define XPREDICT_TREE_WIDTH_TREE_27     64
#define XPREDICT_TREE_DEPTH_TREE_27     512
#define XPREDICT_TREE_ADDR_TREE_28_BASE 0x1d000
#define XPREDICT_TREE_ADDR_TREE_28_HIGH 0x1dfff
#define XPREDICT_TREE_WIDTH_TREE_28     64
#define XPREDICT_TREE_DEPTH_TREE_28     512
#define XPREDICT_TREE_ADDR_TREE_29_BASE 0x1e000
#define XPREDICT_TREE_ADDR_TREE_29_HIGH 0x1efff
#define XPREDICT_TREE_WIDTH_TREE_29     64
#define XPREDICT_TREE_DEPTH_TREE_29     512
#define XPREDICT_TREE_ADDR_TREE_30_BASE 0x1f000
#define XPREDICT_TREE_ADDR_TREE_30_HIGH 0x1ffff
#define XPREDICT_TREE_WIDTH_TREE_30     64
#define XPREDICT_TREE_DEPTH_TREE_30     512
#define XPREDICT_TREE_ADDR_TREE_31_BASE 0x20000
#define XPREDICT_TREE_ADDR_TREE_31_HIGH 0x20fff
#define XPREDICT_TREE_WIDTH_TREE_31     64
#define XPREDICT_TREE_DEPTH_TREE_31     512
#define XPREDICT_TREE_ADDR_TREE_32_BASE 0x21000
#define XPREDICT_TREE_ADDR_TREE_32_HIGH 0x21fff
#define XPREDICT_TREE_WIDTH_TREE_32     64
#define XPREDICT_TREE_DEPTH_TREE_32     512
#define XPREDICT_TREE_ADDR_TREE_33_BASE 0x22000
#define XPREDICT_TREE_ADDR_TREE_33_HIGH 0x22fff
#define XPREDICT_TREE_WIDTH_TREE_33     64
#define XPREDICT_TREE_DEPTH_TREE_33     512
#define XPREDICT_TREE_ADDR_TREE_34_BASE 0x23000
#define XPREDICT_TREE_ADDR_TREE_34_HIGH 0x23fff
#define XPREDICT_TREE_WIDTH_TREE_34     64
#define XPREDICT_TREE_DEPTH_TREE_34     512
#define XPREDICT_TREE_ADDR_TREE_35_BASE 0x24000
#define XPREDICT_TREE_ADDR_TREE_35_HIGH 0x24fff
#define XPREDICT_TREE_WIDTH_TREE_35     64
#define XPREDICT_TREE_DEPTH_TREE_35     512
#define XPREDICT_TREE_ADDR_TREE_36_BASE 0x25000
#define XPREDICT_TREE_ADDR_TREE_36_HIGH 0x25fff
#define XPREDICT_TREE_WIDTH_TREE_36     64
#define XPREDICT_TREE_DEPTH_TREE_36     512
#define XPREDICT_TREE_ADDR_TREE_37_BASE 0x26000
#define XPREDICT_TREE_ADDR_TREE_37_HIGH 0x26fff
#define XPREDICT_TREE_WIDTH_TREE_37     64
#define XPREDICT_TREE_DEPTH_TREE_37     512
#define XPREDICT_TREE_ADDR_TREE_38_BASE 0x27000
#define XPREDICT_TREE_ADDR_TREE_38_HIGH 0x27fff
#define XPREDICT_TREE_WIDTH_TREE_38     64
#define XPREDICT_TREE_DEPTH_TREE_38     512
#define XPREDICT_TREE_ADDR_TREE_39_BASE 0x28000
#define XPREDICT_TREE_ADDR_TREE_39_HIGH 0x28fff
#define XPREDICT_TREE_WIDTH_TREE_39     64
#define XPREDICT_TREE_DEPTH_TREE_39     512
#define XPREDICT_TREE_ADDR_TREE_40_BASE 0x29000
#define XPREDICT_TREE_ADDR_TREE_40_HIGH 0x29fff
#define XPREDICT_TREE_WIDTH_TREE_40     64
#define XPREDICT_TREE_DEPTH_TREE_40     512
#define XPREDICT_TREE_ADDR_TREE_41_BASE 0x2a000
#define XPREDICT_TREE_ADDR_TREE_41_HIGH 0x2afff
#define XPREDICT_TREE_WIDTH_TREE_41     64
#define XPREDICT_TREE_DEPTH_TREE_41     512
#define XPREDICT_TREE_ADDR_TREE_42_BASE 0x2b000
#define XPREDICT_TREE_ADDR_TREE_42_HIGH 0x2bfff
#define XPREDICT_TREE_WIDTH_TREE_42     64
#define XPREDICT_TREE_DEPTH_TREE_42     512
#define XPREDICT_TREE_ADDR_TREE_43_BASE 0x2c000
#define XPREDICT_TREE_ADDR_TREE_43_HIGH 0x2cfff
#define XPREDICT_TREE_WIDTH_TREE_43     64
#define XPREDICT_TREE_DEPTH_TREE_43     512
#define XPREDICT_TREE_ADDR_TREE_44_BASE 0x2d000
#define XPREDICT_TREE_ADDR_TREE_44_HIGH 0x2dfff
#define XPREDICT_TREE_WIDTH_TREE_44     64
#define XPREDICT_TREE_DEPTH_TREE_44     512
#define XPREDICT_TREE_ADDR_TREE_45_BASE 0x2e000
#define XPREDICT_TREE_ADDR_TREE_45_HIGH 0x2efff
#define XPREDICT_TREE_WIDTH_TREE_45     64
#define XPREDICT_TREE_DEPTH_TREE_45     512
#define XPREDICT_TREE_ADDR_TREE_46_BASE 0x2f000
#define XPREDICT_TREE_ADDR_TREE_46_HIGH 0x2ffff
#define XPREDICT_TREE_WIDTH_TREE_46     64
#define XPREDICT_TREE_DEPTH_TREE_46     512
#define XPREDICT_TREE_ADDR_TREE_47_BASE 0x30000
#define XPREDICT_TREE_ADDR_TREE_47_HIGH 0x30fff
#define XPREDICT_TREE_WIDTH_TREE_47     64
#define XPREDICT_TREE_DEPTH_TREE_47     512
#define XPREDICT_TREE_ADDR_TREE_48_BASE 0x31000
#define XPREDICT_TREE_ADDR_TREE_48_HIGH 0x31fff
#define XPREDICT_TREE_WIDTH_TREE_48     64
#define XPREDICT_TREE_DEPTH_TREE_48     512
#define XPREDICT_TREE_ADDR_TREE_49_BASE 0x32000
#define XPREDICT_TREE_ADDR_TREE_49_HIGH 0x32fff
#define XPREDICT_TREE_WIDTH_TREE_49     64
#define XPREDICT_TREE_DEPTH_TREE_49     512
#define XPREDICT_TREE_ADDR_TREE_50_BASE 0x33000
#define XPREDICT_TREE_ADDR_TREE_50_HIGH 0x33fff
#define XPREDICT_TREE_WIDTH_TREE_50     64
#define XPREDICT_TREE_DEPTH_TREE_50     512
#define XPREDICT_TREE_ADDR_TREE_51_BASE 0x34000
#define XPREDICT_TREE_ADDR_TREE_51_HIGH 0x34fff
#define XPREDICT_TREE_WIDTH_TREE_51     64
#define XPREDICT_TREE_DEPTH_TREE_51     512
#define XPREDICT_TREE_ADDR_TREE_52_BASE 0x35000
#define XPREDICT_TREE_ADDR_TREE_52_HIGH 0x35fff
#define XPREDICT_TREE_WIDTH_TREE_52     64
#define XPREDICT_TREE_DEPTH_TREE_52     512
#define XPREDICT_TREE_ADDR_TREE_53_BASE 0x36000
#define XPREDICT_TREE_ADDR_TREE_53_HIGH 0x36fff
#define XPREDICT_TREE_WIDTH_TREE_53     64
#define XPREDICT_TREE_DEPTH_TREE_53     512
#define XPREDICT_TREE_ADDR_TREE_54_BASE 0x37000
#define XPREDICT_TREE_ADDR_TREE_54_HIGH 0x37fff
#define XPREDICT_TREE_WIDTH_TREE_54     64
#define XPREDICT_TREE_DEPTH_TREE_54     512
#define XPREDICT_TREE_ADDR_TREE_55_BASE 0x38000
#define XPREDICT_TREE_ADDR_TREE_55_HIGH 0x38fff
#define XPREDICT_TREE_WIDTH_TREE_55     64
#define XPREDICT_TREE_DEPTH_TREE_55     512
#define XPREDICT_TREE_ADDR_TREE_56_BASE 0x39000
#define XPREDICT_TREE_ADDR_TREE_56_HIGH 0x39fff
#define XPREDICT_TREE_WIDTH_TREE_56     64
#define XPREDICT_TREE_DEPTH_TREE_56     512
#define XPREDICT_TREE_ADDR_TREE_57_BASE 0x3a000
#define XPREDICT_TREE_ADDR_TREE_57_HIGH 0x3afff
#define XPREDICT_TREE_WIDTH_TREE_57     64
#define XPREDICT_TREE_DEPTH_TREE_57     512
#define XPREDICT_TREE_ADDR_TREE_58_BASE 0x3b000
#define XPREDICT_TREE_ADDR_TREE_58_HIGH 0x3bfff
#define XPREDICT_TREE_WIDTH_TREE_58     64
#define XPREDICT_TREE_DEPTH_TREE_58     512
#define XPREDICT_TREE_ADDR_TREE_59_BASE 0x3c000
#define XPREDICT_TREE_ADDR_TREE_59_HIGH 0x3cfff
#define XPREDICT_TREE_WIDTH_TREE_59     64
#define XPREDICT_TREE_DEPTH_TREE_59     512
#define XPREDICT_TREE_ADDR_TREE_60_BASE 0x3d000
#define XPREDICT_TREE_ADDR_TREE_60_HIGH 0x3dfff
#define XPREDICT_TREE_WIDTH_TREE_60     64
#define XPREDICT_TREE_DEPTH_TREE_60     512
#define XPREDICT_TREE_ADDR_TREE_61_BASE 0x3e000
#define XPREDICT_TREE_ADDR_TREE_61_HIGH 0x3efff
#define XPREDICT_TREE_WIDTH_TREE_61     64
#define XPREDICT_TREE_DEPTH_TREE_61     512
#define XPREDICT_TREE_ADDR_TREE_62_BASE 0x3f000
#define XPREDICT_TREE_ADDR_TREE_62_HIGH 0x3ffff
#define XPREDICT_TREE_WIDTH_TREE_62     64
#define XPREDICT_TREE_DEPTH_TREE_62     512
#define XPREDICT_TREE_ADDR_TREE_63_BASE 0x40000
#define XPREDICT_TREE_ADDR_TREE_63_HIGH 0x40fff
#define XPREDICT_TREE_WIDTH_TREE_63     64
#define XPREDICT_TREE_DEPTH_TREE_63     512

